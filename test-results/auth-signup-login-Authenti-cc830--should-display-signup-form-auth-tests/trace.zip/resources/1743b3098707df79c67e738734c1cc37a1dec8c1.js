(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_77026a5b._.css",
  "static/chunks/src_34e50fca._.js",
  "static/chunks/node_modules_next_f963c7aa._.js",
  "static/chunks/node_modules_@apollo_client_d872f34d._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_56b6fd65._.js",
  "static/chunks/node_modules_motion-dom_dist_es_da948acf._.js",
  "static/chunks/node_modules_framer-motion_dist_es_5b4aafa7._.js",
  "static/chunks/node_modules_5ceb2b58._.js"
],
    source: "dynamic"
});
