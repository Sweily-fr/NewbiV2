(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_lib_auth-client_ffa3b39b.js",
  "static/chunks/_cf883065._.js",
  "static/chunks/node_modules_43314aa1._.js"
],
    source: "dynamic"
});
