(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/theme-provider.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ThemeProvider",
    ()=>ThemeProvider,
    "useTheme",
    ()=>useTheme
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
;
const initialState = {
    theme: "system",
    setTheme: ()=>null
};
const ThemeProviderContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(initialState);
function ThemeProvider(param) {
    let { children, defaultTheme = "system", storageKey = "vite-ui-theme", ...props } = param;
    _s();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const isDarkAllowed = (pathname === null || pathname === void 0 ? void 0 : pathname.startsWith("/dashboard")) || (pathname === null || pathname === void 0 ? void 0 : pathname.startsWith("/create-workspace"));
    const [theme, setTheme] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(defaultTheme);
    // Sync with localStorage on mount (client-side only)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ThemeProvider.useEffect": ()=>{
            const stored = localStorage.getItem(storageKey);
            if (stored) {
                setTheme(stored);
            }
        }
    }["ThemeProvider.useEffect"], [
        storageKey
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ThemeProvider.useEffect": ()=>{
            const root = window.document.documentElement;
            root.classList.remove("light", "dark");
            // Si on n'est pas sur une route autorisée, forcer le thème light
            if (!isDarkAllowed) {
                root.classList.add("light");
                return;
            }
            // Si on est sur une route autorisée, appliquer le thème choisi
            if (theme === "system") {
                const systemTheme = window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
                root.classList.add(systemTheme);
                return;
            }
            root.classList.add(theme);
        }
    }["ThemeProvider.useEffect"], [
        theme,
        isDarkAllowed
    ]);
    const value = {
        theme,
        setTheme: (theme)=>{
            if ("TURBOPACK compile-time truthy", 1) {
                localStorage.setItem(storageKey, theme);
            }
            setTheme(theme);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ThemeProviderContext.Provider, {
        ...props,
        value: value,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/components/theme-provider.jsx",
        lineNumber: 67,
        columnNumber: 5
    }, this);
}
_s(ThemeProvider, "FjywWPouF4fjF1wTGm8z6gByWRg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"]
    ];
});
_c = ThemeProvider;
const useTheme = ()=>{
    _s1();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(ThemeProviderContext);
    if (context === undefined) throw new Error("useTheme must be used within a ThemeProvider");
    return context;
};
_s1(useTheme, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
__turbopack_context__.k.register(_c, "ThemeProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/utils.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cn",
    ()=>cn
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/tailwind-merge/dist/bundle-mjs.mjs [app-client] (ecmascript)");
;
;
function cn() {
    for(var _len = arguments.length, inputs = new Array(_len), _key = 0; _key < _len; _key++){
        inputs[_key] = arguments[_key];
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["twMerge"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clsx"])(inputs));
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/button.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Button",
    ()=>Button,
    "buttonVariants",
    ()=>buttonVariants
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-slot/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.js [app-client] (ecmascript)");
;
;
;
;
;
const buttonVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("appearance-none relative inline-flex shrink-0 items-center justify-center cursor-pointer border-none outline-none no-underline transition-[background-color,color,box-shadow] duration-200 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:shrink-0", {
    variants: {
        variant: {
            default: "bg-[#1a1a1a] hover:bg-[#333] active:bg-[#111] text-white [box-shadow:inset_0_0_0_1px_rgba(255,255,255,0.1),0_2px_4px_-2px_rgba(0,0,0,0.12),0_3px_6px_-2px_rgba(0,0,0,0.08)]",
            primary: "bg-[#5A50FF] hover:bg-[#4840D9] active:bg-[#3F37B3] text-white [box-shadow:inset_0_0_0_1px_rgba(0,0,0,0.1),0_2px_4px_-2px_rgba(90,80,255,0.12),0_3px_6px_-2px_rgba(90,80,255,0.08)]",
            danger: "bg-[#E5484D] hover:bg-[#CD2B31] active:bg-[#AA2429] text-white [box-shadow:inset_0_0_0_1px_rgba(0,0,0,0.1),0_2px_4px_-2px_rgba(229,72,77,0.12),0_3px_6px_-2px_rgba(229,72,77,0.08)]",
            destructive: "bg-[#E5484D] hover:bg-[#CD2B31] active:bg-[#AA2429] text-white [box-shadow:inset_0_0_0_1px_rgba(0,0,0,0.1),0_2px_4px_-2px_rgba(229,72,77,0.12),0_3px_6px_-2px_rgba(229,72,77,0.08)]",
            secondary: "bg-white hover:bg-[#f5f5f5] active:bg-[#ebebeb] text-[#242529] [box-shadow:rgba(255,255,255,0)_0_0_0_1px_inset,rgba(28,40,64,0.18)_0_0_2px_0,rgba(24,41,75,0.04)_0_1px_3px_0] dark:bg-[#1a1a1a] dark:hover:bg-[#262626] dark:active:bg-[#333] dark:text-white",
            outline: "bg-transparent hover:bg-[rgba(0,0,0,0.04)] active:bg-[rgba(0,0,0,0.06)] text-[#242529] [box-shadow:rgba(255,255,255,0)_0_0_0_1px_inset,rgba(28,40,64,0.18)_0_0_2px_0,rgba(24,41,75,0.04)_0_1px_3px_0] dark:bg-[#171717] dark:text-white dark:hover:bg-[#222] dark:active:bg-[#2a2a2a] dark:[box-shadow:rgba(255,255,255,0.08)_0_0_0_1px_inset,rgba(255,255,255,0.1)_0_0_2px_0,rgba(0,0,0,0.2)_0_1px_3px_0]",
            ghost: "bg-transparent hover:bg-[rgba(0,0,0,0.04)] active:bg-[rgba(0,0,0,0.06)] text-[#242529] dark:text-white dark:hover:bg-[rgba(255,255,255,0.06)] dark:active:bg-[rgba(255,255,255,0.08)]",
            filter: "bg-[#fbfbfb] hover:bg-[#f5f5f5] active:bg-[#efefef] text-[rgba(0,0,0,0.55)] ![outline:1px_dashed_rgba(0,0,0,0.2)] [outline-offset:-1px] dark:bg-[#1a1a1a] dark:hover:bg-[#262626] dark:active:bg-[#333] dark:text-[rgba(255,255,255,0.55)] dark:![outline-color:rgba(255,255,255,0.2)]",
            link: "bg-transparent text-[#5A50FF] underline-offset-4 hover:underline dark:text-[#8b7fff]"
        },
        size: {
            default: "h-8 gap-1.5 py-1.5 px-2.5 rounded-[9px] text-sm leading-5 font-medium tracking-tight",
            sm: "h-8 gap-1.5 py-1.5 px-2.5 rounded-[9px] text-sm leading-5 font-medium tracking-tight",
            lg: "gap-2 py-[7px] pr-3 pl-2.5 rounded-lg text-sm leading-5 font-medium tracking-tight",
            md: "h-8 gap-1.5 py-1.5 px-2.5 rounded-[9px] text-sm leading-5 font-medium tracking-tight",
            icon: "size-8 rounded-[9px] justify-center"
        }
    },
    defaultVariants: {
        variant: "default",
        size: "default"
    }
});
function Button(param) {
    let { className, variant, size, asChild = false, ...props } = param;
    const Comp = asChild ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Slot"] : "button";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Comp, {
        "data-slot": "button",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])(buttonVariants({
            variant,
            size,
            className
        })),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/button.jsx",
        lineNumber: 49,
        columnNumber: 5
    }, this);
}
_c = Button;
;
var _c;
__turbopack_context__.k.register(_c, "Button");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/sonner.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Toaster",
    ()=>Toaster,
    "toast",
    ()=>toast
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/styled-jsx/style.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$themes$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-themes/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/sonner/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/button.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/x.js [app-client] (ecmascript) <export default as XIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CircleCheck$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/circle-check.js [app-client] (ecmascript) <export default as CircleCheck>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AlertCircleIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/circle-alert.js [app-client] (ecmascript) <export default as AlertCircleIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$info$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InfoIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/info.js [app-client] (ecmascript) <export default as InfoIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LoaderCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/loader-circle.js [app-client] (ecmascript) <export default as LoaderCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
// Composant de notification de succès
const SuccessToast = (param)=>{
    let { message, isMobile } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "max-w-[400px] shadow-lg ".concat(isMobile ? "rounded-2xl px-4 py-4" : "rounded-lg px-4 py-3"),
        style: {
            backgroundColor: "#202020"
        },
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex gap-2 items-center",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "grow ".concat(isMobile ? "text-sm" : "text-sm"),
                    style: {
                        color: "#ffffff"
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CircleCheck$3e$__["CircleCheck"], {
                            className: "me-3 -mt-0.5 inline-flex text-green-600",
                            size: isMobile ? 18 : 16,
                            "aria-hidden": "true"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/sonner.jsx",
                            lineNumber: 20,
                            columnNumber: 9
                        }, ("TURBOPACK compile-time value", void 0)),
                        message
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/sonner.jsx",
                    lineNumber: 16,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                    variant: "ghost",
                    className: "group -my-1.5 -me-2 size-8 shrink-0 p-0 hover:bg-transparent",
                    "aria-label": "Fermer la notification",
                    onClick: ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].dismiss(),
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XIcon$3e$__["XIcon"], {
                        size: 16,
                        className: "opacity-60 transition-opacity group-hover:opacity-100",
                        "aria-hidden": "true",
                        style: {
                            color: "#ffffff"
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/sonner.jsx",
                        lineNumber: 33,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/sonner.jsx",
                    lineNumber: 27,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/ui/sonner.jsx",
            lineNumber: 15,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/ui/sonner.jsx",
        lineNumber: 11,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
};
_c = SuccessToast;
// Composant de notification d'erreur
const ErrorToast = (param)=>{
    let { message, isMobile } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "max-w-[400px] shadow-lg ".concat(isMobile ? "rounded-2xl px-4 py-4" : "rounded-lg px-4 py-3"),
        style: {
            backgroundColor: "#202020"
        },
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex gap-2 items-center",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "grow ".concat(isMobile ? "text-sm" : "text-sm"),
                    style: {
                        color: "#ffffff"
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AlertCircleIcon$3e$__["AlertCircleIcon"], {
                            className: "me-3 -mt-0.5 inline-flex text-red-500",
                            size: isMobile ? 18 : 16,
                            "aria-hidden": "true"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/sonner.jsx",
                            lineNumber: 55,
                            columnNumber: 9
                        }, ("TURBOPACK compile-time value", void 0)),
                        message
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/sonner.jsx",
                    lineNumber: 51,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                    variant: "ghost",
                    className: "group -my-1.5 -me-2 size-8 shrink-0 p-0 hover:bg-transparent",
                    "aria-label": "Fermer la notification",
                    onClick: ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].dismiss(),
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XIcon$3e$__["XIcon"], {
                        size: 16,
                        className: "opacity-60 transition-opacity group-hover:opacity-100",
                        "aria-hidden": "true",
                        style: {
                            color: "#ffffff"
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/sonner.jsx",
                        lineNumber: 68,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/sonner.jsx",
                    lineNumber: 62,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/ui/sonner.jsx",
            lineNumber: 50,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/ui/sonner.jsx",
        lineNumber: 46,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
};
_c1 = ErrorToast;
// Composant de notification d'information
const InfoToast = (param)=>{
    let { message, isMobile } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "max-w-[400px] shadow-lg ".concat(isMobile ? "rounded-2xl px-4 py-4" : "rounded-lg px-4 py-3"),
        style: {
            backgroundColor: "#202020"
        },
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex gap-2 items-center",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "grow ".concat(isMobile ? "text-sm" : "text-sm"),
                    style: {
                        color: "#ffffff"
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$info$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__InfoIcon$3e$__["InfoIcon"], {
                            className: "me-3 -mt-0.5 inline-flex text-blue-500",
                            size: isMobile ? 18 : 16,
                            "aria-hidden": "true"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/sonner.jsx",
                            lineNumber: 90,
                            columnNumber: 9
                        }, ("TURBOPACK compile-time value", void 0)),
                        message
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ui/sonner.jsx",
                    lineNumber: 86,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                    variant: "ghost",
                    className: "group -my-1.5 -me-2 size-8 shrink-0 p-0 hover:bg-transparent",
                    "aria-label": "Fermer la notification",
                    onClick: ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].dismiss(),
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XIcon$3e$__["XIcon"], {
                        size: 16,
                        className: "opacity-60 transition-opacity group-hover:opacity-100",
                        "aria-hidden": "true",
                        style: {
                            color: "#ffffff"
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/sonner.jsx",
                        lineNumber: 103,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/sonner.jsx",
                    lineNumber: 97,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/ui/sonner.jsx",
            lineNumber: 85,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/ui/sonner.jsx",
        lineNumber: 81,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
};
_c2 = InfoToast;
// Composant de notification de chargement
const LoadingToast = (param)=>{
    let { message, isMobile } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "max-w-[400px] shadow-lg ".concat(isMobile ? "rounded-2xl px-4 py-4" : "rounded-lg px-4 py-3"),
        style: {
            backgroundColor: "#202020"
        },
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex gap-2 items-center",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "grow ".concat(isMobile ? "text-sm" : "text-sm"),
                style: {
                    color: "#ffffff"
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LoaderCircle$3e$__["LoaderCircle"], {
                        className: "me-3 -mt-0.5 inline-flex text-white animate-spin",
                        size: isMobile ? 18 : 16,
                        "aria-hidden": "true"
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/sonner.jsx",
                        lineNumber: 125,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    message
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ui/sonner.jsx",
                lineNumber: 121,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/components/ui/sonner.jsx",
            lineNumber: 120,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/ui/sonner.jsx",
        lineNumber: 116,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
};
_c3 = LoadingToast;
// Détection mobile pour les toasts
const checkIsMobile = ()=>"object" !== "undefined" && window.innerWidth < 768;
// Fonctions de toast personnalisées
const toast = {
    success: (message)=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].custom(()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SuccessToast, {
                message: message,
                isMobile: checkIsMobile()
            }, void 0, false, {
                fileName: "[project]/src/components/ui/sonner.jsx",
                lineNumber: 144,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))),
    error: (message)=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].custom(()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ErrorToast, {
                message: message,
                isMobile: checkIsMobile()
            }, void 0, false, {
                fileName: "[project]/src/components/ui/sonner.jsx",
                lineNumber: 148,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))),
    info: (message)=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].custom(()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(InfoToast, {
                message: message,
                isMobile: checkIsMobile()
            }, void 0, false, {
                fileName: "[project]/src/components/ui/sonner.jsx",
                lineNumber: 152,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))),
    warning: (message)=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].custom(()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(InfoToast, {
                message: message,
                isMobile: checkIsMobile()
            }, void 0, false, {
                fileName: "[project]/src/components/ui/sonner.jsx",
                lineNumber: 156,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))),
    loading: (message)=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].custom(()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LoadingToast, {
                message: message,
                isMobile: checkIsMobile()
            }, void 0, false, {
                fileName: "[project]/src/components/ui/sonner.jsx",
                lineNumber: 160,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0)), {
            duration: Infinity
        }),
    // Conserver les méthodes originales de sonner si nécessaire
    dismiss: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].dismiss,
    promise: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].promise
};
const Toaster = (param)=>{
    let { ...props } = param;
    _s();
    const { theme = "system" } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$themes$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"])();
    const [isMobile, setIsMobile] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Toaster.useEffect": ()=>{
            const checkMobile = {
                "Toaster.useEffect.checkMobile": ()=>{
                    setIsMobile(window.innerWidth < 768); // md breakpoint
                }
            }["Toaster.useEffect.checkMobile"];
            checkMobile();
            window.addEventListener("resize", checkMobile);
            return ({
                "Toaster.useEffect": ()=>window.removeEventListener("resize", checkMobile)
            })["Toaster.useEffect"];
        }
    }["Toaster.useEffect"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            isMobile && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                id: "75dab3fcfcbaca22",
                children: ".mobile-toast{transform-origin:top!important;animation:.3s ease-out slideInFromTop!important}@keyframes slideInFromTop{0%{opacity:0;transform:translateY(-100%)scale(.95)}to{opacity:1;transform:translateY(0)scale(1)}}.toaster[data-position=top-center]{width:calc(100% - 32px)!important;max-width:400px!important;top:0!important;left:50%!important;transform:translate(-50%)!important}.mobile-toast [data-sonner-toast]{-webkit-backdrop-filter:blur(20px)!important;backdrop-filter:blur(20px)!important;background:rgba(255,255,255,.9)!important;border:1px solid rgba(0,0,0,.1)!important;border-radius:12px!important;box-shadow:0 10px 40px rgba(0,0,0,.1)!important}.dark .mobile-toast [data-sonner-toast]{background:rgba(28,28,30,.9)!important;border:1px solid rgba(255,255,255,.1)!important}"
            }, void 0, false, void 0, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Toaster"], {
                theme: theme,
                className: "toaster group",
                position: isMobile ? "top-center" : "bottom-right",
                expand: isMobile,
                richColors: false,
                closeButton: false,
                style: {
                    "--normal-bg": "var(--popover)",
                    "--normal-text": "var(--popover-foreground)",
                    "--normal-border": "var(--border)"
                },
                toastOptions: {
                    style: isMobile ? {
                        marginTop: "4px"
                    } : {},
                    className: isMobile ? "mobile-toast" : ""
                },
                ...props
            }, void 0, false, {
                fileName: "[project]/src/components/ui/sonner.jsx",
                lineNumber: 225,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true);
};
_s(Toaster, "AccNjuc+2efmTgA532yqznCbF+M=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$themes$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"]
    ];
});
_c4 = Toaster;
;
var _c, _c1, _c2, _c3, _c4;
__turbopack_context__.k.register(_c, "SuccessToast");
__turbopack_context__.k.register(_c1, "ErrorToast");
__turbopack_context__.k.register(_c2, "InfoToast");
__turbopack_context__.k.register(_c3, "LoadingToast");
__turbopack_context__.k.register(_c4, "Toaster");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/permissions.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ac",
    ()=>ac,
    "accountant",
    ()=>accountant,
    "admin",
    ()=>admin,
    "member",
    ()=>member,
    "owner",
    ()=>owner,
    "statement",
    ()=>statement,
    "viewer",
    ()=>viewer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$better$2d$auth$2f$dist$2f$plugins$2f$access$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/better-auth/dist/plugins/access/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$better$2d$auth$2f$dist$2f$plugins$2f$admin$2f$access$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/better-auth/dist/plugins/admin/access/index.mjs [app-client] (ecmascript)");
;
;
const statement = {
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$better$2d$auth$2f$dist$2f$plugins$2f$admin$2f$access$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultStatements"],
    // ========================================
    // DOCUMENTS COMMERCIAUX
    // ========================================
    quotes: [
        "view",
        "create",
        "edit",
        "delete",
        "approve",
        "convert",
        "send",
        "export"
    ],
    purchaseOrders: [
        "view",
        "create",
        "edit",
        "delete",
        "approve",
        "convert",
        "send",
        "export"
    ],
    invoices: [
        "view",
        "create",
        "edit",
        "delete",
        "approve",
        "send",
        "export",
        "mark-paid",
        "import"
    ],
    creditNotes: [
        "view",
        "create",
        "edit",
        "delete",
        "approve",
        "send"
    ],
    // ========================================
    // FINANCES
    // ========================================
    expenses: [
        "view",
        "create",
        "edit",
        "delete",
        "approve",
        "export",
        "ocr"
    ],
    payments: [
        "view",
        "create",
        "edit",
        "delete",
        "export"
    ],
    // ========================================
    // DONNÉES DE BASE
    // ========================================
    clients: [
        "view",
        "create",
        "edit",
        "delete",
        "export"
    ],
    products: [
        "view",
        "create",
        "edit",
        "delete",
        "export",
        "manage-categories"
    ],
    suppliers: [
        "view",
        "create",
        "edit",
        "delete"
    ],
    // ========================================
    // OUTILS
    // ========================================
    fileTransfers: [
        "view",
        "create",
        "delete",
        "download"
    ],
    sharedDocuments: [
        "view",
        "create",
        "edit",
        "delete",
        "download"
    ],
    kanban: [
        "view",
        "create",
        "edit",
        "delete",
        "assign"
    ],
    signatures: [
        "view",
        "create",
        "edit",
        "delete",
        "set-default"
    ],
    calendar: [
        "view",
        "create",
        "edit",
        "delete"
    ],
    // ========================================
    // RAPPORTS ET ANALYTICS
    // ========================================
    reports: [
        "view",
        "export"
    ],
    analytics: [
        "view",
        "export"
    ],
    // ========================================
    // GESTION ORGANISATION
    // ========================================
    team: [
        "view",
        "invite",
        "remove",
        "change-role"
    ],
    orgSettings: [
        "view",
        "manage"
    ],
    integrations: [
        "view",
        "manage"
    ],
    billing: [
        "view",
        "manage"
    ],
    auditLog: [
        "view",
        "export"
    ]
};
const ac = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$better$2d$auth$2f$dist$2f$plugins$2f$access$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createAccessControl"])(statement);
const owner = ac.newRole({
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$better$2d$auth$2f$dist$2f$plugins$2f$admin$2f$access$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["adminAc"].statements,
    // Documents commerciaux - Accès complet
    quotes: [
        "view",
        "create",
        "edit",
        "delete",
        "approve",
        "convert",
        "send",
        "export"
    ],
    purchaseOrders: [
        "view",
        "create",
        "edit",
        "delete",
        "approve",
        "convert",
        "send",
        "export"
    ],
    invoices: [
        "view",
        "create",
        "edit",
        "delete",
        "approve",
        "send",
        "export",
        "mark-paid",
        "import"
    ],
    creditNotes: [
        "view",
        "create",
        "edit",
        "delete",
        "approve",
        "send"
    ],
    // Finances - Accès complet
    expenses: [
        "view",
        "create",
        "edit",
        "delete",
        "approve",
        "export",
        "ocr"
    ],
    payments: [
        "view",
        "create",
        "edit",
        "delete",
        "export"
    ],
    // Données de base - Accès complet
    clients: [
        "view",
        "create",
        "edit",
        "delete",
        "export"
    ],
    products: [
        "view",
        "create",
        "edit",
        "delete",
        "export",
        "manage-categories"
    ],
    suppliers: [
        "view",
        "create",
        "edit",
        "delete"
    ],
    // Outils - Accès complet
    fileTransfers: [
        "view",
        "create",
        "delete",
        "download"
    ],
    sharedDocuments: [
        "view",
        "create",
        "edit",
        "delete",
        "download"
    ],
    kanban: [
        "view",
        "create",
        "edit",
        "delete",
        "assign"
    ],
    signatures: [
        "view",
        "create",
        "edit",
        "delete",
        "set-default"
    ],
    calendar: [
        "view",
        "create",
        "edit",
        "delete"
    ],
    // Rapports - Accès complet
    reports: [
        "view",
        "export"
    ],
    analytics: [
        "view",
        "export"
    ],
    // Gestion - Accès complet (y compris facturation)
    team: [
        "view",
        "invite",
        "remove",
        "change-role"
    ],
    orgSettings: [
        "view",
        "manage"
    ],
    integrations: [
        "view",
        "manage"
    ],
    billing: [
        "view",
        "manage"
    ],
    auditLog: [
        "view",
        "export"
    ]
});
const admin = ac.newRole({
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$better$2d$auth$2f$dist$2f$plugins$2f$admin$2f$access$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["adminAc"].statements,
    // Documents commerciaux - Accès complet
    quotes: [
        "view",
        "create",
        "edit",
        "delete",
        "approve",
        "convert",
        "send",
        "export"
    ],
    purchaseOrders: [
        "view",
        "create",
        "edit",
        "delete",
        "approve",
        "convert",
        "send",
        "export"
    ],
    invoices: [
        "view",
        "create",
        "edit",
        "delete",
        "approve",
        "send",
        "export",
        "mark-paid",
        "import"
    ],
    creditNotes: [
        "view",
        "create",
        "edit",
        "delete",
        "approve",
        "send"
    ],
    // Finances - Accès complet
    expenses: [
        "view",
        "create",
        "edit",
        "delete",
        "approve",
        "export",
        "ocr"
    ],
    payments: [
        "view",
        "create",
        "edit",
        "delete",
        "export"
    ],
    // Données de base - Accès complet
    clients: [
        "view",
        "create",
        "edit",
        "delete",
        "export"
    ],
    products: [
        "view",
        "create",
        "edit",
        "delete",
        "export",
        "manage-categories"
    ],
    suppliers: [
        "view",
        "create",
        "edit",
        "delete"
    ],
    // Outils - Accès complet
    fileTransfers: [
        "view",
        "create",
        "delete",
        "download"
    ],
    sharedDocuments: [
        "view",
        "create",
        "edit",
        "delete",
        "download"
    ],
    kanban: [
        "view",
        "create",
        "edit",
        "delete",
        "assign"
    ],
    signatures: [
        "view",
        "create",
        "edit",
        "delete",
        "set-default"
    ],
    calendar: [
        "view",
        "create",
        "edit",
        "delete"
    ],
    // Rapports - Accès complet
    reports: [
        "view",
        "export"
    ],
    analytics: [
        "view",
        "export"
    ],
    // Gestion - Accès complet sauf facturation (manage réservé au owner)
    team: [
        "view",
        "invite",
        "remove",
        "change-role"
    ],
    orgSettings: [
        "view",
        "manage"
    ],
    integrations: [
        "view",
        "manage"
    ],
    billing: [
        "view"
    ],
    auditLog: [
        "view",
        "export"
    ]
});
const member = ac.newRole({
    // Documents commerciaux - Création + envoi + export
    quotes: [
        "view",
        "create",
        "send",
        "export"
    ],
    purchaseOrders: [
        "view",
        "create",
        "send",
        "export"
    ],
    invoices: [
        "view",
        "create",
        "send",
        "export",
        "import"
    ],
    creditNotes: [
        "view",
        "create",
        "export"
    ],
    // Finances - Création + export
    expenses: [
        "view",
        "create",
        "ocr",
        "export"
    ],
    payments: [
        "view",
        "create",
        "export"
    ],
    // Données de base - Création + export
    clients: [
        "view",
        "create",
        "export"
    ],
    products: [
        "view",
        "create",
        "export"
    ],
    suppliers: [
        "view",
        "create"
    ],
    // Outils - Utilisation standard
    fileTransfers: [
        "view",
        "create",
        "download"
    ],
    sharedDocuments: [
        "view",
        "create",
        "edit",
        "download"
    ],
    kanban: [
        "view",
        "create",
        "edit",
        "assign"
    ],
    signatures: [
        "view",
        "create",
        "edit",
        "set-default"
    ],
    calendar: [
        "view",
        "create",
        "edit"
    ],
    // Rapports - Lecture + export
    reports: [
        "view",
        "export"
    ],
    analytics: [
        "view",
        "export"
    ],
    // Gestion - Lecture seule
    team: [
        "view"
    ]
});
const viewer = ac.newRole({
    // Documents commerciaux - Lecture seule
    quotes: [
        "view"
    ],
    purchaseOrders: [
        "view"
    ],
    invoices: [
        "view"
    ],
    creditNotes: [
        "view"
    ],
    // Finances - Lecture seule
    expenses: [
        "view"
    ],
    payments: [
        "view"
    ],
    // Données de base - Lecture seule
    clients: [
        "view"
    ],
    products: [
        "view"
    ],
    suppliers: [
        "view"
    ],
    // Outils - Lecture + téléchargement uniquement
    fileTransfers: [
        "view",
        "download"
    ],
    kanban: [
        "view"
    ],
    signatures: [
        "view"
    ],
    calendar: [
        "view"
    ],
    // Rapports - Lecture seule
    reports: [
        "view"
    ],
    analytics: [
        "view"
    ],
    // Gestion - Lecture seule
    team: [
        "view"
    ]
});
const accountant = ac.newRole({
    // Documents commerciaux - Lecture + export
    quotes: [
        "view",
        "export"
    ],
    purchaseOrders: [
        "view",
        "export"
    ],
    invoices: [
        "view",
        "export",
        "mark-paid",
        "import"
    ],
    creditNotes: [
        "view",
        "export"
    ],
    // Finances - Lecture + validation + export
    expenses: [
        "view",
        "approve",
        "export"
    ],
    payments: [
        "view",
        "export"
    ],
    // Données de base - Lecture + export
    clients: [
        "view",
        "export"
    ],
    products: [
        "view",
        "export"
    ],
    suppliers: [
        "view"
    ],
    // Outils - Documents partagés uniquement
    sharedDocuments: [
        "view",
        "create",
        "edit",
        "delete",
        "download"
    ],
    // Rapports - Lecture + export
    reports: [
        "view",
        "export"
    ],
    analytics: [
        "view",
        "export"
    ],
    // Gestion - Lecture seule
    team: [
        "view"
    ],
    auditLog: [
        "view"
    ]
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/auth-client.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "admin",
    ()=>admin,
    "authClient",
    ()=>authClient,
    "forgetPassword",
    ()=>forgetPassword,
    "multiSession",
    ()=>multiSession,
    "organization",
    ()=>organization,
    "resetPassword",
    ()=>resetPassword,
    "signIn",
    ()=>signIn,
    "signOut",
    ()=>signOut,
    "signUp",
    ()=>signUp,
    "twoFactor",
    ()=>twoFactor,
    "updateUser",
    ()=>updateUser,
    "useSession",
    ()=>useSession
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$better$2d$auth$2f$dist$2f$client$2f$react$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/better-auth/dist/client/react/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$better$2d$auth$2f$dist$2f$client$2f$plugins$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/better-auth/dist/client/plugins/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$better$2d$auth$2f$dist$2f$shared$2f$better$2d$auth$2e$Ddw8bVyV$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__t__as__twoFactorClient$3e$__ = __turbopack_context__.i("[project]/node_modules/better-auth/dist/shared/better-auth.Ddw8bVyV.mjs [app-client] (ecmascript) <export t as twoFactorClient>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$better$2d$auth$2f$stripe$2f$dist$2f$client$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@better-auth/stripe/dist/client.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$permissions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/permissions.js [app-client] (ecmascript)");
;
;
;
;
const authClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$better$2d$auth$2f$dist$2f$client$2f$react$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createAuthClient"])({
    baseURL: ("TURBOPACK compile-time value", "http://localhost:3000") || "http://localhost:3000",
    plugins: [
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$better$2d$auth$2f$dist$2f$client$2f$plugins$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["adminClient"])({
            ac: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$permissions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ac"],
            roles: {
                admin: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$permissions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["admin"],
                member: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$permissions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["member"],
                viewer: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$permissions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["viewer"],
                accountant: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$permissions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["accountant"]
            }
        }),
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$better$2d$auth$2f$dist$2f$client$2f$plugins$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["phoneNumberClient"])(),
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$better$2d$auth$2f$dist$2f$shared$2f$better$2d$auth$2e$Ddw8bVyV$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__t__as__twoFactorClient$3e$__["twoFactorClient"])({
            // Redirection automatique vers la page de vérification 2FA
            onTwoFactorRedirect () {
                window.location.href = "/auth/verify-2fa";
            }
        }),
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$better$2d$auth$2f$dist$2f$client$2f$plugins$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["multiSessionClient"])(),
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$better$2d$auth$2f$dist$2f$client$2f$plugins$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["organizationClient"])({
            schema: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$better$2d$auth$2f$dist$2f$client$2f$plugins$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["inferOrgAdditionalFields"])({
                organization: {
                    additionalFields: {
                        // Company basic information
                        companyName: {
                            type: "string"
                        },
                        companyEmail: {
                            type: "string"
                        },
                        companyPhone: {
                            type: "string"
                        },
                        website: {
                            type: "string"
                        },
                        logo: {
                            type: "string"
                        },
                        // Legal information
                        siret: {
                            type: "string"
                        },
                        vatNumber: {
                            type: "string"
                        },
                        rcs: {
                            type: "string"
                        },
                        legalForm: {
                            type: "string"
                        },
                        capitalSocial: {
                            type: "string"
                        },
                        fiscalRegime: {
                            type: "string"
                        },
                        activityCategory: {
                            type: "string"
                        },
                        isVatSubject: {
                            type: "boolean"
                        },
                        hasCommercialActivity: {
                            type: "boolean"
                        },
                        vatRegime: {
                            type: "string"
                        },
                        vatFrequency: {
                            type: "string"
                        },
                        vatMode: {
                            type: "string"
                        },
                        fiscalYearStartDate: {
                            type: "string"
                        },
                        fiscalYearEndDate: {
                            type: "string"
                        },
                        // Address information (flattened)
                        addressStreet: {
                            type: "string"
                        },
                        addressCity: {
                            type: "string"
                        },
                        addressZipCode: {
                            type: "string"
                        },
                        addressCountry: {
                            type: "string"
                        },
                        // Bank details (flattened)
                        bankName: {
                            type: "string"
                        },
                        bankIban: {
                            type: "string"
                        },
                        bankBic: {
                            type: "string"
                        },
                        // Document appearance settings (global defaults)
                        documentTextColor: {
                            type: "string"
                        },
                        documentHeaderTextColor: {
                            type: "string"
                        },
                        documentHeaderBgColor: {
                            type: "string"
                        },
                        // Per-document-type appearance settings
                        quoteTextColor: {
                            type: "string"
                        },
                        quoteHeaderTextColor: {
                            type: "string"
                        },
                        quoteHeaderBgColor: {
                            type: "string"
                        },
                        invoiceTextColor: {
                            type: "string"
                        },
                        invoiceHeaderTextColor: {
                            type: "string"
                        },
                        invoiceHeaderBgColor: {
                            type: "string"
                        },
                        purchaseOrderTextColor: {
                            type: "string"
                        },
                        purchaseOrderHeaderTextColor: {
                            type: "string"
                        },
                        purchaseOrderHeaderBgColor: {
                            type: "string"
                        },
                        // Document notes settings
                        documentHeaderNotes: {
                            type: "string"
                        },
                        documentFooterNotes: {
                            type: "string"
                        },
                        documentTermsAndConditions: {
                            type: "string"
                        },
                        quoteHeaderNotes: {
                            type: "string"
                        },
                        quoteFooterNotes: {
                            type: "string"
                        },
                        quoteTermsAndConditions: {
                            type: "string"
                        },
                        invoiceHeaderNotes: {
                            type: "string"
                        },
                        invoiceFooterNotes: {
                            type: "string"
                        },
                        invoiceTermsAndConditions: {
                            type: "string"
                        },
                        purchaseOrderHeaderNotes: {
                            type: "string"
                        },
                        purchaseOrderFooterNotes: {
                            type: "string"
                        },
                        purchaseOrderTermsAndConditions: {
                            type: "string"
                        },
                        showBankDetails: {
                            type: "boolean"
                        },
                        // Client position in PDF
                        invoiceClientPositionRight: {
                            type: "boolean"
                        },
                        quoteClientPositionRight: {
                            type: "boolean"
                        },
                        purchaseOrderClientPositionRight: {
                            type: "boolean"
                        },
                        // Préfixes de numérotation
                        invoicePrefix: {
                            type: "string"
                        },
                        quotePrefix: {
                            type: "string"
                        },
                        purchaseOrderPrefix: {
                            type: "string"
                        },
                        // Numéros de départ personnalisés
                        invoiceStartNumber: {
                            type: "string"
                        },
                        quoteStartNumber: {
                            type: "string"
                        },
                        purchaseOrderStartNumber: {
                            type: "string"
                        },
                        // Trial system fields (ISO date strings)
                        trialStartDate: {
                            type: "string"
                        },
                        trialEndDate: {
                            type: "string"
                        },
                        isTrialActive: {
                            type: "boolean"
                        },
                        hasUsedTrial: {
                            type: "boolean"
                        }
                    }
                }
            })
        }),
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$better$2d$auth$2f$stripe$2f$dist$2f$client$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stripeClient"])({
            subscription: true
        })
    ]
});
const { signUp, signIn, signOut, updateUser, forgetPassword, resetPassword, useSession, admin, organization, twoFactor, multiSession } = authClient;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/errorMessages.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Système centralisé de gestion des messages d'erreur utilisateur
 * Transforme les erreurs techniques en messages compréhensibles
 */ // Messages d'erreur par catégorie
__turbopack_context__.s([
    "ERROR_MESSAGES",
    ()=>ERROR_MESSAGES,
    "getErrorMessage",
    ()=>getErrorMessage,
    "isCriticalError",
    ()=>isCriticalError,
    "requiresUserAction",
    ()=>requiresUserAction,
    "showErrorToast",
    ()=>showErrorToast
]);
const ERROR_MESSAGES = {
    // Erreurs d'authentification
    AUTH: {
        INVALID_CREDENTIALS: "Email ou mot de passe incorrect",
        ACCOUNT_DISABLED: "Votre compte a été temporairement désactivé. Contactez le support.",
        EMAIL_NOT_VERIFIED: "Veuillez vérifier votre adresse email avant de vous connecter",
        SESSION_EXPIRED: "Votre session a expiré. Veuillez vous reconnecter.",
        UNAUTHORIZED: "Vous n'êtes pas autorisé à effectuer cette action",
        TOKEN_EXPIRED: "Votre session a expiré. Veuillez vous reconnecter.",
        INVALID_TOKEN: "Session invalide. Veuillez vous reconnecter."
    },
    // Erreurs de réseau
    NETWORK: {
        CONNECTION_FAILED: "Impossible de se connecter au serveur. Vérifiez votre connexion internet.",
        SERVER_UNAVAILABLE: "Le serveur est temporairement indisponible. Veuillez réessayer dans quelques instants.",
        TIMEOUT: "La requête a pris trop de temps. Veuillez réessayer.",
        NO_INTERNET: "Aucune connexion internet détectée. Vérifiez votre connexion."
    },
    // Erreurs de validation
    VALIDATION: {
        REQUIRED_FIELD: "Ce champ est obligatoire",
        INVALID_EMAIL: "Veuillez saisir une adresse email valide",
        INVALID_PHONE: "Veuillez saisir un numéro de téléphone valide",
        INVALID_SIRET: "Le SIRET doit contenir exactement 14 chiffres",
        INVALID_VAT: "Le format du numéro de TVA n'est pas valide",
        PASSWORD_TOO_SHORT: "Le mot de passe doit contenir au moins 8 caractères",
        PASSWORDS_DONT_MATCH: "Les mots de passe ne correspondent pas",
        INVALID_DATE: "Veuillez saisir une date valide",
        INVALID_AMOUNT: "Veuillez saisir un montant valide"
    },
    // Erreurs métier - Clients
    CLIENT: {
        NOT_FOUND: "Client introuvable",
        ALREADY_EXISTS: "Un client avec cet email existe déjà",
        CREATION_FAILED: "Impossible de créer le client. Vérifiez les informations saisies.",
        UPDATE_FAILED: "Impossible de modifier le client. Veuillez réessayer.",
        DELETE_FAILED: "Impossible de supprimer le client. Il est peut-être utilisé dans des documents.",
        INVALID_DATA: "Les données du client ne sont pas valides"
    },
    // Erreurs métier - Factures
    INVOICE: {
        NOT_FOUND: "Facture introuvable",
        CREATION_FAILED: "Impossible de créer la facture. Vérifiez les informations saisies.",
        UPDATE_FAILED: "Impossible de modifier la facture. Veuillez réessayer.",
        DELETE_FAILED: "Impossible de supprimer la facture",
        SEND_FAILED: "Impossible d'envoyer la facture par email",
        INVALID_STATUS: "Statut de facture invalide",
        ALREADY_PAID: "Cette facture est déjà marquée comme payée",
        CANNOT_MODIFY_PAID: "Impossible de modifier une facture payée",
        DUPLICATE_NUMBER: "Ce numéro de facture existe déjà",
        INVALID_ITEMS: "Veuillez ajouter au moins un article à la facture"
    },
    // Erreurs métier - Devis
    QUOTE: {
        NOT_FOUND: "Devis introuvable",
        CREATION_FAILED: "Impossible de créer le devis. Vérifiez les informations saisies.",
        UPDATE_FAILED: "Impossible de modifier le devis. Veuillez réessayer.",
        DELETE_FAILED: "Impossible de supprimer le devis",
        SEND_FAILED: "Impossible d'envoyer le devis par email",
        INVALID_STATUS: "Statut de devis invalide",
        ALREADY_CONVERTED: "Ce devis a déjà été converti en facture",
        CONVERSION_FAILED: "Impossible de convertir le devis en facture",
        DUPLICATE_NUMBER: "Ce numéro de devis existe déjà",
        INVALID_ITEMS: "Veuillez ajouter au moins un article au devis"
    },
    // Erreurs métier - Avoirs
    CREDIT_NOTE: {
        NOT_FOUND: "Avoir introuvable",
        CREATION_FAILED: "Impossible de créer l'avoir. Vérifiez les informations saisies.",
        UPDATE_FAILED: "Impossible de modifier l'avoir. Veuillez réessayer.",
        DELETE_FAILED: "Impossible de supprimer l'avoir",
        AMOUNT_EXCEEDS_INVOICE: "Le montant de l'avoir ne peut pas dépasser le montant de la facture",
        LIMIT_REACHED: "La limite d'avoirs pour cette facture est atteinte",
        INVALID_ITEMS: "Veuillez ajouter au moins un article à l'avoir"
    },
    // Erreurs métier - Entreprise
    COMPANY: {
        INFO_INCOMPLETE: "Veuillez compléter les informations de votre entreprise dans les paramètres",
        LEGAL_INFO_MISSING: "Les informations légales de votre entreprise sont incomplètes (SIRET, TVA)",
        UPDATE_FAILED: "Impossible de mettre à jour les informations de l'entreprise",
        INVALID_SIRET: "Le numéro SIRET n'est pas valide",
        INVALID_VAT: "Le numéro de TVA n'est pas valide"
    },
    // Erreurs de fichiers
    FILE: {
        UPLOAD_FAILED: "Échec de l'envoi du fichier. Veuillez réessayer.",
        INVALID_FORMAT: "Format de fichier non supporté",
        TOO_LARGE: "Le fichier est trop volumineux. Taille maximum autorisée : 10 Mo",
        DOWNLOAD_FAILED: "Impossible de télécharger le fichier",
        NOT_FOUND: "Fichier introuvable",
        PROCESSING_FAILED: "Erreur lors du traitement du fichier"
    },
    // Erreurs de paiement
    PAYMENT: {
        FAILED: "Le paiement a échoué. Veuillez réessayer.",
        CARD_DECLINED: "Votre carte a été refusée. Vérifiez vos informations bancaires.",
        INSUFFICIENT_FUNDS: "Fonds insuffisants sur votre compte",
        SUBSCRIPTION_FAILED: "Impossible de traiter l'abonnement. Contactez le support.",
        INVOICE_CREATION_FAILED: "Erreur lors de la création de la facture de paiement"
    },
    // Erreurs génériques
    GENERIC: {
        UNKNOWN_ERROR: "Une erreur inattendue s'est produite. Veuillez réessayer.",
        OPERATION_FAILED: "L'opération a échoué. Veuillez réessayer.",
        ACCESS_DENIED: "Accès refusé. Vous n'avez pas les permissions nécessaires.",
        RESOURCE_NOT_FOUND: "Ressource introuvable",
        INVALID_REQUEST: "Requête invalide. Vérifiez les données saisies.",
        SERVER_ERROR: "Erreur serveur. Veuillez réessayer plus tard."
    }
};
// Patterns d'erreurs techniques à détecter
const ERROR_PATTERNS = {
    // Erreurs GraphQL
    GRAPHQL_VALIDATION: /GraphQL error:|Variable .* of required type|Field .* doesn't exist/i,
    GRAPHQL_NETWORK: /Network error|Failed to fetch/i,
    // Erreurs MongoDB
    MONGO_DUPLICATE: /duplicate key error|E11000/i,
    MONGO_VALIDATION: /ValidationError|Path .* is required/i,
    MONGO_CAST: /CastError|Cast to .* failed/i,
    // Erreurs d'authentification
    AUTH_INVALID: /invalid credentials|wrong password|authentication failed/i,
    AUTH_EXPIRED: /token expired|session expired|jwt expired/i,
    AUTH_UNAUTHORIZED: /unauthorized|access denied|forbidden/i,
    // Erreurs de validation
    VALIDATION_REQUIRED: /required|obligatoire|manquant/i,
    VALIDATION_FORMAT: /invalid format|format invalide|malformed/i,
    VALIDATION_LENGTH: /too short|too long|length/i,
    // Erreurs réseau
    NETWORK_TIMEOUT: /timeout|timed out/i,
    NETWORK_CONNECTION: /connection refused|connection failed|network error/i,
    NETWORK_UNAVAILABLE: /service unavailable|server unavailable/i
};
function getErrorMessage(error) {
    let context = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 'generic';
    if (!error) return ERROR_MESSAGES.GENERIC.UNKNOWN_ERROR;
    const errorMessage = typeof error === 'string' ? error : error.message || '';
    const errorCode = typeof error === 'object' ? error.code : null;
    // Vérifier d'abord les codes d'erreur spécifiques
    if (errorCode) {
        switch(errorCode){
            case 'UNAUTHENTICATED':
            case 'UNAUTHORIZED':
                return ERROR_MESSAGES.AUTH.UNAUTHORIZED;
            case 'COMPANY_INFO_INCOMPLETE':
                return ERROR_MESSAGES.COMPANY.INFO_INCOMPLETE;
            case 'VALIDATION_ERROR':
                return ERROR_MESSAGES.VALIDATION.INVALID_DATA;
            case 'DUPLICATE_KEY':
                return getContextualDuplicateMessage(context);
            case 'NOT_FOUND':
                return getContextualNotFoundMessage(context);
        }
    }
    // Analyser le message d'erreur avec les patterns
    const lowerMessage = errorMessage.toLowerCase();
    // Erreurs spécifiques de confusion entre createInvoice et createQuote
    if (errorMessage.includes("Cannot read properties of undefined (reading 'createInvoice')")) {
        if (context === 'quote') {
            return "Impossible de créer le devis. Veuillez vérifier les informations saisies et réessayer.";
        }
        if (context === 'invoice') {
            return "Impossible de créer la facture. Veuillez vérifier les informations saisies et réessayer.";
        }
        return "Erreur lors de la création du document. Veuillez réessayer.";
    }
    // Erreurs génériques de propriétés undefined
    if (errorMessage.includes("Cannot read properties of undefined")) {
        if (context === 'invoice') {
            return "Impossible de traiter la facture. Veuillez vérifier les informations saisies et réessayer.";
        }
        if (context === 'quote') {
            return "Impossible de traiter le devis. Veuillez vérifier les informations saisies et réessayer.";
        }
        return "Une erreur s'est produite lors du traitement. Veuillez réessayer.";
    }
    // Erreurs d'authentification
    if (ERROR_PATTERNS.AUTH_INVALID.test(errorMessage)) {
        return ERROR_MESSAGES.AUTH.INVALID_CREDENTIALS;
    }
    if (ERROR_PATTERNS.AUTH_EXPIRED.test(errorMessage)) {
        return ERROR_MESSAGES.AUTH.SESSION_EXPIRED;
    }
    if (ERROR_PATTERNS.AUTH_UNAUTHORIZED.test(errorMessage)) {
        return ERROR_MESSAGES.AUTH.UNAUTHORIZED;
    }
    // Erreurs réseau
    if (ERROR_PATTERNS.NETWORK_CONNECTION.test(errorMessage)) {
        return ERROR_MESSAGES.NETWORK.CONNECTION_FAILED;
    }
    if (ERROR_PATTERNS.NETWORK_TIMEOUT.test(errorMessage)) {
        return ERROR_MESSAGES.NETWORK.TIMEOUT;
    }
    if (ERROR_PATTERNS.NETWORK_UNAVAILABLE.test(errorMessage)) {
        return ERROR_MESSAGES.NETWORK.SERVER_UNAVAILABLE;
    }
    // Erreurs de validation spécifiques
    if (lowerMessage.includes('email') && lowerMessage.includes('invalid')) {
        return ERROR_MESSAGES.VALIDATION.INVALID_EMAIL;
    }
    if (lowerMessage.includes('siret')) {
        return ERROR_MESSAGES.VALIDATION.INVALID_SIRET;
    }
    if (lowerMessage.includes('tva') || lowerMessage.includes('vat')) {
        return ERROR_MESSAGES.VALIDATION.INVALID_VAT;
    }
    // Erreurs contextuelles
    if (lowerMessage.includes('existe déjà') || lowerMessage.includes('already exists')) {
        return getContextualDuplicateMessage(context);
    }
    if (lowerMessage.includes('introuvable') || lowerMessage.includes('not found')) {
        return getContextualNotFoundMessage(context);
    }
    // Erreurs de fichiers
    if (lowerMessage.includes('upload') || lowerMessage.includes('téléchargement')) {
        if (lowerMessage.includes('too large') || lowerMessage.includes('trop volumineux')) {
            return ERROR_MESSAGES.FILE.TOO_LARGE;
        }
        return ERROR_MESSAGES.FILE.UPLOAD_FAILED;
    }
    // Messages contextuels par défaut
    return getContextualDefaultMessage(context);
}
/**
 * Retourne un message de duplication contextuel
 */ function getContextualDuplicateMessage(context) {
    switch(context){
        case 'client':
            return ERROR_MESSAGES.CLIENT.ALREADY_EXISTS;
        case 'invoice':
            return ERROR_MESSAGES.INVOICE.DUPLICATE_NUMBER;
        case 'quote':
            return ERROR_MESSAGES.QUOTE.DUPLICATE_NUMBER;
        default:
            return "Cette information existe déjà";
    }
}
/**
 * Retourne un message "non trouvé" contextuel
 */ function getContextualNotFoundMessage(context) {
    switch(context){
        case 'client':
            return ERROR_MESSAGES.CLIENT.NOT_FOUND;
        case 'invoice':
            return ERROR_MESSAGES.INVOICE.NOT_FOUND;
        case 'quote':
            return ERROR_MESSAGES.QUOTE.NOT_FOUND;
        case 'creditNote':
            return ERROR_MESSAGES.CREDIT_NOTE.NOT_FOUND;
        default:
            return ERROR_MESSAGES.GENERIC.RESOURCE_NOT_FOUND;
    }
}
/**
 * Retourne un message d'erreur par défaut contextuel
 */ function getContextualDefaultMessage(context) {
    switch(context){
        case 'client':
            return ERROR_MESSAGES.CLIENT.CREATION_FAILED;
        case 'invoice':
            return ERROR_MESSAGES.INVOICE.CREATION_FAILED;
        case 'quote':
            return ERROR_MESSAGES.QUOTE.CREATION_FAILED;
        case 'creditNote':
            return ERROR_MESSAGES.CREDIT_NOTE.CREATION_FAILED;
        case 'auth':
            return ERROR_MESSAGES.AUTH.INVALID_CREDENTIALS;
        case 'payment':
            return ERROR_MESSAGES.PAYMENT.FAILED;
        case 'file':
            return ERROR_MESSAGES.FILE.UPLOAD_FAILED;
        default:
            return ERROR_MESSAGES.GENERIC.UNKNOWN_ERROR;
    }
}
function showErrorToast(error) {
    let context = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 'generic', toastFunction = arguments.length > 2 ? arguments[2] : void 0;
    const message = getErrorMessage(error, context);
    if (toastFunction) {
        toastFunction(message);
    }
    return message;
}
function isCriticalError(error) {
    if (!error) return false;
    const errorMessage = typeof error === 'string' ? error : error.message || '';
    const errorCode = typeof error === 'object' ? error.code : null;
    // ✅ FIX: Seuls les codes d'expiration de session/token sont critiques
    // UNAUTHENTICATED = pas de session valide (token absent ou expiré)
    // TOKEN_EXPIRED / SESSION_EXPIRED = session explicitement expirée
    // ❌ RETIRÉ: AUTH_UNAUTHORIZED qui matchait "unauthorized|access denied|forbidden"
    // car ces erreurs de PERMISSION (RBAC) ne sont PAS des expirations de session
    const criticalCodes = [
        'UNAUTHENTICATED',
        'TOKEN_EXPIRED',
        'SESSION_EXPIRED'
    ];
    const criticalPatterns = [
        ERROR_PATTERNS.AUTH_EXPIRED
    ];
    return criticalCodes.includes(errorCode) || criticalPatterns.some((pattern)=>pattern.test(errorMessage));
}
function requiresUserAction(error) {
    if (!error) return false;
    const errorMessage = typeof error === 'string' ? error : error.message || '';
    const errorCode = typeof error === 'object' ? error.code : null;
    // Erreurs qui nécessitent une action utilisateur
    const actionRequiredCodes = [
        'COMPANY_INFO_INCOMPLETE',
        'EMAIL_NOT_VERIFIED'
    ];
    const actionRequiredPatterns = [
        /compléter.*informations/i,
        /vérifier.*email/i,
        /configuration.*requise/i
    ];
    return actionRequiredCodes.includes(errorCode) || actionRequiredPatterns.some((pattern)=>pattern.test(errorMessage));
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/apolloClient.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "apolloClient",
    ()=>apolloClient,
    "getApolloClient",
    ()=>getApolloClient,
    "resetOrganizationIdForApollo",
    ()=>resetOrganizationIdForApollo,
    "setOrganizationIdForApollo",
    ()=>setOrganizationIdForApollo
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$core$2f$ApolloClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client/core/ApolloClient.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$cache$2f$inmemory$2f$inMemoryCache$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client/cache/inmemory/inMemoryCache.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$link$2f$core$2f$from$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client/link/core/from.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$link$2f$core$2f$split$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client/link/core/split.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zen$2d$observable$2d$ts$2f$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zen-observable-ts/module.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$link$2f$error$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client/link/error/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$link$2f$context$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client/link/context/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$link$2f$ws$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client/link/ws/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$utilities$2f$graphql$2f$getFromAST$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client/utilities/graphql/getFromAST.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$apollo$2d$upload$2d$client$2f$createUploadLink$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/apollo-upload-client/createUploadLink.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$sonner$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/sonner.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/auth-client.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$errorMessages$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/errorMessages.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
// ==================== GARDE ANTI-BOUCLE POUR LES ERREURS AUTH ====================
let isRedirecting = false;
const forceSessionExpiredRedirect = function() {
    let reason = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "inactivity";
    if (isRedirecting) return;
    isRedirecting = true;
    clearCachedJWT();
    resetOrganizationIdForApollo();
    // Ne pas reset isRedirecting — la page va se recharger via la redirection.
    // Le reset après timeout causait des boucles de redirection si la page
    // n'avait pas encore navigué et que d'autres erreurs auth arrivaient.
    window.location.href = "/auth/session-expired?reason=".concat(reason);
};
// ==================== SYNCHRONISATION ORG ID AVEC useWorkspace ====================
let _workspaceReady = false;
let _confirmedOrgId = null;
function setOrganizationIdForApollo(orgId) {
    _workspaceReady = true;
    _confirmedOrgId = orgId || null;
}
function resetOrganizationIdForApollo() {
    _workspaceReady = false;
    _confirmedOrgId = null;
}
// ==================== JWT ON-DEMAND (mémoire uniquement) ====================
// Le cookie session est scopé au domaine frontend (Vercel).
// Pour les requêtes cross-origin vers le backend, on génère un JWT
// à la volée via /api/auth/token (same-origin = cookie envoyé).
// Le JWT vit uniquement en mémoire — jamais en localStorage (pas de risque XSS).
let _cachedJWT = null;
let _jwtExpiresAt = 0;
let _jwtFetchPromise = null;
const getJWTToken = async ()=>{
    // Si on a un JWT valide en cache (avec 60s de marge), le réutiliser
    if (_cachedJWT && Date.now() < _jwtExpiresAt - 60000) {
        return _cachedJWT;
    }
    // Éviter les appels parallèles (déduplique les fetches simultanés)
    if (_jwtFetchPromise) {
        return _jwtFetchPromise;
    }
    _jwtFetchPromise = (async ()=>{
        try {
            const response = await fetch("/api/auth/token", {
                credentials: "include"
            });
            if (!response.ok) {
                _cachedJWT = null;
                _jwtExpiresAt = 0;
                return null;
            }
            const data = await response.json();
            if (!data.token) {
                _cachedJWT = null;
                _jwtExpiresAt = 0;
                return null;
            }
            _cachedJWT = data.token;
            // Extraire l'expiration du JWT (payload base64)
            try {
                const payload = JSON.parse(atob(data.token.split(".")[1]));
                _jwtExpiresAt = (payload.exp || 0) * 1000;
            } catch (e) {
                // Fallback : cache 5 minutes
                _jwtExpiresAt = Date.now() + 5 * 60 * 1000;
            }
            return _cachedJWT;
        } catch (e) {
            _cachedJWT = null;
            _jwtExpiresAt = 0;
            return null;
        } finally{
            _jwtFetchPromise = null;
        }
    })();
    return _jwtFetchPromise;
};
function clearCachedJWT() {
    _cachedJWT = null;
    _jwtExpiresAt = 0;
}
// DEBUG: Exposer des helpers pour tester l'expiration de session en local
// ⚠️ À SUPPRIMER avant mise en production
if ("TURBOPACK compile-time truthy", 1) {
    window.__debugAuth = {
        // Simule un JWT expiré → la prochaine requête GraphQL déclenchera le retry
        expireJWT: ()=>{
            _cachedJWT = "expired.invalid.token";
            _jwtExpiresAt = Date.now() + 5 * 60 * 1000; // Le cache croit qu'il est valide
            console.log("[DEBUG] JWT remplacé par un token invalide. La prochaine requête GraphQL déclenchera le flow de retry.");
        },
        // Vide le cache JWT → la prochaine requête ira chercher un nouveau JWT
        clearJWT: ()=>{
            clearCachedJWT();
            console.log("[DEBUG] JWT cache vidé.");
        },
        // Affiche l'état actuel du cache JWT
        status: ()=>{
            console.log({
                hasJWT: !!_cachedJWT,
                expiresAt: _jwtExpiresAt ? new Date(_jwtExpiresAt).toISOString() : "none",
                isExpired: _jwtExpiresAt ? Date.now() > _jwtExpiresAt : true,
                isRedirecting,
                isRetryingAuth
            });
        }
    };
}
// ==================== UPLOAD LINK ====================
const uploadLink = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$apollo$2d$upload$2d$client$2f$createUploadLink$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
    uri: ("TURBOPACK compile-time truthy", 1) ? ("TURBOPACK compile-time value", "http://localhost:4000/") + "graphql" : "TURBOPACK unreachable",
    credentials: "include",
    headers: {
        "Apollo-Require-Preflight": "true"
    }
});
// ==================== WEBSOCKET LINK ====================
// WebSocket ne peut pas envoyer de cookies — on utilise le même JWT on-demand
let wsClient = null;
const wsLink = ("TURBOPACK compile-time truthy", 1) ? new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$link$2f$ws$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WebSocketLink"]({
    uri: ("TURBOPACK compile-time value", "ws://localhost:4000/graphql") || "ws://localhost:4000/graphql",
    options: {
        reconnect: true,
        lazy: true,
        connectionParams: async ()=>{
            const isPublicPage = "object" !== "undefined" && window.location.pathname.startsWith("/public/");
            if (isPublicPage) return {};
            const jwtToken = await getJWTToken();
            return {
                authorization: jwtToken ? "Bearer ".concat(jwtToken) : ""
            };
        },
        onError: (error)=>{
            console.error("[WebSocket] Erreur:", error);
        }
    }
}) : "TURBOPACK unreachable";
if (wsLink && "object" !== "undefined") {
    wsClient = wsLink.subscriptionClient;
}
// ==================== AUTH LINK ====================
// JWT on-demand pour l'auth cross-origin (frontend Vercel → backend API).
// Le JWT est récupéré via /api/auth/token (same-origin, cookie envoyé)
// et transmis au backend en Authorization: Bearer.
// Le JWT vit uniquement en mémoire — pas de localStorage.
const authLink = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$link$2f$context$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setContext"])(async (_, param)=>{
    let { headers } = param;
    const requestHeaders = {
        ...headers
    };
    // JWT on-demand pour authentifier les requêtes cross-origin
    const jwtToken = await getJWTToken();
    if (jwtToken) {
        requestHeaders["authorization"] = "Bearer ".concat(jwtToken);
    }
    const organizationId = _workspaceReady ? _confirmedOrgId : null;
    const userRole = _workspaceReady ? localStorage.getItem("user_role") : null;
    if (organizationId) {
        requestHeaders["x-organization-id"] = organizationId;
    }
    if (userRole) {
        requestHeaders["x-user-role"] = userRole;
    }
    return {
        headers: requestHeaders
    };
});
// ==================== ERROR LINK ====================
let isRetryingAuth = false;
// File d'attente pour les operations qui arrivent pendant un retry auth en cours.
// Au lieu d'afficher un toast d'erreur, on les met en attente et on les retry
// une fois que la session a ete verifiee.
let _pendingRetryQueue = [];
const errorLink = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$link$2f$error$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["onError"])((param)=>{
    let { graphQLErrors, networkError, operation, forward } = param;
    if (graphQLErrors) {
        let hasCriticalError = false;
        const processedMessages = new Set();
        // Classifier les erreurs : critiques vs non-critiques
        graphQLErrors.forEach((error)=>{
            var _extensions_exception;
            const { message, extensions } = error;
            const errorCode = (extensions === null || extensions === void 0 ? void 0 : extensions.code) !== "INTERNAL_SERVER_ERROR" ? extensions === null || extensions === void 0 ? void 0 : extensions.code : (extensions === null || extensions === void 0 ? void 0 : (_extensions_exception = extensions.exception) === null || _extensions_exception === void 0 ? void 0 : _extensions_exception.code) || error.code;
            const errorWithCode = {
                message,
                code: errorCode
            };
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$errorMessages$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isCriticalError"])(errorWithCode)) {
                hasCriticalError = true;
            } else {
                if (processedMessages.has(message)) return;
                processedMessages.add(message);
                const skipErrorToast = operation.getContext().skipErrorToast;
                const isBoardNotFound = (message === null || message === void 0 ? void 0 : message.includes("Board not found")) || (message === null || message === void 0 ? void 0 : message.includes("board not found"));
                // Les mutations gerent leurs propres toasts via onError — ne pas doubler
                const definition = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$utilities$2f$graphql$2f$getFromAST$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getMainDefinition"])(operation.query);
                const isMutation = definition.kind === "OperationDefinition" && definition.operation === "mutation";
                if (!skipErrorToast && !isBoardNotFound && !isMutation) {
                    const userMessage = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$errorMessages$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getErrorMessage"])(errorWithCode, "generic");
                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$sonner$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error(userMessage, {
                        duration: 4000
                    });
                }
            }
        });
        // Erreur auth critique pendant un retry en cours :
        // mettre l'operation en file d'attente au lieu d'afficher un toast
        if (hasCriticalError && isRetryingAuth && !isRedirecting) {
            return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zen$2d$observable$2d$ts$2f$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Observable"]((observer)=>{
                _pendingRetryQueue.push({
                    operation,
                    forward,
                    observer
                });
            });
        }
        // Erreur auth critique : retry transparent avec un nouveau JWT
        if (hasCriticalError && !isRetryingAuth && !isRedirecting) {
            const isInitialLoad = operation.getContext().isInitialLoad;
            if (isInitialLoad) return;
            isRetryingAuth = true;
            clearCachedJWT();
            // Retourner un Observable pour retry l'operation au lieu de propager l'erreur
            return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zen$2d$observable$2d$ts$2f$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Observable"]((observer)=>{
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authClient"].getSession().then(async (session)=>{
                    var _session_data;
                    if (!(session === null || session === void 0 ? void 0 : (_session_data = session.data) === null || _session_data === void 0 ? void 0 : _session_data.user)) {
                        // Session reellement expiree — rediriger
                        forceSessionExpiredRedirect("inactivity");
                        observer.error(graphQLErrors[0]);
                        // Vider la file d'attente avec erreur
                        _pendingRetryQueue.forEach((pending)=>pending.observer.error(graphQLErrors[0]));
                        _pendingRetryQueue = [];
                        return;
                    }
                    // Session valide — generer un nouveau JWT et l'injecter dans l'operation.
                    // forward() ne repasse PAS par authLink (il va directement a uploadLink),
                    // donc on doit manuellement mettre a jour les headers ici.
                    const newJWT = await getJWTToken();
                    const oldHeaders = operation.getContext().headers || {};
                    operation.setContext({
                        headers: {
                            ...oldHeaders,
                            authorization: newJWT ? "Bearer ".concat(newJWT) : ""
                        }
                    });
                    forward(operation).subscribe({
                        next: observer.next.bind(observer),
                        error: observer.error.bind(observer),
                        complete: observer.complete.bind(observer)
                    });
                    // Retry toutes les operations en file d'attente avec le nouveau JWT
                    const queue = [
                        ..._pendingRetryQueue
                    ];
                    _pendingRetryQueue = [];
                    queue.forEach((pending)=>{
                        const pendingHeaders = pending.operation.getContext().headers || {};
                        pending.operation.setContext({
                            headers: {
                                ...pendingHeaders,
                                authorization: newJWT ? "Bearer ".concat(newJWT) : ""
                            }
                        });
                        pending.forward(pending.operation).subscribe({
                            next: pending.observer.next.bind(pending.observer),
                            error: pending.observer.error.bind(pending.observer),
                            complete: pending.observer.complete.bind(pending.observer)
                        });
                    });
                }).catch(()=>{
                    // Erreur reseau lors de la verification — ne pas rediriger
                    observer.error(graphQLErrors[0]);
                    // Propager l'erreur aux operations en attente
                    _pendingRetryQueue.forEach((pending)=>pending.observer.error(graphQLErrors[0]));
                    _pendingRetryQueue = [];
                }).finally(()=>{
                    isRetryingAuth = false;
                });
            });
        }
    }
    if (networkError) {
        const msg = networkError.message || "";
        // Erreurs de chunk stale (deploiement Vercel) : ne pas afficher de toast,
        // le listener global dans layout.jsx va auto-reload la page.
        const isChunkError = msg.includes("Unexpected token") || msg.includes("ChunkLoadError") || msg.includes("Loading chunk") || msg.includes("dynamically imported module") || msg.includes("ERR_CONNECTION_CLOSED");
        if (isChunkError) {
            // Silencieux — le auto-reload va s'en charger
            return;
        }
        const userMessage = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$errorMessages$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getErrorMessage"])(networkError, "network");
        if (msg === "Failed to fetch") {
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$sonner$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error(userMessage, {
                duration: 5000,
                description: "Vérifiez votre connexion internet et réessayez"
            });
        } else {
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$sonner$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].warning(userMessage, {
                duration: 4000
            });
        }
    }
});
// ==================== CACHE ====================
const cache = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$cache$2f$inmemory$2f$inMemoryCache$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InMemoryCache"]({
    typePolicies: {
        Board: {
            fields: {
                tasks: {
                    merge () {
                        let existing = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : [], incoming = arguments.length > 1 ? arguments[1] : void 0;
                        return incoming;
                    }
                },
                columns: {
                    merge () {
                        let existing = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : [], incoming = arguments.length > 1 ? arguments[1] : void 0;
                        return incoming;
                    }
                }
            }
        },
        Column: {
            fields: {
                tasks: {
                    merge () {
                        let existing = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : [], incoming = arguments.length > 1 ? arguments[1] : void 0;
                        return incoming;
                    }
                }
            }
        }
    }
});
// ==================== CLIENT ====================
const splitLink = "object" !== "undefined" && wsLink ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$link$2f$core$2f$split$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["split"])((param)=>{
    let { query } = param;
    const definition = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$utilities$2f$graphql$2f$getFromAST$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getMainDefinition"])(query);
    return definition.kind === "OperationDefinition" && definition.operation === "subscription";
}, wsLink, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$link$2f$core$2f$from$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["from"])([
    authLink,
    errorLink,
    uploadLink
])) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$link$2f$core$2f$from$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["from"])([
    authLink,
    errorLink,
    uploadLink
]);
const apolloClient = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$core$2f$ApolloClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ApolloClient"]({
    link: splitLink,
    cache,
    defaultOptions: {
        watchQuery: {
            fetchPolicy: "cache-and-network",
            errorPolicy: "all"
        },
        query: {
            fetchPolicy: "cache-and-network",
            errorPolicy: "all"
        },
        mutate: {
            errorPolicy: "all"
        }
    },
    devtools: {
        enabled: ("TURBOPACK compile-time value", "development") === "development"
    }
});
const getApolloClient = async ()=>apolloClient;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/providers/apollo-provider.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ApolloWrapper",
    ()=>ApolloWrapper
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$context$2f$ApolloProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client/react/context/ApolloProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$apolloClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/apolloClient.js [app-client] (ecmascript)");
"use client";
;
;
;
function ApolloWrapper(param) {
    let { children } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$context$2f$ApolloProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ApolloProvider"], {
        client: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$apolloClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apolloClient"],
        children: children
    }, void 0, false, {
        fileName: "[project]/src/providers/apollo-provider.jsx",
        lineNumber: 7,
        columnNumber: 10
    }, this);
}
_c = ApolloWrapper;
var _c;
__turbopack_context__.k.register(_c, "ApolloWrapper");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/pro-subscription-overlay.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ProSubscriptionOverlay",
    ()=>ProSubscriptionOverlay
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function ProSubscriptionOverlay(param) {
    let { isVisible, onComplete } = param;
    _s();
    const [phase, setPhase] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("enter");
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ProSubscriptionOverlay.useEffect": ()=>{
            if (isVisible) {
                setPhase("enter");
                // Phase de sortie après l'animation complète
                const exitTimer = setTimeout({
                    "ProSubscriptionOverlay.useEffect.exitTimer": ()=>{
                        setPhase("exit");
                    }
                }["ProSubscriptionOverlay.useEffect.exitTimer"], 2800);
                // Callback de fin - fermer l'overlay
                const completeTimer = setTimeout({
                    "ProSubscriptionOverlay.useEffect.completeTimer": ()=>{
                        onComplete === null || onComplete === void 0 ? void 0 : onComplete();
                    }
                }["ProSubscriptionOverlay.useEffect.completeTimer"], 3300);
                return ({
                    "ProSubscriptionOverlay.useEffect": ()=>{
                        clearTimeout(exitTimer);
                        clearTimeout(completeTimer);
                    }
                })["ProSubscriptionOverlay.useEffect"];
            }
        }
    }["ProSubscriptionOverlay.useEffect"], [
        isVisible,
        onComplete
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
        children: isVisible && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                    className: "fixed inset-0 z-[9998] bg-black/80",
                    initial: {
                        opacity: 0
                    },
                    animate: {
                        opacity: 1
                    },
                    exit: {
                        opacity: 0
                    },
                    transition: {
                        duration: 0.3
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/pro-subscription-overlay.jsx",
                    lineNumber: 36,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                    className: "fixed inset-0 z-[9999] flex items-center justify-center",
                    initial: {
                        opacity: 0
                    },
                    animate: {
                        opacity: 1
                    },
                    exit: {
                        opacity: 0
                    },
                    transition: {
                        duration: 0.4
                    },
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                        className: "relative z-10 flex flex-col items-center text-center",
                        initial: {
                            scale: 0.9,
                            opacity: 0
                        },
                        animate: {
                            scale: phase === "exit" ? 0.95 : 1,
                            opacity: phase === "exit" ? 0 : 1
                        },
                        transition: {
                            duration: 0.5,
                            ease: "easeOut"
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                                initial: {
                                    scale: 0.8,
                                    opacity: 0
                                },
                                animate: {
                                    scale: 1,
                                    opacity: 1
                                },
                                transition: {
                                    type: "spring",
                                    stiffness: 200,
                                    damping: 20,
                                    duration: 0.5
                                },
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                    width: "120",
                                    height: "120",
                                    viewBox: "0 0 120 120",
                                    fill: "none",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].circle, {
                                            cx: "60",
                                            cy: "60",
                                            r: "54",
                                            stroke: "url(#gradient)",
                                            strokeWidth: "4",
                                            strokeLinecap: "round",
                                            fill: "none",
                                            initial: {
                                                pathLength: 0
                                            },
                                            animate: {
                                                pathLength: 1
                                            },
                                            transition: {
                                                duration: 1.2,
                                                ease: [
                                                    0.4,
                                                    0,
                                                    0.2,
                                                    1
                                                ]
                                            }
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/pro-subscription-overlay.jsx",
                                            lineNumber: 84,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].path, {
                                            d: "M 35 60 L 52 77 L 85 44",
                                            stroke: "#ffffff",
                                            strokeWidth: "5",
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            fill: "none",
                                            initial: {
                                                pathLength: 0
                                            },
                                            animate: {
                                                pathLength: 1
                                            },
                                            transition: {
                                                duration: 0.6,
                                                delay: 0.8,
                                                ease: [
                                                    0.4,
                                                    0,
                                                    0.2,
                                                    1
                                                ]
                                            }
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/pro-subscription-overlay.jsx",
                                            lineNumber: 101,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("linearGradient", {
                                                id: "gradient",
                                                x1: "0%",
                                                y1: "0%",
                                                x2: "100%",
                                                y2: "100%",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                                                        offset: "0%",
                                                        stopColor: "#5a50ff"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/pro-subscription-overlay.jsx",
                                                        lineNumber: 126,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                                                        offset: "50%",
                                                        stopColor: "#7c6dff"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/pro-subscription-overlay.jsx",
                                                        lineNumber: 127,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                                                        offset: "100%",
                                                        stopColor: "#9d8aff"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/pro-subscription-overlay.jsx",
                                                        lineNumber: 128,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/pro-subscription-overlay.jsx",
                                                lineNumber: 119,
                                                columnNumber: 21
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/pro-subscription-overlay.jsx",
                                            lineNumber: 118,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/pro-subscription-overlay.jsx",
                                    lineNumber: 76,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/pro-subscription-overlay.jsx",
                                lineNumber: 66,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].p, {
                                className: "mt-6 text-white text-xl font-medium tracking-tight",
                                initial: {
                                    opacity: 0,
                                    y: 10
                                },
                                animate: {
                                    opacity: 1,
                                    y: 0
                                },
                                transition: {
                                    delay: 1.5,
                                    duration: 0.5,
                                    ease: "easeOut"
                                },
                                children: "Vous êtes prêt !"
                            }, void 0, false, {
                                fileName: "[project]/src/components/pro-subscription-overlay.jsx",
                                lineNumber: 135,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/pro-subscription-overlay.jsx",
                        lineNumber: 53,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/pro-subscription-overlay.jsx",
                    lineNumber: 45,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true)
    }, void 0, false, {
        fileName: "[project]/src/components/pro-subscription-overlay.jsx",
        lineNumber: 32,
        columnNumber: 5
    }, this);
}
_s(ProSubscriptionOverlay, "Yi18fL4kTnZZg1TFB+16aUQ3Ur4=");
_c = ProSubscriptionOverlay;
var _c;
__turbopack_context__.k.register(_c, "ProSubscriptionOverlay");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/bank-sync-overlay.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BankSyncOverlay",
    ()=>BankSyncOverlay
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LoaderCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/loader-circle.js [app-client] (ecmascript) <export default as LoaderCircle>");
"use client";
;
;
;
function BankSyncOverlay(param) {
    let { isVisible, message = "Synchronisation de vos comptes bancaires..." } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
        children: isVisible && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                    className: "fixed inset-0 z-[9998] bg-black/80",
                    initial: {
                        opacity: 0
                    },
                    animate: {
                        opacity: 1
                    },
                    exit: {
                        opacity: 0
                    },
                    transition: {
                        duration: 0.3
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/bank-sync-overlay.jsx",
                    lineNumber: 15,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                    className: "fixed inset-0 z-[9999] flex items-center justify-center",
                    initial: {
                        opacity: 0
                    },
                    animate: {
                        opacity: 1
                    },
                    exit: {
                        opacity: 0
                    },
                    transition: {
                        duration: 0.4
                    },
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                        className: "flex flex-col items-center text-center",
                        initial: {
                            scale: 0.9,
                            opacity: 0
                        },
                        animate: {
                            scale: 1,
                            opacity: 1
                        },
                        exit: {
                            scale: 0.95,
                            opacity: 0
                        },
                        transition: {
                            duration: 0.5,
                            ease: "easeOut"
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                                initial: {
                                    scale: 0.8,
                                    opacity: 0
                                },
                                animate: {
                                    scale: 1,
                                    opacity: 1
                                },
                                transition: {
                                    duration: 0.4,
                                    ease: "easeOut"
                                },
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LoaderCircle$3e$__["LoaderCircle"], {
                                    className: "size-9 text-white animate-spin",
                                    strokeWidth: 0.5
                                }, void 0, false, {
                                    fileName: "[project]/src/components/bank-sync-overlay.jsx",
                                    lineNumber: 44,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/bank-sync-overlay.jsx",
                                lineNumber: 39,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].p, {
                                className: "mt-6 text-white text-xl font-medium tracking-tight",
                                initial: {
                                    opacity: 0,
                                    y: 10
                                },
                                animate: {
                                    opacity: 1,
                                    y: 0
                                },
                                transition: {
                                    delay: 0.3,
                                    duration: 0.5,
                                    ease: "easeOut"
                                },
                                children: message
                            }, void 0, false, {
                                fileName: "[project]/src/components/bank-sync-overlay.jsx",
                                lineNumber: 51,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].p, {
                                className: "mt-2 text-gray-400 text-sm",
                                initial: {
                                    opacity: 0
                                },
                                animate: {
                                    opacity: 1
                                },
                                transition: {
                                    delay: 0.5,
                                    duration: 0.4
                                },
                                children: "Veuillez patienter quelques instants"
                            }, void 0, false, {
                                fileName: "[project]/src/components/bank-sync-overlay.jsx",
                                lineNumber: 61,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/bank-sync-overlay.jsx",
                        lineNumber: 31,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/bank-sync-overlay.jsx",
                    lineNumber: 24,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true)
    }, void 0, false, {
        fileName: "[project]/src/components/bank-sync-overlay.jsx",
        lineNumber: 11,
        columnNumber: 5
    }, this);
}
_c = BankSyncOverlay;
var _c;
__turbopack_context__.k.register(_c, "BankSyncOverlay");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/dev-animation-trigger.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DevAnimationTrigger",
    ()=>DevAnimationTrigger
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Bug$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/bug.js [app-client] (ecmascript) <export default as Bug>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$credit$2d$card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CreditCard$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/credit-card.js [app-client] (ecmascript) <export default as CreditCard>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$landmark$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Landmark$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/landmark.js [app-client] (ecmascript) <export default as Landmark>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$up$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronUp$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-up.js [app-client] (ecmascript) <export default as ChevronUp>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$pro$2d$subscription$2d$overlay$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/pro-subscription-overlay.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$bank$2d$sync$2d$overlay$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/bank-sync-overlay.jsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
function DevAnimationTrigger() {
    _s();
    const [open, setOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [showProOverlay, setShowProOverlay] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [showBankSync, setShowBankSync] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    const handleProAnimation = ()=>{
        setOpen(false);
        setShowProOverlay(true);
    };
    const handleBankSync = ()=>{
        setOpen(false);
        setShowBankSync(true);
        setTimeout(()=>setShowBankSync(false), 3000);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed bottom-4 right-4 z-[9000]",
                children: [
                    open && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-2 rounded-xl border border-[#EEEFF1] bg-white shadow-lg overflow-hidden w-56",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: handleProAnimation,
                                className: "flex items-center gap-3 w-full px-4 py-3 text-sm text-[#46464A] hover:bg-[#F8F9FA] transition-colors cursor-pointer",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$credit$2d$card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CreditCard$3e$__["CreditCard"], {
                                        className: "size-4 text-[#5A50FF]"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/dev-animation-trigger.jsx",
                                        lineNumber: 36,
                                        columnNumber: 15
                                    }, this),
                                    "Animation Stripe"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/dev-animation-trigger.jsx",
                                lineNumber: 32,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "h-px bg-[#EEEFF1]"
                            }, void 0, false, {
                                fileName: "[project]/src/components/dev-animation-trigger.jsx",
                                lineNumber: 39,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: handleBankSync,
                                className: "flex items-center gap-3 w-full px-4 py-3 text-sm text-[#46464A] hover:bg-[#F8F9FA] transition-colors cursor-pointer",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$landmark$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Landmark$3e$__["Landmark"], {
                                        className: "size-4 text-[#5A50FF]"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/dev-animation-trigger.jsx",
                                        lineNumber: 44,
                                        columnNumber: 15
                                    }, this),
                                    "Animation Bancaire"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/dev-animation-trigger.jsx",
                                lineNumber: 40,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/dev-animation-trigger.jsx",
                        lineNumber: 31,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>setOpen(!open),
                        className: "flex items-center justify-center size-10 rounded-full bg-[#5A50FF] text-white shadow-lg hover:bg-[#4a40ef] transition-colors cursor-pointer",
                        children: open ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$up$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronUp$3e$__["ChevronUp"], {
                            className: "size-4"
                        }, void 0, false, {
                            fileName: "[project]/src/components/dev-animation-trigger.jsx",
                            lineNumber: 55,
                            columnNumber: 19
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Bug$3e$__["Bug"], {
                            className: "size-4"
                        }, void 0, false, {
                            fileName: "[project]/src/components/dev-animation-trigger.jsx",
                            lineNumber: 55,
                            columnNumber: 54
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/dev-animation-trigger.jsx",
                        lineNumber: 51,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/dev-animation-trigger.jsx",
                lineNumber: 28,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$pro$2d$subscription$2d$overlay$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProSubscriptionOverlay"], {
                isVisible: showProOverlay,
                onComplete: ()=>setShowProOverlay(false)
            }, void 0, false, {
                fileName: "[project]/src/components/dev-animation-trigger.jsx",
                lineNumber: 59,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$bank$2d$sync$2d$overlay$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BankSyncOverlay"], {
                isVisible: showBankSync
            }, void 0, false, {
                fileName: "[project]/src/components/dev-animation-trigger.jsx",
                lineNumber: 63,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(DevAnimationTrigger, "g2e1u5pCoZ1dAGJudoa4W//juMo=");
_c = DevAnimationTrigger;
var _c;
__turbopack_context__.k.register(_c, "DevAnimationTrigger");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_34e50fca._.js.map