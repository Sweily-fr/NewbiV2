(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/ui/separator.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Separator",
    ()=>Separator
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$separator$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-separator/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.js [app-client] (ecmascript)");
"use client";
;
;
;
function Separator(param) {
    let { className, orientation = "horizontal", decorative = true, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$separator$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Root"], {
        "data-slot": "separator",
        decorative: decorative,
        orientation: orientation,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("bg-border shrink-0 data-[orientation=horizontal]:h-px data-[orientation=horizontal]:w-full data-[orientation=vertical]:h-full data-[orientation=vertical]:w-px", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/separator.tsx",
        lineNumber: 15,
        columnNumber: 5
    }, this);
}
_c = Separator;
;
var _c;
__turbopack_context__.k.register(_c, "Separator");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/submit-button.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SubmitButton",
    ()=>SubmitButton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react-dom/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/button.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LoaderCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/loader-circle.js [app-client] (ecmascript) <export default as LoaderCircle>");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
const SubmitButton = (props)=>{
    _s();
    const { pending } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFormStatus"])();
    const { children, isLoading, ...rest } = props;
    // Utiliser soit isLoading (pour react-hook-form) soit pending (pour React Server Actions)
    const loading = isLoading || pending;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
        ...rest,
        disabled: props.disabled || loading,
        className: "".concat(props.className || "", " relative"),
        children: [
            loading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "absolute inset-0 flex items-center justify-center",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LoaderCircle$3e$__["LoaderCircle"], {
                    className: "h-4 w-4 animate-spin"
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/submit-button.jsx",
                    lineNumber: 18,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/components/ui/submit-button.jsx",
                lineNumber: 17,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: loading ? "invisible" : "",
                children: children
            }, void 0, false, {
                fileName: "[project]/src/components/ui/submit-button.jsx",
                lineNumber: 21,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/submit-button.jsx",
        lineNumber: 15,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(SubmitButton, "ChN3pfldoIBH4a0f1nBGB7ED+p0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFormStatus"]
    ];
});
_c = SubmitButton;
;
var _c;
__turbopack_context__.k.register(_c, "SubmitButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/label.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Label",
    ()=>Label
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$label$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Label$3e$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-label/dist/index.mjs [app-client] (ecmascript) <export * as Label>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.js [app-client] (ecmascript)");
"use client";
;
;
;
function Label(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$label$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Label$3e$__["Label"].Root, {
        "data-slot": "label",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("text-foreground text-sm leading-4 font-medium select-none group-data-[disabled=true]:pointer-events-none group-data-[disabled=true]:opacity-50 peer-disabled:cursor-not-allowed peer-disabled:opacity-50", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/label.tsx",
        lineNumber: 13,
        columnNumber: 5
    }, this);
}
_c = Label;
;
var _c;
__turbopack_context__.k.register(_c, "Label");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/input.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Input",
    ()=>Input,
    "InputEmail",
    ()=>InputEmail,
    "InputEndAddOn",
    ()=>InputEndAddOn,
    "InputLoader",
    ()=>InputLoader,
    "InputPassword",
    ()=>InputPassword,
    "InputPhone",
    ()=>InputPhone,
    "inputVariants",
    ()=>inputVariants
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__EyeIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/eye.js [app-client] (ecmascript) <export default as EyeIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2d$off$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__EyeOffIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/eye-off.js [app-client] (ecmascript) <export default as EyeOffIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$phone$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PhoneIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/phone.js [app-client] (ecmascript) <export default as PhoneIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$at$2d$sign$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AtSignIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/at-sign.js [app-client] (ecmascript) <export default as AtSignIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LoaderCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/loader-circle.js [app-client] (ecmascript) <export default as LoaderCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__SearchIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/search.js [app-client] (ecmascript) <export default as SearchIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/label.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature(), _s3 = __turbopack_context__.k.signature(), _s4 = __turbopack_context__.k.signature();
;
;
;
;
;
;
const inputVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("outline-none bg-transparent m-0 flex w-full tracking-[-0.01em] font-medium text-[#242529] placeholder:text-[rgba(0,0,0,0.35)] disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50 dark:text-white dark:placeholder:text-[rgba(255,255,255,0.35)]", {
    variants: {
        variant: {
            default: "border border-[#e6e7ea] hover:border-[#D1D3D8] dark:border-[#2E2E32] dark:hover:border-[#44444A] h-8 rounded-[9px] px-2.5 transition-[border] duration-[80ms] ease-in-out",
            ghost: "border-none p-0 flex-1 h-full"
        },
        size: {
            default: "text-sm leading-5",
            sm: "text-xs leading-4",
            lg: "text-base leading-6"
        }
    },
    defaultVariants: {
        variant: "default",
        size: "default"
    }
});
const Input = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"]((param, ref)=>{
    let { className, variant, size, type = "text", ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
        ref: ref,
        type: type,
        "data-slot": "input",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])(inputVariants({
            variant,
            size,
            className
        })),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/input.jsx",
        lineNumber: 41,
        columnNumber: 7
    }, ("TURBOPACK compile-time value", void 0));
});
_c = Input;
Input.displayName = "Input";
function InputPassword(param) {
    let { className, label, placeholder, ...props } = param;
    _s();
    const id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])();
    const [isVisible, setIsVisible] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const toggleVisibility = ()=>setIsVisible((prevState)=>!prevState);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "*:not-first:mt-2",
        children: [
            label && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                htmlFor: id,
                children: label
            }, void 0, false, {
                fileName: "[project]/src/components/ui/input.jsx",
                lineNumber: 61,
                columnNumber: 17
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Input, {
                        id: id,
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("pe-9", className),
                        placeholder: placeholder,
                        type: isVisible ? "text" : "password",
                        ...props
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/input.jsx",
                        lineNumber: 63,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: "text-[rgba(0,0,0,0.35)] hover:text-[#242529] dark:text-[rgba(255,255,255,0.35)] dark:hover:text-white absolute inset-y-0 end-0 flex h-full w-9 items-center justify-center rounded-e-[9px] transition-colors outline-none focus:z-10 disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50",
                        type: "button",
                        onClick: toggleVisibility,
                        "aria-label": isVisible ? "Masquer le mot de passe" : "Afficher le mot de passe",
                        "aria-pressed": isVisible,
                        "aria-controls": id,
                        children: isVisible ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2d$off$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__EyeOffIcon$3e$__["EyeOffIcon"], {
                            size: 16,
                            "aria-hidden": "true"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/input.jsx",
                            lineNumber: 81,
                            columnNumber: 13
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__EyeIcon$3e$__["EyeIcon"], {
                            size: 16,
                            "aria-hidden": "true"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/input.jsx",
                            lineNumber: 83,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/input.jsx",
                        lineNumber: 70,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ui/input.jsx",
                lineNumber: 62,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/input.jsx",
        lineNumber: 60,
        columnNumber: 5
    }, this);
}
_s(InputPassword, "C12BMw8Iv3tohZ5yEnZ9kw/8AHg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"]
    ];
});
_c1 = InputPassword;
function InputEmail(param) {
    let { className, label, placeholder, ...props } = param;
    _s1();
    const id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "*:not-first:mt-2",
        children: [
            label && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                htmlFor: id,
                children: label
            }, void 0, false, {
                fileName: "[project]/src/components/ui/input.jsx",
                lineNumber: 95,
                columnNumber: 17
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Input, {
                        id: id,
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("peer ps-9", className),
                        placeholder: placeholder,
                        type: "email",
                        ...props
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/input.jsx",
                        lineNumber: 97,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-[rgba(0,0,0,0.35)] dark:text-[rgba(255,255,255,0.35)] pointer-events-none absolute inset-y-0 start-0 flex items-center justify-center ps-3 peer-disabled:opacity-50",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$at$2d$sign$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AtSignIcon$3e$__["AtSignIcon"], {
                            size: 16,
                            "aria-hidden": "true"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/input.jsx",
                            lineNumber: 105,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/input.jsx",
                        lineNumber: 104,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ui/input.jsx",
                lineNumber: 96,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/input.jsx",
        lineNumber: 94,
        columnNumber: 5
    }, this);
}
_s1(InputEmail, "WhsuKpSQZEWeFcB7gWlfDRQktoQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"]
    ];
});
_c2 = InputEmail;
function InputPhone(param) {
    let { className, label, placeholder = "Numéro de téléphone", ...props } = param;
    _s2();
    const id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "*:not-first:mt-2",
        children: [
            label && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                htmlFor: id,
                children: label
            }, void 0, false, {
                fileName: "[project]/src/components/ui/input.jsx",
                lineNumber: 122,
                columnNumber: 17
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Input, {
                        id: id,
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("peer ps-9", className),
                        placeholder: placeholder,
                        type: "tel",
                        ...props
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/input.jsx",
                        lineNumber: 124,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-[rgba(0,0,0,0.35)] dark:text-[rgba(255,255,255,0.35)] pointer-events-none absolute inset-y-0 start-0 flex items-center justify-center ps-3 peer-disabled:opacity-50",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$phone$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PhoneIcon$3e$__["PhoneIcon"], {
                            size: 16,
                            "aria-hidden": "true"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/input.jsx",
                            lineNumber: 132,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/input.jsx",
                        lineNumber: 131,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ui/input.jsx",
                lineNumber: 123,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/input.jsx",
        lineNumber: 121,
        columnNumber: 5
    }, this);
}
_s2(InputPhone, "WhsuKpSQZEWeFcB7gWlfDRQktoQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"]
    ];
});
_c3 = InputPhone;
function InputEndAddOn(param) {
    let { className, label, placeholder, ...props } = param;
    _s3();
    const id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "*:not-first:mt-2",
        children: [
            label && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                htmlFor: id,
                children: label
            }, void 0, false, {
                fileName: "[project]/src/components/ui/input.jsx",
                lineNumber: 143,
                columnNumber: 17
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "border border-[#e6e7ea] dark:border-[#2E2E32] bg-transparent text-[#242529] dark:text-white -z-10 inline-flex items-center rounded-s-[9px] border-e-0 px-3 text-sm font-medium",
                        children: "https://"
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/input.jsx",
                        lineNumber: 145,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Input, {
                        id: id,
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("rounded-s-none border-s-0", className),
                        placeholder: placeholder,
                        type: "text",
                        ...props
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/input.jsx",
                        lineNumber: 148,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ui/input.jsx",
                lineNumber: 144,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/input.jsx",
        lineNumber: 142,
        columnNumber: 5
    }, this);
}
_s3(InputEndAddOn, "WhsuKpSQZEWeFcB7gWlfDRQktoQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"]
    ];
});
_c4 = InputEndAddOn;
function InputLoader(param) {
    let { className, label, placeholder, ...props } = param;
    _s4();
    const id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])();
    const [inputValue, setInputValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "InputLoader.useEffect": ()=>{
            if (inputValue) {
                setIsLoading(true);
                const timer = setTimeout({
                    "InputLoader.useEffect.timer": ()=>{
                        setIsLoading(false);
                    }
                }["InputLoader.useEffect.timer"], 500);
                return ({
                    "InputLoader.useEffect": ()=>clearTimeout(timer)
                })["InputLoader.useEffect"];
            }
            setIsLoading(false);
        }
    }["InputLoader.useEffect"], [
        inputValue
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "*:not-first:mt-2",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                htmlFor: id,
                children: label
            }, void 0, false, {
                fileName: "[project]/src/components/ui/input.jsx",
                lineNumber: 178,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Input, {
                        id: id,
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("peer ps-9", className),
                        placeholder: placeholder,
                        type: "search",
                        value: inputValue,
                        onChange: (e)=>setInputValue(e.target.value)
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/input.jsx",
                        lineNumber: 180,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-[rgba(0,0,0,0.35)] dark:text-[rgba(255,255,255,0.35)] pointer-events-none absolute inset-y-0 start-0 flex items-center justify-center ps-3 peer-disabled:opacity-50",
                        children: isLoading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LoaderCircle$3e$__["LoaderCircle"], {
                            className: "animate-spin",
                            size: 16,
                            role: "status",
                            "aria-label": "Loading..."
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/input.jsx",
                            lineNumber: 190,
                            columnNumber: 13
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__SearchIcon$3e$__["SearchIcon"], {
                            size: 16,
                            "aria-hidden": "true"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/input.jsx",
                            lineNumber: 197,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/input.jsx",
                        lineNumber: 188,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ui/input.jsx",
                lineNumber: 179,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/input.jsx",
        lineNumber: 177,
        columnNumber: 5
    }, this);
}
_s4(InputLoader, "v1LfJkBREdwQ2Uci8a2usuJxJd8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"]
    ];
});
_c5 = InputLoader;
;
var _c, _c1, _c2, _c3, _c4, _c5;
__turbopack_context__.k.register(_c, "Input");
__turbopack_context__.k.register(_c1, "InputPassword");
__turbopack_context__.k.register(_c2, "InputEmail");
__turbopack_context__.k.register(_c3, "InputPhone");
__turbopack_context__.k.register(_c4, "InputEndAddOn");
__turbopack_context__.k.register(_c5, "InputLoader");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/password-strength-input.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PasswordStrengthInput",
    ()=>PasswordStrengthInput
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/check.js [app-client] (ecmascript) <export default as CheckIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__EyeIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/eye.js [app-client] (ecmascript) <export default as EyeIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2d$off$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__EyeOffIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/eye-off.js [app-client] (ecmascript) <export default as EyeOffIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/x.js [app-client] (ecmascript) <export default as XIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$input$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/input.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/label.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
const PasswordStrengthInput = /*#__PURE__*/ _s((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = _s((param, ref)=>{
    let { label = "Mot de passe", value, onChange, error, ...props } = param;
    _s();
    const id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])();
    const [isVisible, setIsVisible] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const toggleVisibility = ()=>setIsVisible((prevState)=>!prevState);
    const checkStrength = (pass)=>{
        const requirements = [
            {
                regex: /.{8,}/,
                text: "Au moins 8 caractères"
            },
            {
                regex: /[0-9]/,
                text: "Au moins 1 chiffre"
            },
            {
                regex: /[a-z]/,
                text: "Au moins 1 minuscule"
            },
            {
                regex: /[A-Z]/,
                text: "Au moins 1 majuscule"
            }
        ];
        return requirements.map((req)=>({
                met: req.regex.test(pass),
                text: req.text
            }));
    };
    const strength = checkStrength(value || "");
    const strengthScore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "PasswordStrengthInput.useMemo[strengthScore]": ()=>{
            return strength.filter({
                "PasswordStrengthInput.useMemo[strengthScore]": (req)=>req.met
            }["PasswordStrengthInput.useMemo[strengthScore]"]).length;
        }
    }["PasswordStrengthInput.useMemo[strengthScore]"], [
        strength
    ]);
    const getStrengthColor = (score)=>{
        if (score === 0) return "bg-border";
        if (score <= 1) return "bg-red-500";
        if (score <= 2) return "bg-orange-500";
        if (score === 3) return "bg-amber-500";
        return "bg-[#5a50ff]";
    };
    const getStrengthText = (score)=>{
        if (score === 0) return "Entrez un mot de passe";
        if (score <= 2) return "Mot de passe faible";
        if (score === 3) return "Mot de passe moyen";
        return "Mot de passe fort";
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                htmlFor: id,
                className: "text-sm font-medium text-foreground dark:text-foreground",
                children: label
            }, void 0, false, {
                fileName: "[project]/src/components/ui/password-strength-input.jsx",
                lineNumber: 53,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative mt-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$input$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"], {
                        ref: ref,
                        id: id,
                        className: "pe-9",
                        placeholder: "Saisissez votre mot de passe",
                        type: isVisible ? "text" : "password",
                        value: value,
                        onChange: onChange,
                        "aria-describedby": "".concat(id, "-description"),
                        ...props
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/password-strength-input.jsx",
                        lineNumber: 60,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: "text-muted-foreground/80 hover:text-foreground focus-visible:border-ring focus-visible:ring-ring/50 absolute inset-y-0 end-0 flex h-full w-9 items-center justify-center rounded-e-md transition-[color,box-shadow] outline-none focus:z-10 focus-visible:ring-[3px] disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50",
                        type: "button",
                        onClick: toggleVisibility,
                        "aria-label": isVisible ? "Masquer le mot de passe" : "Afficher le mot de passe",
                        "aria-pressed": isVisible,
                        "aria-controls": "password",
                        children: isVisible ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2d$off$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__EyeOffIcon$3e$__["EyeOffIcon"], {
                            size: 16,
                            "aria-hidden": "true"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/password-strength-input.jsx",
                            lineNumber: 82,
                            columnNumber: 15
                        }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__EyeIcon$3e$__["EyeIcon"], {
                            size: 16,
                            "aria-hidden": "true"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/password-strength-input.jsx",
                            lineNumber: 84,
                            columnNumber: 15
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/password-strength-input.jsx",
                        lineNumber: 71,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ui/password-strength-input.jsx",
                lineNumber: 59,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "mt-2 text-sm text-red-500",
                children: error
            }, void 0, false, {
                fileName: "[project]/src/components/ui/password-strength-input.jsx",
                lineNumber: 90,
                columnNumber: 19
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-border mt-3 mb-4 h-1 w-full overflow-hidden rounded-full",
                role: "progressbar",
                "aria-valuenow": strengthScore,
                "aria-valuemin": 0,
                "aria-valuemax": 4,
                "aria-label": "Force du mot de passe",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "h-full ".concat(getStrengthColor(strengthScore), " transition-all duration-500 ease-out"),
                    style: {
                        width: "".concat(strengthScore / 4 * 100, "%")
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/password-strength-input.jsx",
                    lineNumber: 101,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/components/ui/password-strength-input.jsx",
                lineNumber: 93,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                id: "".concat(id, "-description"),
                className: "text-foreground mb-2 text-sm font-medium",
                children: [
                    getStrengthText(strengthScore),
                    ". Doit contenir :"
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ui/password-strength-input.jsx",
                lineNumber: 108,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                className: "grid grid-cols-2 gap-x-4 gap-y-1.5",
                "aria-label": "Exigences du mot de passe",
                children: strength.map((req, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                        className: "flex items-center gap-2",
                        children: [
                            req.met ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckIcon$3e$__["CheckIcon"], {
                                size: 16,
                                className: "text-[#5a50ff]",
                                "aria-hidden": "true"
                            }, void 0, false, {
                                fileName: "[project]/src/components/ui/password-strength-input.jsx",
                                lineNumber: 123,
                                columnNumber: 17
                            }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XIcon$3e$__["XIcon"], {
                                size: 16,
                                className: "text-muted-foreground/80",
                                "aria-hidden": "true"
                            }, void 0, false, {
                                fileName: "[project]/src/components/ui/password-strength-input.jsx",
                                lineNumber: 129,
                                columnNumber: 17
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-xs ".concat(req.met ? "text-[#5a50ff]" : "text-muted-foreground"),
                                children: [
                                    req.text,
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "sr-only",
                                        children: req.met ? " - Exigence remplie" : " - Exigence non remplie"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ui/password-strength-input.jsx",
                                        lineNumber: 139,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/ui/password-strength-input.jsx",
                                lineNumber: 135,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, index, true, {
                        fileName: "[project]/src/components/ui/password-strength-input.jsx",
                        lineNumber: 121,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0)))
            }, void 0, false, {
                fileName: "[project]/src/components/ui/password-strength-input.jsx",
                lineNumber: 116,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/password-strength-input.jsx",
        lineNumber: 51,
        columnNumber: 7
    }, ("TURBOPACK compile-time value", void 0));
}, "2PUfhwuOYfqdntoE9njBTQvJDuk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"]
    ];
})), "2PUfhwuOYfqdntoE9njBTQvJDuk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"]
    ];
});
_c1 = PasswordStrengthInput;
PasswordStrengthInput.displayName = "PasswordStrengthInput";
var _c, _c1;
__turbopack_context__.k.register(_c, "PasswordStrengthInput$forwardRef");
__turbopack_context__.k.register(_c1, "PasswordStrengthInput");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/auth/api.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getCurrentUser",
    ()=>getCurrentUser,
    "getGoogleAccessToken",
    ()=>getGoogleAccessToken,
    "getGoogleUserProfile",
    ()=>getGoogleUserProfile,
    "loginUser",
    ()=>loginUser,
    "logoutUser",
    ()=>logoutUser,
    "registerUser",
    ()=>registerUser,
    "signInGithub",
    ()=>signInGithub,
    "signInGoogle",
    ()=>signInGoogle,
    "updateUserProfile",
    ()=>updateUserProfile,
    "verifyEmail",
    ()=>verifyEmail
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$api$2d$utils$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/api-utils/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/auth-client.js [app-client] (ecmascript)");
;
;
async function loginUser(formData) {
    let rememberMe = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : false;
    try {
        const { data, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authClient"].signIn.email({
            email: formData.email,
            password: formData.password,
            // callbackURL: "/dashboard",
            rememberMe: rememberMe
        }, {
            onSuccess: ()=>{
                console.log("login");
            //   toast.success("Connexion reussie");
            },
            onError: (error)=>{
                toast.error(error.message);
            }
        });
        if (error) {
            throw new Error(error.message || "Erreur de connexion");
        }
        return data;
    } catch (err) {
        throw new Error(err.message || "Erreur de connexion");
    }
}
async function registerUser(formData) {
    try {
        // Format selon la documentation Better Auth
        const { data, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authClient"].signUp.email({
            email: formData.email,
            password: formData.password,
            name: formData.name,
            // Supprimer passwordConfirmation car non supporté par l'API
            callbackURL: "/dashboard"
        });
        if (error) {
            // Propager le message d'erreur exact de Better Auth
            const errorMessage = error.message || "Erreur lors de l'inscription";
            // Gérer les erreurs spécifiques
            if (errorMessage.toLowerCase().includes("email") && errorMessage.toLowerCase().includes("exist")) {
                throw new Error("Cet email est déjà utilisé");
            } else if (errorMessage.toLowerCase().includes("already")) {
                throw new Error("Cet email est déjà utilisé");
            }
            throw new Error(errorMessage);
        }
        return data;
    } catch (err) {
        // Propager l'erreur sans la modifier
        throw err;
    }
}
async function logoutUser() {
    try {
        const { error } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authClient"].signOut({
            fetchOptions: {
                onSuccess: ()=>{
                    console.log("logout");
                }
            }
        });
        console.log(error);
        if (error) {
            throw new Error(error.message || "Erreur lors de la déconnexion");
        }
        return true;
    } catch (err) {
        throw new Error(err.message || "Erreur lors de la déconnexion");
    }
}
async function getCurrentUser() {
    try {
        const { data, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authClient"].getSession();
        if (error) {
            return null;
        }
        return (data === null || data === void 0 ? void 0 : data.user) || null;
    } catch (err) {
        return null;
    }
}
async function updateUserProfile(formData) {
    try {
        console.log(formData, "update profile");
        // Utiliser l'API Better Auth pour mettre à jour le profil utilisateur
        // Envoyer uniquement les champs fournis dans formData
        const { data, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authClient"].updateUser(formData);
        if (error) {
            throw new Error(error.message || "Erreur lors de la mise à jour du profil");
        }
        return data;
    } catch (err) {
        throw new Error(err.message || "Erreur lors de la mise à jour du profil");
    }
}
const verifyEmail = async (email)=>{
    try {
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authClient"].sendVerificationEmail({
            email: email,
            callbackURL: "/dashboard"
        });
    } catch (err) {
        throw new Error(err.message || "Erreur lors de la vérification de l'email");
    }
};
const signInGoogle = async ()=>{
    try {
        const data = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authClient"].signIn.social({
            provider: "google",
            callbackURL: "/dashboard"
        });
        return data;
    } catch (err) {
        console.error("Erreur lors de la connexion avec Google:", err);
        throw err;
    }
};
const signInGithub = async ()=>{
    try {
        const data = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authClient"].signIn.social({
            provider: "github",
            callbackURL: "/dashboard"
        });
        return data;
    } catch (err) {
        console.error("Erreur lors de la connexion avec Github:", err);
        throw err;
    }
};
const getGoogleAccessToken = async (accountId)=>{
    try {
        const { accessToken } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authClient"].getAccessToken({
            providerId: "google",
            accountId: accountId
        });
        return {
            accessToken
        };
    } catch (err) {
        throw new Error(err.message || "Impossible de récupérer le token Google");
    }
};
const getGoogleUserProfile = async (accessToken)=>{
    try {
        const response = await fetch("https://www.googleapis.com/oauth2/v2/userinfo", {
            headers: {
                Authorization: "Bearer ".concat(accessToken)
            }
        });
        if (!response.ok) {
            throw new Error("Erreur API Google: ".concat(response.status));
        }
        const profileData = await response.json();
        return profileData;
    } catch (err) {
        console.error("Erreur lors de la récupération du profil Google:", err);
        throw new Error(err.message || "Impossible de récupérer le profil Google");
    }
}; // export const accounts = await authClient.listAccounts();
 // console.log(accounts);
 // export const accountsGoogle = accounts.data.filter(
 //   (account) => account.providerId === "google"
 // );
 // console.log(accountsGoogle, "accountsGoogle");
 // export const accounts = await authClient.listAccounts();
 // const accountID = accounts.data.filter(
 //   (account) => account.provider === "google"
 // )[0];
 // console.log(accountID);
 // export const getGoogleTokenForAccount = async () => {
 //   try {
 //     // Récupérer la liste des comptes
 //     const accountsResponse = await authClient.listAccounts();
 //     console.log("Tous les comptes:", accountsResponse);
 //     // Filtrer pour trouver le compte Google
 //     const googleAccount = accountsResponse.data.find(
 //       (account) => account.provider === "google"
 //     );
 //     if (!googleAccount) {
 //       console.error("Aucun compte Google trouvé");
 //       return null;
 //     }
 //     console.log("Compte Google trouvé:", googleAccount);
 //     // Vérifier si l'utilisateur est authentifié
 //     const session = await authClient.getSession();
 //     console.log("Session utilisateur:", session);
 //     if (!session) {
 //       console.error("Utilisateur non authentifié");
 //       return null;
 //     }
 //     // Appel à getAccessToken avec l'ID du compte Google
 //     console.log(
 //       "Tentative de récupération du token pour le compte:",
 //       googleAccount.id
 //     );
 //     const result = await authClient.getAccessToken({
 //       providerId: "google",
 //       accountId: googleAccount.id,
 //     });
 //     console.log("Résultat de getAccessToken:", result);
 //     return result.data.accessToken;
 //   } catch (err) {
 //     console.error("Erreur lors de la récupération du token:", err);
 //     console.error("Détails de l'erreur:", err.response?.data || err.message);
 //     return null;
 //   }
 // };
 // /**
 //  * Vérifie si l'utilisateur est connecté via Google
 //  * @returns {Promise<boolean>} - True si l'utilisateur est connecté via Google
 //  */
 // export const isConnectedWithGoogle = async () => {
 //   try {
 //     // Récupérer la session utilisateur
 //     const session = await authClient.getSession();
 //     if (!session || !session.user) {
 //       return false;
 //     }
 //     // Vérifier si l'utilisateur a un compte Google associé
 //     const accounts = session.user.accounts || [];
 //     return accounts.some((account) => account.providerId === "google");
 //   } catch (err) {
 //     console.error(
 //       "Erreur lors de la vérification de la connexion Google:",
 //       err
 //     );
 //     return false;
 //   }
 // };
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/auth/signup/registerForm.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hook$2d$form$2f$dist$2f$index$2e$esm$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-hook-form/dist/index.esm.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$submit$2d$button$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/submit-button.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$input$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/input.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/label.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$password$2d$strength$2d$input$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/password-strength-input.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/auth/api.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/auth-client.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$sonner$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/sonner.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
const RegisterFormContent = ()=>{
    _s();
    const { register, handleSubmit, watch, control, formState: { errors, isSubmitting }, setError: setFormError } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hook$2d$form$2f$dist$2f$index$2e$esm$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useForm"])();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"])();
    // Récupérer les paramètres d'invitation
    const invitationId = searchParams.get("invitation");
    const invitationEmail = searchParams.get("email");
    // Récupérer le code partenaire
    const partnerCode = searchParams.get("partner");
    const onSubmit = async (formData)=>{
        // Ajouter le code partenaire si présent
        if (partnerCode) {
            formData.referralCode = partnerCode;
        }
        // Selon la doc Better Auth, l'erreur est retournée directement dans { data, error }
        const { data, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["signUp"].email(formData, {
            onSuccess: async (ctx)=>{
                // ✅ Si c'est une inscription via invitation, accepter l'invitation immédiatement
                // L'utilisateur invité n'a PAS d'organisation propre, il rejoint celle de l'inviteur
                if (invitationId && invitationEmail) {
                    console.log("📨 [SIGNUP] Inscription via invitation détectée: ".concat(invitationId));
                    try {
                        // Accepter l'invitation immédiatement
                        const response = await fetch("/api/invitations/".concat(invitationId), {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/json"
                            },
                            body: JSON.stringify({
                                action: "accept"
                            })
                        });
                        if (response.ok) {
                            const result = await response.json();
                            console.log("✅ [SIGNUP] Invitation acceptée:", result);
                            // ✅ CRITIQUE: Stocker l'organizationId dans localStorage pour Apollo Client
                            // Le backend retourne l'organizationId après acceptation
                            if (result.organizationId) {
                                localStorage.setItem("active_organization_id", result.organizationId);
                                console.log("📦 [SIGNUP] Organization ID stocké: ".concat(result.organizationId));
                            }
                            // ✅ Rafraîchir la session Better Auth pour obtenir le nouveau activeOrganizationId
                            const { authClient } = await __turbopack_context__.A("[project]/src/lib/auth-client.js [app-client] (ecmascript, async loader)");
                            // Définir l'organisation active côté client
                            if (result.organizationId) {
                                await authClient.organization.setActive({
                                    organizationId: result.organizationId
                                });
                                console.log("🔄 [SIGNUP] Organisation active définie côté client");
                            }
                            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$sonner$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].success("Bienvenue ! Vous avez rejoint l'organisation avec succès.");
                            // ✅ Marquer l'onboarding comme vu pour les utilisateurs invités
                            // Ils n'ont pas besoin de passer par l'onboarding complet
                            await authClient.updateUser({
                                hasSeenOnboarding: true
                            });
                            // Rediriger directement vers le dashboard
                            router.push("/dashboard?welcome=invited");
                            return;
                        } else {
                            const errorData = await response.json();
                            console.error("❌ [SIGNUP] Erreur acceptation invitation:", errorData);
                            // Si l'invitation a échoué, rediriger quand même vers l'onboarding
                            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$sonner$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error(errorData.error || "Erreur lors de l'acceptation de l'invitation");
                        }
                    } catch (invError) {
                        console.error("❌ [SIGNUP] Exception acceptation invitation:", invError);
                        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$sonner$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error("Erreur lors de l'acceptation de l'invitation");
                    }
                    // En cas d'erreur, stocker l'invitation pour réessayer plus tard
                    localStorage.setItem("pendingInvitation", JSON.stringify({
                        invitationId,
                        email: invitationEmail,
                        timestamp: Date.now()
                    }));
                }
                // Redirection vers l'onboarding pour les utilisateurs normaux (non invités)
                router.push("/onboarding?step=1");
            },
            onError: (ctx)=>{
            // L'erreur est gérée via le retour { data, error }
            }
        });
        // Vérifier l'erreur retournée directement (selon la doc Better Auth)
        if (error) {
            // Better Auth peut retourner l'erreur dans différents formats
            let errorMessage = "Erreur lors de l'inscription";
            // Essayer différentes sources de message
            if (error.message) {
                errorMessage = error.message;
            } else if (error.statusText) {
                errorMessage = error.statusText;
            } else if (typeof error === "string") {
                errorMessage = error;
            }
            // Gérer les erreurs spécifiques
            if (errorMessage.toLowerCase().includes("email") && errorMessage.toLowerCase().includes("exist")) {
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$sonner$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error("Cet email est déjà utilisé");
            } else if (errorMessage.toLowerCase().includes("already")) {
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$sonner$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error("Cet email est déjà utilisé");
            } else if (errorMessage.toLowerCase().includes("utilisé")) {
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$sonner$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error("Cet email est déjà utilisé");
            } else if (errorMessage.toLowerCase().includes("duplicate")) {
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$sonner$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error("Cet email est déjà utilisé");
            } else if (errorMessage.toLowerCase().includes("unique")) {
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$sonner$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error("Cet email est déjà utilisé");
            } else if (error.status === 500) {
                // Erreur serveur - probablement email dupliqué (contrainte unique MongoDB)
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$sonner$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error("Cet email est déjà utilisé");
            } else {
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$sonner$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error(errorMessage);
            }
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
        action: "#",
        method: "post",
        className: "mt-6 space-y-4",
        onSubmit: handleSubmit(onSubmit),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                        htmlFor: "email-register-04",
                        className: "text-sm font-medium text-foreground dark:text-foreground",
                        children: "Email"
                    }, void 0, false, {
                        fileName: "[project]/app/auth/signup/registerForm.jsx",
                        lineNumber: 172,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$input$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InputEmail"], {
                        id: "email",
                        name: "email",
                        autoComplete: "email",
                        placeholder: "Saisissez votre email",
                        className: "mt-2",
                        defaultValue: invitationEmail || "",
                        ...register("email", {
                            required: "Email est requis",
                            pattern: {
                                value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
                                message: "Email invalide"
                            }
                        })
                    }, void 0, false, {
                        fileName: "[project]/app/auth/signup/registerForm.jsx",
                        lineNumber: 178,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    errors.email && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "mt-2 text-sm text-red-500",
                        children: errors.email.message
                    }, void 0, false, {
                        fileName: "[project]/app/auth/signup/registerForm.jsx",
                        lineNumber: 194,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/app/auth/signup/registerForm.jsx",
                lineNumber: 171,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hook$2d$form$2f$dist$2f$index$2e$esm$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Controller"], {
                    name: "password",
                    control: control,
                    rules: {
                        required: "Mot de passe est requis",
                        minLength: {
                            value: 8,
                            message: "Le mot de passe doit contenir au moins 8 caractères"
                        },
                        validate: {
                            hasNumber: (value)=>/[0-9]/.test(value) || "Doit contenir au moins 1 chiffre",
                            hasLowercase: (value)=>/[a-z]/.test(value) || "Doit contenir au moins 1 minuscule",
                            hasUppercase: (value)=>/[A-Z]/.test(value) || "Doit contenir au moins 1 majuscule"
                        }
                    },
                    render: (param)=>{
                        let { field } = param;
                        var _errors_password;
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$password$2d$strength$2d$input$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PasswordStrengthInput"], {
                            ...field,
                            label: "Mot de passe",
                            error: (_errors_password = errors.password) === null || _errors_password === void 0 ? void 0 : _errors_password.message
                        }, void 0, false, {
                            fileName: "[project]/app/auth/signup/registerForm.jsx",
                            lineNumber: 217,
                            columnNumber: 13
                        }, void 0);
                    }
                }, void 0, false, {
                    fileName: "[project]/app/auth/signup/registerForm.jsx",
                    lineNumber: 198,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/app/auth/signup/registerForm.jsx",
                lineNumber: 197,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$submit$2d$button$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SubmitButton"], {
                type: "submit",
                className: "mt-4 w-full py-2 font-medium cursor-pointer",
                isLoading: isSubmitting,
                children: "S'inscrire"
            }, void 0, false, {
                fileName: "[project]/app/auth/signup/registerForm.jsx",
                lineNumber: 225,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/app/auth/signup/registerForm.jsx",
        lineNumber: 165,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(RegisterFormContent, "9Iw48o1XsEXtInqWFftxzde7CJk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hook$2d$form$2f$dist$2f$index$2e$esm$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useForm"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"]
    ];
});
_c = RegisterFormContent;
const RegisterForm = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Suspense"], {
        fallback: null,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(RegisterFormContent, {}, void 0, false, {
            fileName: "[project]/app/auth/signup/registerForm.jsx",
            lineNumber: 239,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/app/auth/signup/registerForm.jsx",
        lineNumber: 238,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c1 = RegisterForm;
const __TURBOPACK__default__export__ = RegisterForm;
var _c, _c1;
__turbopack_context__.k.register(_c, "RegisterFormContent");
__turbopack_context__.k.register(_c1, "RegisterForm");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/typewriter-text.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Typewriter",
    ()=>Typewriter
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function Typewriter(param) {
    let { text, speed = 100, cursor = "|", loop = false, deleteSpeed = 50, delay = 1500, className } = param;
    _s();
    const [displayText, setDisplayText] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [currentIndex, setCurrentIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [isDeleting, setIsDeleting] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [textArrayIndex, setTextArrayIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    // Validate and process input text
    const textArray = Array.isArray(text) ? text : [
        text
    ];
    const currentText = textArray[textArrayIndex] || "";
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Typewriter.useEffect": ()=>{
            if (!currentText) return;
            const timeout = setTimeout({
                "Typewriter.useEffect.timeout": ()=>{
                    if (!isDeleting) {
                        if (currentIndex < currentText.length) {
                            setDisplayText({
                                "Typewriter.useEffect.timeout": (prev)=>prev + currentText[currentIndex]
                            }["Typewriter.useEffect.timeout"]);
                            setCurrentIndex({
                                "Typewriter.useEffect.timeout": (prev)=>prev + 1
                            }["Typewriter.useEffect.timeout"]);
                        } else if (loop) {
                            setTimeout({
                                "Typewriter.useEffect.timeout": ()=>setIsDeleting(true)
                            }["Typewriter.useEffect.timeout"], delay);
                        }
                    } else {
                        if (displayText.length > 0) {
                            setDisplayText({
                                "Typewriter.useEffect.timeout": (prev)=>prev.slice(0, -1)
                            }["Typewriter.useEffect.timeout"]);
                        } else {
                            setIsDeleting(false);
                            setCurrentIndex(0);
                            setTextArrayIndex({
                                "Typewriter.useEffect.timeout": (prev)=>(prev + 1) % textArray.length
                            }["Typewriter.useEffect.timeout"]);
                        }
                    }
                }
            }["Typewriter.useEffect.timeout"], isDeleting ? deleteSpeed : speed);
            return ({
                "Typewriter.useEffect": ()=>clearTimeout(timeout)
            })["Typewriter.useEffect"];
        }
    }["Typewriter.useEffect"], [
        currentIndex,
        isDeleting,
        currentText,
        loop,
        speed,
        deleteSpeed,
        delay,
        displayText,
        text
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        className: className,
        children: [
            displayText,
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "animate-pulse",
                children: cursor
            }, void 0, false, {
                fileName: "[project]/src/components/ui/typewriter-text.jsx",
                lineNumber: 65,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/typewriter-text.jsx",
        lineNumber: 63,
        columnNumber: 5
    }, this);
}
_s(Typewriter, "p87dQqAt9kwjvtFjU6ANjx4NS2o=");
_c = Typewriter;
var _c;
__turbopack_context__.k.register(_c, "Typewriter");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/seo/seo-head.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>SEOHead
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$noop$2d$head$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/components/noop-head.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function SEOHead(param) {
    let { title, description, keywords, canonical, openGraph = {}, twitter = {}, jsonLd, robots = "index,follow", author = "Newbi", language = "fr-FR" } = param;
    _s();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const baseUrl = ("TURBOPACK compile-time value", "http://localhost:3000") || "https://newbi.fr";
    // Construction de l'URL canonique
    const canonicalUrl = canonical || "".concat(baseUrl).concat(pathname);
    // Configuration Open Graph par défaut
    const defaultOpenGraph = {
        type: "website",
        locale: "fr_FR",
        url: canonicalUrl,
        siteName: "Newbi - Solution de gestion pour entrepreneurs",
        title: title,
        description: description,
        image: "/images/op-newbi.png",
        imageWidth: 1200,
        imageHeight: 1200,
        ...openGraph
    };
    // Configuration Twitter Card par défaut
    const defaultTwitter = {
        card: "summary_large_image",
        site: "@newbi_fr",
        creator: "@newbi_fr",
        title: title,
        description: description,
        image: "/images/op-newbi.png",
        ...twitter
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$noop$2d$head$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("title", {
                children: title
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 66,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                name: "description",
                content: description
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 67,
                columnNumber: 7
            }, this),
            keywords && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                name: "keywords",
                content: keywords
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 68,
                columnNumber: 20
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                name: "author",
                content: author
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 69,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                name: "robots",
                content: robots
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 70,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                name: "language",
                content: language
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 71,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("link", {
                rel: "canonical",
                href: canonicalUrl
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 74,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                httpEquiv: "content-language",
                content: "fr"
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 77,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                name: "geo.region",
                content: "FR"
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 78,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                name: "geo.country",
                content: "France"
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 79,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                property: "og:type",
                content: defaultOpenGraph.type
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 82,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                property: "og:locale",
                content: defaultOpenGraph.locale
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 83,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                property: "og:url",
                content: defaultOpenGraph.url
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 84,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                property: "og:site_name",
                content: defaultOpenGraph.siteName
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 85,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                property: "og:title",
                content: defaultOpenGraph.title
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 86,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                property: "og:description",
                content: defaultOpenGraph.description
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 87,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                property: "og:image",
                content: defaultOpenGraph.image
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 88,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                property: "og:image:width",
                content: defaultOpenGraph.imageWidth
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 89,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                property: "og:image:height",
                content: defaultOpenGraph.imageHeight
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 90,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                property: "og:image:alt",
                content: defaultOpenGraph.title
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 91,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                name: "twitter:card",
                content: defaultTwitter.card
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 94,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                name: "twitter:site",
                content: defaultTwitter.site
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 95,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                name: "twitter:creator",
                content: defaultTwitter.creator
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 96,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                name: "twitter:title",
                content: defaultTwitter.title
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 97,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                name: "twitter:description",
                content: defaultTwitter.description
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 98,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                name: "twitter:image",
                content: defaultTwitter.image
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 99,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                name: "viewport",
                content: "width=device-width, initial-scale=1.0"
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 102,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                name: "format-detection",
                content: "telephone=no"
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 103,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                name: "revisit-after",
                content: "7 days"
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 106,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                name: "rating",
                content: "general"
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 107,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("link", {
                rel: "icon",
                type: "image/x-icon",
                href: "/favicon.ico"
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 110,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("link", {
                rel: "icon",
                type: "image/png",
                sizes: "32x32",
                href: "/favicon-32x32.png"
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 111,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("link", {
                rel: "icon",
                type: "image/png",
                sizes: "16x16",
                href: "/favicon-16x16.png"
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 112,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("link", {
                rel: "apple-touch-icon",
                sizes: "180x180",
                href: "/apple-touch-icon.png"
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 113,
                columnNumber: 7
            }, this),
            jsonLd && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("script", {
                type: "application/ld+json",
                dangerouslySetInnerHTML: {
                    __html: JSON.stringify(jsonLd)
                }
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 117,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("link", {
                rel: "preconnect",
                href: "https://fonts.googleapis.com"
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 126,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("link", {
                rel: "preconnect",
                href: "https://fonts.gstatic.com",
                crossOrigin: "anonymous"
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 127,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/seo/seo-head.jsx",
        lineNumber: 64,
        columnNumber: 5
    }, this);
}
_s(SEOHead, "xbyQPtUVMO7MNj7WjJlpdWqRcTo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"]
    ];
});
_c = SEOHead;
var _c;
__turbopack_context__.k.register(_c, "SEOHead");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/seo/seo-metadata.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Favicons",
    ()=>Favicons,
    "JsonLd",
    ()=>JsonLd,
    "PerformanceOptimizations",
    ()=>PerformanceOptimizations,
    "SEOProvider",
    ()=>SEOProvider,
    "generateMetadata",
    ()=>generateMetadata
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
"use client";
;
function generateMetadata(seoData) {
    var _window_location, _window, _window_location1, _window1, _window_location2, _window2;
    const { title, description, keywords, canonical, openGraph = {}, twitter = {}, robots = "index,follow", author = "Newbi", language = "fr-FR" } = seoData;
    const baseUrl = ("TURBOPACK compile-time value", "http://localhost:3000") || "https://newbi.fr";
    return {
        title,
        description,
        keywords: keywords === null || keywords === void 0 ? void 0 : keywords.split(", "),
        authors: [
            {
                name: author
            }
        ],
        robots,
        alternates: {
            canonical: canonical || "".concat(baseUrl).concat(((_window = window) === null || _window === void 0 ? void 0 : (_window_location = _window.location) === null || _window_location === void 0 ? void 0 : _window_location.pathname) || ""),
            languages: {
                "fr-FR": canonical || "".concat(baseUrl).concat(((_window1 = window) === null || _window1 === void 0 ? void 0 : (_window_location1 = _window1.location) === null || _window_location1 === void 0 ? void 0 : _window_location1.pathname) || "")
            }
        },
        openGraph: {
            type: "website",
            locale: "fr_FR",
            url: canonical || "".concat(baseUrl).concat(((_window2 = window) === null || _window2 === void 0 ? void 0 : (_window_location2 = _window2.location) === null || _window_location2 === void 0 ? void 0 : _window_location2.pathname) || ""),
            siteName: "Newbi - Solution de gestion pour entrepreneurs",
            title: openGraph.title || title,
            description: openGraph.description || description,
            images: [
                {
                    url: "/images/op-newbi.png",
                    width: openGraph.imageWidth || 1200,
                    height: openGraph.imageHeight || 1200,
                    alt: openGraph.title || title
                }
            ],
            ...openGraph
        },
        twitter: {
            card: "summary_large_image",
            site: "@newbi_fr",
            creator: "@newbi_fr",
            title: twitter.title || title,
            description: twitter.description || description,
            images: [
                "/images/op-newbi.png"
            ],
            ...twitter
        },
        other: {
            "geo.region": "FR",
            "geo.country": "France",
            "language": language,
            "revisit-after": "7 days",
            "rating": "general"
        }
    };
}
function JsonLd(param) {
    let { jsonLd } = param;
    if (!jsonLd) return null;
    // Si c'est un tableau de JSON-LD, on les rend tous
    if (Array.isArray(jsonLd)) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: jsonLd.map((data, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("script", {
                    type: "application/ld+json",
                    dangerouslySetInnerHTML: {
                        __html: JSON.stringify(data)
                    }
                }, index, false, {
                    fileName: "[project]/src/components/seo/seo-metadata.jsx",
                    lineNumber: 88,
                    columnNumber: 11
                }, this))
        }, void 0, false);
    }
    // Sinon, on rend un seul JSON-LD
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("script", {
        type: "application/ld+json",
        dangerouslySetInnerHTML: {
            __html: JSON.stringify(jsonLd)
        }
    }, void 0, false, {
        fileName: "[project]/src/components/seo/seo-metadata.jsx",
        lineNumber: 102,
        columnNumber: 5
    }, this);
}
_c = JsonLd;
function Favicons() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("link", {
                rel: "icon",
                type: "image/x-icon",
                href: "/favicon.ico"
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-metadata.jsx",
                lineNumber: 117,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("link", {
                rel: "icon",
                type: "image/png",
                sizes: "32x32",
                href: "/favicon-32x32.png"
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-metadata.jsx",
                lineNumber: 118,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("link", {
                rel: "icon",
                type: "image/png",
                sizes: "16x16",
                href: "/favicon-16x16.png"
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-metadata.jsx",
                lineNumber: 119,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("link", {
                rel: "apple-touch-icon",
                sizes: "180x180",
                href: "/apple-touch-icon.png"
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-metadata.jsx",
                lineNumber: 120,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("link", {
                rel: "manifest",
                href: "/site.webmanifest"
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-metadata.jsx",
                lineNumber: 121,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                name: "theme-color",
                content: "#5B4FFF"
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-metadata.jsx",
                lineNumber: 122,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                name: "msapplication-TileColor",
                content: "#5B4FFF"
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-metadata.jsx",
                lineNumber: 123,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_c1 = Favicons;
function PerformanceOptimizations() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("link", {
                rel: "preconnect",
                href: "https://fonts.googleapis.com"
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-metadata.jsx",
                lineNumber: 134,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("link", {
                rel: "preconnect",
                href: "https://fonts.gstatic.com",
                crossOrigin: "anonymous"
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-metadata.jsx",
                lineNumber: 135,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("link", {
                rel: "dns-prefetch",
                href: "https://api.newbi.fr"
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-metadata.jsx",
                lineNumber: 136,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("link", {
                rel: "dns-prefetch",
                href: "https://cdn.newbi.fr"
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-metadata.jsx",
                lineNumber: 137,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_c2 = PerformanceOptimizations;
function SEOProvider(param) {
    let { children, jsonLd } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Favicons, {}, void 0, false, {
                fileName: "[project]/src/components/seo/seo-metadata.jsx",
                lineNumber: 149,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(PerformanceOptimizations, {}, void 0, false, {
                fileName: "[project]/src/components/seo/seo-metadata.jsx",
                lineNumber: 150,
                columnNumber: 7
            }, this),
            jsonLd && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(JsonLd, {
                jsonLd: jsonLd
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-metadata.jsx",
                lineNumber: 151,
                columnNumber: 18
            }, this),
            children
        ]
    }, void 0, true);
}
_c3 = SEOProvider;
var _c, _c1, _c2, _c3;
__turbopack_context__.k.register(_c, "JsonLd");
__turbopack_context__.k.register(_c1, "Favicons");
__turbopack_context__.k.register(_c2, "PerformanceOptimizations");
__turbopack_context__.k.register(_c3, "SEOProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/seo-data.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Configuration SEO centralisée pour toutes les pages du site
 * Contient les métadonnées, descriptions, mots-clés et données structurées
 */ __turbopack_context__.s([
    "defaultSEO",
    ()=>defaultSEO,
    "generateBasicJsonLd",
    ()=>generateBasicJsonLd,
    "generateBreadcrumbsJsonLd",
    ()=>generateBreadcrumbsJsonLd,
    "generateFAQJsonLd",
    ()=>generateFAQJsonLd,
    "generateMetaTags",
    ()=>generateMetaTags,
    "generateNextMetadata",
    ()=>generateNextMetadata,
    "generateReviewsJsonLd",
    ()=>generateReviewsJsonLd,
    "generateSitemap",
    ()=>generateSitemap,
    "getSEOData",
    ()=>getSEOData,
    "seoData",
    ()=>seoData,
    "validateSEOData",
    ()=>validateSEOData
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
const baseUrl = ("TURBOPACK compile-time value", "http://localhost:3000") || "https://newbi.fr";
const defaultSEO = {
    siteName: "Newbi - Solution de gestion pour entrepreneurs",
    author: "Newbi",
    language: "fr-FR",
    locale: "fr_FR",
    defaultImage: "/images/op-newbi.png",
    favicon: "".concat(baseUrl, "/NewbiV2/public/newbi.svg"),
    themeColor: "#3B82F6",
    // Informations de contact et localisation
    contact: {
        email: "contact@newbi.fr",
        supportEmail: "contact@newbi.fr",
        country: "France",
        region: "Europe"
    },
    // Configuration des réseaux sociaux
    social: {
        instagram: "https://www.instagram.com/newbi_fr?igsh=dnVwZ3NndTU3bWw5"
    }
};
const seoData = {
    // Page d'accueil
    home: {
        title: "Newbi - Solution de gestion complète pour entrepreneurs et freelances",
        description: "Simplifiez votre gestion d'entreprise avec Newbi : facturation, devis, signatures de mail, kanban, transferts de fichiers, gestion de trésorerie. Essai gratuit de 30 jours sans engagement.",
        keywords: "gestion entreprise, facturation, devis, signature de mail, kanban, freelance, entrepreneur, comptabilité, CRM, logiciel gestion, auto-entrepreneur, TPE, PME",
        canonical: "".concat(baseUrl),
        alternates: {
            canonical: "".concat(baseUrl)
        },
        openGraph: {
            title: "Newbi - La solution tout-en-un pour entrepreneurs",
            description: "Gérez votre entreprise efficacement : facturation, devis, signatures, organisation. Plus de 200 entrepreneurs nous font confiance.",
            image: "/images/op-newbi.png",
            type: "website",
            locale: "fr_FR",
            siteName: "Newbi"
        },
        twitter: {
            card: "summary_large_image",
            title: "Newbi - La solution tout-en-un pour entrepreneurs",
            description: "Gérez votre entreprise efficacement : facturation, devis, signatures, organisation.",
            image: "/images/op-newbi.png"
        },
        jsonLd: {
            "@context": "https://schema.org",
            "@type": "Organization",
            name: "Newbi",
            url: baseUrl,
            logo: "/images/op-newbi.png",
            description: "Solution de gestion complète pour entrepreneurs et freelances",
            foundingDate: "2023",
            address: {
                "@type": "PostalAddress",
                addressCountry: "FR",
                addressRegion: "France"
            },
            contactPoint: {
                "@type": "ContactPoint",
                email: "contact@newbi.fr",
                contactType: "customer service",
                availableLanguage: [
                    "French",
                    "fr"
                ]
            },
            sameAs: [
                "https://www.instagram.com/newbi_fr?igsh=dnVwZ3NndTU3bWw5"
            ],
            offers: {
                "@type": "Offer",
                description: "Essai gratuit de 30 jours",
                price: "0",
                priceCurrency: "EUR"
            },
            applicationCategory: "BusinessApplication",
            operatingSystem: "Web Browser"
        }
    },
    // Page Factures
    factures: {
        title: "Logiciel de Facturation Professionnel - Newbi",
        description: "Créez, envoyez et gérez vos factures professionnelles en quelques clics. Suivi des paiements, relances automatiques et conformité légale garantie.",
        keywords: "logiciel facturation, facture professionnelle, gestion factures, suivi paiements, relance automatique, TVA, comptabilité, facturation en ligne, auto-entrepreneur",
        canonical: "".concat(baseUrl, "/produits/factures"),
        openGraph: {
            title: "Facturation Professionnelle Simplifiée - Newbi",
            description: "Automatisez votre facturation et suivez vos paiements. Interface intuitive, conformité légale et gain de temps garanti.",
            image: "/images/op-newbi.png",
            type: "website",
            locale: "fr_FR"
        },
        twitter: {
            card: "summary_large_image",
            title: "Facturation Professionnelle Simplifiée - Newbi",
            description: "Automatisez votre facturation et suivez vos paiements.",
            image: "/images/op-newbi.png"
        },
        jsonLd: {
            "@context": "https://schema.org",
            "@type": "SoftwareApplication",
            name: "Newbi Facturation",
            applicationCategory: "BusinessApplication",
            operatingSystem: "Web",
            description: "Logiciel de facturation professionnel pour entrepreneurs et freelances",
            url: "".concat(baseUrl, "/produits/factures"),
            publisher: {
                "@type": "Organization",
                name: "Newbi"
            },
            offers: {
                "@type": "Offer",
                price: "0",
                priceCurrency: "EUR",
                description: "Essai gratuit de 30 jours"
            },
            featureList: [
                "Création de factures professionnelles",
                "Suivi des paiements",
                "Relances automatiques",
                "Conformité légale française",
                "Export comptable",
                "Gestion de la TVA",
                "Templates personnalisables"
            ],
            aggregateRating: {
                "@type": "AggregateRating",
                ratingValue: "4.8",
                reviewCount: "150"
            }
        }
    },
    // Page Devis
    devis: {
        title: "Créateur de Devis Professionnel en Ligne - Newbi",
        description: "Créez des devis professionnels personnalisés en quelques minutes. Conversion automatique en facture, suivi client et taux de conversion optimisé.",
        keywords: "créateur devis, devis professionnel, estimation, proposition commerciale, conversion facture, suivi client, devis en ligne, auto-entrepreneur",
        canonical: "".concat(baseUrl, "/produits/devis"),
        openGraph: {
            title: "Devis Professionnels en Ligne - Newbi",
            description: "Impressionnez vos clients avec des devis professionnels. Conversion facile en facture et suivi des acceptations.",
            image: "/images/op-newbi.png",
            type: "website",
            locale: "fr_FR"
        },
        twitter: {
            card: "summary_large_image",
            title: "Devis Professionnels en Ligne - Newbi",
            description: "Impressionnez vos clients avec des devis professionnels.",
            image: "/images/op-newbi.png"
        },
        jsonLd: {
            "@context": "https://schema.org",
            "@type": "SoftwareApplication",
            name: "Newbi Devis",
            applicationCategory: "BusinessApplication",
            operatingSystem: "Web",
            description: "Créateur de devis professionnel pour entrepreneurs",
            url: "".concat(baseUrl, "/produits/devis"),
            publisher: {
                "@type": "Organization",
                name: "Newbi"
            },
            offers: {
                "@type": "Offer",
                price: "0",
                priceCurrency: "EUR",
                description: "Essai gratuit de 30 jours"
            },
            featureList: [
                "Création de devis personnalisés",
                "Templates professionnels",
                "Conversion automatique en facture",
                "Suivi des acceptations",
                "Signature électronique intégrée",
                "Recherche d'entreprises françaises",
                "Calcul automatique de TVA"
            ],
            aggregateRating: {
                "@type": "AggregateRating",
                ratingValue: "4.7",
                reviewCount: "120"
            }
        }
    },
    // Page Signatures
    signatures: {
        title: "Générateur de Signature Mail Gratuit | Newbi",
        description: "Créez des signatures mail professionnelles gratuitement. Compatible Gmail, Outlook et Apple Mail. Templates personnalisables, export HTML et prévisualisation en temps réel.",
        keywords: "générateur signature mail gratuit, créer signature email professionnelle, signature gmail, signature outlook, template signature mail, signature email HTML, outil signature mail gratuit en ligne",
        canonical: "".concat(baseUrl, "/produits/signatures"),
        openGraph: {
            title: "Créez des Signatures Mail Professionnelles Gratuitement | Newbi",
            description: "Renforcez votre image de marque avec des signatures mail élégantes. Templates prêts à l'emploi, compatible tous clients email. 100% gratuit.",
            image: "/images/op-newbi.png",
            type: "website",
            locale: "fr_FR"
        },
        twitter: {
            card: "summary_large_image",
            title: "Signatures Mail Professionnelles Gratuites | Newbi",
            description: "Générateur de signatures mail gratuit. Templates pro, compatible Gmail, Outlook et Apple Mail.",
            image: "/images/op-newbi.png"
        },
        jsonLd: {
            "@context": "https://schema.org",
            "@type": "SoftwareApplication",
            name: "Newbi - Générateur de Signatures Mail",
            applicationCategory: "BusinessApplication",
            operatingSystem: "Web",
            description: "Générateur gratuit de signatures mail professionnelles compatible Gmail, Outlook et Apple Mail",
            url: "".concat(baseUrl, "/produits/signatures"),
            publisher: {
                "@type": "Organization",
                name: "Newbi"
            },
            offers: {
                "@type": "Offer",
                price: "0",
                priceCurrency: "EUR",
                description: "Outil entièrement gratuit"
            },
            featureList: [
                "Création de signatures email",
                "Templates personnalisables",
                "Conformité légale",
                "Intégration facile",
                "Design responsive",
                "Export HTML/CSS",
                "Prévisualisation en temps réel"
            ],
            aggregateRating: {
                "@type": "AggregateRating",
                ratingValue: "4.9",
                reviewCount: "200"
            }
        }
    },
    // Page Kanban
    kanban: {
        title: "Tableau Kanban - Gestion de Projets Agile - Newbi",
        description: "Organisez vos projets avec des tableaux Kanban intuitifs. Collaboration en équipe, suivi des tâches et productivité optimisée. Outil gratuit.",
        keywords: "kanban, gestion projet, organisation, productivité, collaboration équipe, suivi tâches, méthode agile, tableau kanban, outil gratuit",
        canonical: "".concat(baseUrl, "/dashboard/outils/kanban"),
        openGraph: {
            title: "Gestion de Projets Kanban - Newbi",
            description: "Boostez votre productivité avec nos tableaux Kanban. Organisation visuelle et collaboration simplifiée.",
            image: "/images/op-newbi.png",
            type: "website",
            locale: "fr_FR"
        },
        twitter: {
            card: "summary_large_image",
            title: "Gestion de Projets Kanban - Newbi",
            description: "Boostez votre productivité avec nos tableaux Kanban.",
            image: "/images/op-newbi.png"
        },
        jsonLd: {
            "@context": "https://schema.org",
            "@type": "SoftwareApplication",
            name: "Newbi Kanban",
            applicationCategory: "BusinessApplication",
            operatingSystem: "Web",
            description: "Outil de gestion de projets avec tableaux Kanban",
            url: "".concat(baseUrl, "/dashboard/outils/kanban"),
            publisher: {
                "@type": "Organization",
                name: "Newbi"
            },
            offers: {
                "@type": "Offer",
                price: "0",
                priceCurrency: "EUR",
                description: "Outil entièrement gratuit"
            },
            featureList: [
                "Tableaux Kanban personnalisables",
                "Collaboration en temps réel",
                "Suivi des tâches",
                "Notifications automatiques",
                "Rapports de productivité",
                "Interface drag & drop",
                "Organisation par colonnes"
            ],
            aggregateRating: {
                "@type": "AggregateRating",
                ratingValue: "4.6",
                reviewCount: "95"
            }
        }
    },
    // Page Transferts
    transfers: {
        title: "Transfert de Fichiers Sécurisé - Partage Professionnel - Newbi",
        description: "Partagez vos fichiers volumineux en toute sécurité. Transferts cryptés, liens temporaires et suivi des téléchargements pour professionnels.",
        keywords: "transfert fichiers, partage sécurisé, envoi gros fichiers, partage professionnel, cryptage, sécurité données, wetransfer alternatif",
        canonical: "".concat(baseUrl, "/dashboard/outils/transferts"),
        openGraph: {
            title: "Transfert de Fichiers Sécurisé - Newbi",
            description: "Partagez vos fichiers professionnels en toute sécurité. Cryptage avancé et contrôle total sur vos partages.",
            image: "/images/op-newbi.png",
            type: "website",
            locale: "fr_FR"
        },
        twitter: {
            card: "summary_large_image",
            title: "Transfert de Fichiers Sécurisé - Newbi",
            description: "Partagez vos fichiers professionnels en toute sécurité.",
            image: "/images/op-newbi.png"
        },
        jsonLd: {
            "@context": "https://schema.org",
            "@type": "SoftwareApplication",
            name: "Newbi Transferts",
            applicationCategory: "BusinessApplication",
            operatingSystem: "Web",
            description: "Solution de transfert de fichiers sécurisé pour professionnels",
            url: "".concat(baseUrl, "/dashboard/outils/transferts"),
            publisher: {
                "@type": "Organization",
                name: "Newbi"
            },
            offers: {
                "@type": "Offer",
                price: "0",
                priceCurrency: "EUR",
                description: "Essai gratuit de 30 jours"
            },
            featureList: [
                "Transferts cryptés",
                "Liens temporaires",
                "Suivi des téléchargements",
                "Contrôle d'accès",
                "Notifications en temps réel",
                "Stockage cloud sécurisé",
                "Interface drag & drop"
            ],
            aggregateRating: {
                "@type": "AggregateRating",
                ratingValue: "4.5",
                reviewCount: "80"
            }
        }
    },
    // Page Connexion
    login: {
        title: "Connexion - Accédez à votre espace Newbi",
        description: "Connectez-vous à votre compte Newbi pour accéder à tous vos outils de gestion d'entreprise : facturation, devis, signatures et plus.",
        keywords: "connexion newbi, login, espace client, compte utilisateur, authentification",
        robots: "noindex,nofollow",
        openGraph: {
            title: "Connexion à votre espace Newbi",
            description: "Accédez à votre tableau de bord et gérez votre entreprise efficacement."
        }
    },
    // Page Inscription
    signup: {
        title: "Inscription Gratuite - Créez votre compte Newbi",
        description: "Créez votre compte Newbi gratuitement et accédez à tous nos outils de gestion d'entreprise. Essai gratuit sans engagement, activation immédiate.",
        keywords: "inscription newbi, créer compte, essai gratuit, registration, nouveau compte",
        openGraph: {
            title: "Créez votre compte Newbi gratuitement",
            description: "Rejoignez plus de 1000 entrepreneurs qui font confiance à Newbi. Inscription gratuite et activation immédiate."
        },
        jsonLd: {
            "@context": "https://schema.org",
            "@type": "WebPage",
            name: "Inscription Newbi",
            description: "Page d'inscription pour créer un compte Newbi gratuit",
            offers: {
                "@type": "Offer",
                price: "0",
                priceCurrency: "EUR",
                description: "Compte gratuit avec accès aux fonctionnalités de base"
            }
        }
    },
    // Page Mentions Légales
    mentionsLegales: {
        title: "Mentions Légales - Newbi",
        description: "Mentions légales, informations sur l'éditeur, hébergement et conditions d'utilisation de la plateforme Newbi.",
        keywords: "mentions légales, éditeur, hébergement, conditions utilisation, RGPD, données personnelles",
        robots: "index,nofollow",
        openGraph: {
            title: "Mentions Légales - Newbi",
            description: "Informations légales et réglementaires concernant l'utilisation de Newbi."
        }
    },
    // Page Politique de Confidentialité
    politiqueConfidentialite: {
        title: "Politique de Confidentialité - Protection des Données - Newbi",
        description: "Notre politique de confidentialité détaille comment nous collectons, utilisons et protégeons vos données personnelles conformément au RGPD.",
        keywords: "politique confidentialité, protection données, RGPD, vie privée, cookies, données personnelles",
        robots: "index,nofollow",
        canonical: "".concat(baseUrl, "/politique-confidentialite"),
        openGraph: {
            title: "Politique de Confidentialité - Newbi",
            description: "Découvrez comment nous protégeons vos données personnelles et respectons votre vie privée.",
            type: "website",
            locale: "fr_FR"
        },
        jsonLd: {
            "@context": "https://schema.org",
            "@type": "WebPage",
            name: "Politique de Confidentialité",
            description: "Politique de confidentialité et protection des données personnelles de Newbi",
            url: "".concat(baseUrl, "/politique-confidentialite")
        }
    },
    // Page Tarifs
    pricing: {
        title: "Tarifs et Abonnements - Plans Newbi pour Entrepreneurs",
        description: "Découvrez nos tarifs transparents pour votre gestion d'entreprise. Essai gratuit de 30 jours, puis abonnement flexible. Fonctionnalités complètes incluses.",
        keywords: "tarifs newbi, prix abonnement, plan entrepreneur, facturation prix, devis tarif, essai gratuit, abonnement mensuel",
        canonical: "".concat(baseUrl, "/pricing"),
        openGraph: {
            title: "Tarifs Newbi - Plans pour Entrepreneurs",
            description: "Plans flexibles pour votre gestion d'entreprise. Essai gratuit de 30 jours inclus.",
            image: "/images/op-newbi.png",
            type: "website",
            locale: "fr_FR"
        },
        twitter: {
            card: "summary_large_image",
            title: "Tarifs Newbi - Plans pour Entrepreneurs",
            description: "Plans flexibles pour votre gestion d'entreprise.",
            image: "/images/op-newbi.png"
        },
        jsonLd: {
            "@context": "https://schema.org",
            "@type": "Product",
            name: "Newbi - Solution de gestion d'entreprise",
            description: "Solution complète de gestion pour entrepreneurs et freelances",
            url: "".concat(baseUrl, "/pricing"),
            brand: {
                "@type": "Brand",
                name: "Newbi"
            },
            offers: [
                {
                    "@type": "Offer",
                    name: "Essai Gratuit",
                    price: "0",
                    priceCurrency: "EUR",
                    description: "Essai gratuit de 30 jours - Toutes fonctionnalités incluses",
                    availability: "https://schema.org/InStock"
                },
                {
                    "@type": "Offer",
                    name: "Plan Professionnel",
                    price: "29",
                    priceCurrency: "EUR",
                    description: "Abonnement mensuel - Accès complet",
                    availability: "https://schema.org/InStock"
                }
            ]
        }
    },
    // Page FAQ
    faq: {
        title: "FAQ - Questions Fréquentes sur Newbi",
        description: "Trouvez rapidement les réponses à vos questions sur Newbi : facturation, devis, signatures, tarifs, fonctionnalités. Support et aide complète.",
        keywords: "faq newbi, questions fréquentes, aide newbi, support client, guide utilisation, facturation aide, devis questions, tarifs newbi",
        canonical: "".concat(baseUrl, "/faq"),
        robots: "index,follow",
        openGraph: {
            title: "FAQ - Toutes vos questions sur Newbi",
            description: "Découvrez les réponses aux questions les plus fréquentes sur Newbi. Support complet et aide détaillée.",
            image: "/images/op-newbi.png",
            type: "website",
            locale: "fr_FR"
        },
        twitter: {
            card: "summary_large_image",
            title: "FAQ - Toutes vos questions sur Newbi",
            description: "Découvrez les réponses aux questions les plus fréquentes sur Newbi.",
            image: "/images/op-newbi.png"
        },
        jsonLd: {
            "@context": "https://schema.org",
            "@type": "FAQPage",
            name: "FAQ Newbi",
            description: "Questions fréquentes et réponses sur l'utilisation de Newbi",
            url: "".concat(baseUrl, "/faq"),
            mainEntity: [
                {
                    "@type": "Question",
                    name: "Qu'est-ce que Newbi ?",
                    acceptedAnswer: {
                        "@type": "Answer",
                        text: "Newbi est une plateforme tout-en-un pour gérer simplement et efficacement votre activité: devis, factures, signature de mail, gestion de tâches en Kanban et transfert de fichiers sécurisé."
                    }
                },
                {
                    "@type": "Question",
                    name: "À qui s'adresse Newbi ?",
                    acceptedAnswer: {
                        "@type": "Answer",
                        text: "Newbi est une plateforme pensée pour les indépendants, TPE/PME, agences et associations qui veulent centraliser leurs outils commerciaux et administratifs, sans complexité."
                    }
                },
                {
                    "@type": "Question",
                    name: "Y a-t-il un essai gratuit ?",
                    acceptedAnswer: {
                        "@type": "Answer",
                        text: "Oui, vous bénéficiez de 30 jours gratuits à l'inscription, durant lesquels vous pouvez résilier votre abonnement à tout moment."
                    }
                }
            ]
        }
    },
    // Page CGV
    cgv: {
        title: "Conditions Générales de Vente - CGV Newbi",
        description: "Consultez les conditions générales de vente de Newbi : modalités d'abonnement, facturation, résiliation, garanties et conditions d'utilisation.",
        keywords: "cgv newbi, conditions générales vente, modalités abonnement, facturation, résiliation, garanties, conditions utilisation",
        canonical: "".concat(baseUrl, "/cgv"),
        robots: "index,nofollow",
        openGraph: {
            title: "Conditions Générales de Vente - Newbi",
            description: "Découvrez les conditions générales de vente et d'utilisation de la plateforme Newbi.",
            image: "/images/op-newbi.png",
            type: "website",
            locale: "fr_FR"
        },
        twitter: {
            card: "summary_large_image",
            title: "Conditions Générales de Vente - Newbi",
            description: "Conditions générales de vente et d'utilisation de Newbi.",
            image: "/images/op-newbi.png"
        },
        jsonLd: {
            "@context": "https://schema.org",
            "@type": "WebPage",
            name: "Conditions Générales de Vente",
            description: "Conditions générales de vente et d'utilisation de la plateforme Newbi",
            url: "".concat(baseUrl, "/cgv"),
            isPartOf: {
                "@type": "WebSite",
                name: "Newbi",
                url: baseUrl
            },
            inLanguage: "fr-FR",
            dateModified: "2024-01-01",
            publisher: {
                "@type": "Organization",
                name: "Newbi",
                url: baseUrl
            }
        }
    }
};
function getSEOData(pageKey) {
    const pageSEO = seoData[pageKey] || {};
    return {
        ...defaultSEO,
        ...pageSEO,
        openGraph: {
            siteName: defaultSEO.siteName,
            locale: defaultSEO.locale,
            type: "website",
            ...pageSEO.openGraph
        },
        twitter: {
            card: "summary_large_image",
            site: "@newbi_fr",
            creator: "@newbi_fr",
            ...pageSEO.twitter
        }
    };
}
function generateBasicJsonLd(title, description, url) {
    return {
        "@context": "https://schema.org",
        "@type": "WebPage",
        name: title,
        description: description,
        url: url,
        isPartOf: {
            "@type": "WebSite",
            name: defaultSEO.siteName,
            url: baseUrl
        },
        inLanguage: "fr-FR",
        potentialAction: {
            "@type": "ReadAction",
            target: url
        }
    };
}
function generateBreadcrumbsJsonLd(breadcrumbs) {
    return {
        "@context": "https://schema.org",
        "@type": "BreadcrumbList",
        itemListElement: breadcrumbs.map((item, index)=>({
                "@type": "ListItem",
                position: index + 1,
                name: item.name,
                item: item.url
            }))
    };
}
function generateSitemap() {
    const pages = Object.keys(seoData).filter((key)=>{
        var _seoData_key_robots;
        return !((_seoData_key_robots = seoData[key].robots) === null || _seoData_key_robots === void 0 ? void 0 : _seoData_key_robots.includes("noindex"));
    });
    const urls = pages.map((pageKey)=>{
        const page = seoData[pageKey];
        const url = page.canonical || "".concat(baseUrl, "/").concat(pageKey);
        const priority = pageKey === "home" ? "1.0" : "0.8";
        const changefreq = pageKey === "home" ? "weekly" : "monthly";
        return "\n    <url>\n      <loc>".concat(url, "</loc>\n      <changefreq>").concat(changefreq, "</changefreq>\n      <priority>").concat(priority, "</priority>\n      <lastmod>").concat(new Date().toISOString().split("T")[0], "</lastmod>\n    </url>");
    }).join("");
    return '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n  '.concat(urls, "\n</urlset>");
}
function generateMetaTags(pageKey) {
    let currentUrl = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "";
    var _seo_openGraph, _seo_openGraph1, _seo_openGraph2, _seo_openGraph3, _seo_openGraph4, _seo_openGraph5, _seo_openGraph6, _seo_twitter, _seo_twitter1, _seo_twitter2, _seo_twitter3, _seo_twitter4, _seo_twitter5, _seo_openGraph7;
    const seo = getSEOData(pageKey);
    return {
        title: seo.title,
        description: seo.description,
        keywords: seo.keywords,
        canonical: seo.canonical || currentUrl,
        robots: seo.robots || "index,follow",
        // Open Graph
        openGraph: {
            title: ((_seo_openGraph = seo.openGraph) === null || _seo_openGraph === void 0 ? void 0 : _seo_openGraph.title) || seo.title,
            description: ((_seo_openGraph1 = seo.openGraph) === null || _seo_openGraph1 === void 0 ? void 0 : _seo_openGraph1.description) || seo.description,
            url: currentUrl,
            siteName: ((_seo_openGraph2 = seo.openGraph) === null || _seo_openGraph2 === void 0 ? void 0 : _seo_openGraph2.siteName) || defaultSEO.siteName,
            images: [
                {
                    url: ((_seo_openGraph3 = seo.openGraph) === null || _seo_openGraph3 === void 0 ? void 0 : _seo_openGraph3.image) || defaultSEO.defaultImage,
                    width: 1200,
                    height: 630,
                    alt: ((_seo_openGraph4 = seo.openGraph) === null || _seo_openGraph4 === void 0 ? void 0 : _seo_openGraph4.title) || seo.title
                }
            ],
            locale: ((_seo_openGraph5 = seo.openGraph) === null || _seo_openGraph5 === void 0 ? void 0 : _seo_openGraph5.locale) || defaultSEO.locale,
            type: ((_seo_openGraph6 = seo.openGraph) === null || _seo_openGraph6 === void 0 ? void 0 : _seo_openGraph6.type) || "website"
        },
        // Twitter
        twitter: {
            card: ((_seo_twitter = seo.twitter) === null || _seo_twitter === void 0 ? void 0 : _seo_twitter.card) || "summary_large_image",
            site: ((_seo_twitter1 = seo.twitter) === null || _seo_twitter1 === void 0 ? void 0 : _seo_twitter1.site) || "@newbi_fr",
            creator: ((_seo_twitter2 = seo.twitter) === null || _seo_twitter2 === void 0 ? void 0 : _seo_twitter2.creator) || "@newbi_fr",
            title: ((_seo_twitter3 = seo.twitter) === null || _seo_twitter3 === void 0 ? void 0 : _seo_twitter3.title) || seo.title,
            description: ((_seo_twitter4 = seo.twitter) === null || _seo_twitter4 === void 0 ? void 0 : _seo_twitter4.description) || seo.description,
            images: [
                ((_seo_twitter5 = seo.twitter) === null || _seo_twitter5 === void 0 ? void 0 : _seo_twitter5.image) || ((_seo_openGraph7 = seo.openGraph) === null || _seo_openGraph7 === void 0 ? void 0 : _seo_openGraph7.image) || defaultSEO.defaultImage
            ]
        },
        // Autres meta tags
        other: {
            "theme-color": defaultSEO.themeColor,
            "application-name": "Newbi",
            "apple-mobile-web-app-title": "Newbi",
            "apple-mobile-web-app-capable": "yes",
            "apple-mobile-web-app-status-bar-style": "default",
            "format-detection": "telephone=no",
            "mobile-web-app-capable": "yes",
            "msapplication-config": "".concat(baseUrl, "/browserconfig.xml"),
            "msapplication-TileColor": defaultSEO.themeColor
        }
    };
}
function generateFAQJsonLd(faqs) {
    return {
        "@context": "https://schema.org",
        "@type": "FAQPage",
        mainEntity: faqs.map((faq)=>({
                "@type": "Question",
                name: faq.question,
                acceptedAnswer: {
                    "@type": "Answer",
                    text: faq.answer
                }
            }))
    };
}
function generateReviewsJsonLd(reviews) {
    return {
        "@context": "https://schema.org",
        "@type": "Product",
        name: "Newbi - Solution de gestion d'entreprise",
        aggregateRating: {
            "@type": "AggregateRating",
            ratingValue: reviews.reduce((sum, review)=>sum + review.rating, 0) / reviews.length,
            reviewCount: reviews.length,
            bestRating: 5,
            worstRating: 1
        },
        review: reviews.map((review)=>({
                "@type": "Review",
                author: {
                    "@type": "Person",
                    name: review.author
                },
                reviewRating: {
                    "@type": "Rating",
                    ratingValue: review.rating,
                    bestRating: 5,
                    worstRating: 1
                },
                reviewBody: review.text,
                datePublished: review.date
            }))
    };
}
function validateSEOData(pageKey) {
    var _seo_openGraph, _seo_openGraph1, _seo_openGraph2;
    const seo = seoData[pageKey];
    const errors = [];
    const warnings = [];
    if (!seo) {
        errors.push('Page "'.concat(pageKey, '" non trouvée dans seoData'));
        return {
            valid: false,
            errors,
            warnings
        };
    }
    // Validation du titre
    if (!seo.title) {
        errors.push("Titre manquant");
    } else if (seo.title.length > 60) {
        warnings.push("Titre trop long (".concat(seo.title.length, " caractères, recommandé: <60)"));
    } else if (seo.title.length < 30) {
        warnings.push("Titre court (".concat(seo.title.length, " caractères, recommandé: 30-60)"));
    }
    // Validation de la description
    if (!seo.description) {
        errors.push("Description manquante");
    } else if (seo.description.length > 160) {
        warnings.push("Description trop longue (".concat(seo.description.length, " caractères, recommandé: <160)"));
    } else if (seo.description.length < 120) {
        warnings.push("Description courte (".concat(seo.description.length, " caractères, recommandé: 120-160)"));
    }
    // Validation des mots-clés
    if (!seo.keywords) {
        warnings.push("Mots-clés manquants");
    } else {
        const keywordCount = seo.keywords.split(",").length;
        if (keywordCount > 10) {
            warnings.push("Trop de mots-clés (".concat(keywordCount, ", recommandé: <10)"));
        }
    }
    // Validation Open Graph
    if (!((_seo_openGraph = seo.openGraph) === null || _seo_openGraph === void 0 ? void 0 : _seo_openGraph.title)) {
        warnings.push("Titre Open Graph manquant");
    }
    if (!((_seo_openGraph1 = seo.openGraph) === null || _seo_openGraph1 === void 0 ? void 0 : _seo_openGraph1.description)) {
        warnings.push("Description Open Graph manquante");
    }
    if (!((_seo_openGraph2 = seo.openGraph) === null || _seo_openGraph2 === void 0 ? void 0 : _seo_openGraph2.image)) {
        warnings.push("Image Open Graph manquante");
    }
    return {
        valid: errors.length === 0,
        errors,
        warnings,
        score: Math.max(0, 100 - errors.length * 20 - warnings.length * 5)
    };
}
function generateNextMetadata(pageKey) {
    var _seoConfig_openGraph, _seoConfig_openGraph1, _seoConfig_openGraph2, _seoConfig_openGraph3, _seoConfig_openGraph4, _seoConfig_openGraph5, _seoConfig_openGraph6, _seoConfig_twitter, _seoConfig_twitter1, _seoConfig_twitter2, _seoConfig_twitter3;
    const seoConfig = getSEOData(pageKey);
    return {
        title: seoConfig.title,
        description: seoConfig.description,
        keywords: seoConfig.keywords,
        authors: [
            {
                name: seoConfig.author || defaultSEO.author
            }
        ],
        creator: seoConfig.author || defaultSEO.author,
        publisher: defaultSEO.siteName,
        alternates: {
            canonical: seoConfig.canonical
        },
        openGraph: {
            title: ((_seoConfig_openGraph = seoConfig.openGraph) === null || _seoConfig_openGraph === void 0 ? void 0 : _seoConfig_openGraph.title) || seoConfig.title,
            description: ((_seoConfig_openGraph1 = seoConfig.openGraph) === null || _seoConfig_openGraph1 === void 0 ? void 0 : _seoConfig_openGraph1.description) || seoConfig.description,
            url: seoConfig.canonical,
            siteName: ((_seoConfig_openGraph2 = seoConfig.openGraph) === null || _seoConfig_openGraph2 === void 0 ? void 0 : _seoConfig_openGraph2.siteName) || defaultSEO.siteName,
            images: ((_seoConfig_openGraph3 = seoConfig.openGraph) === null || _seoConfig_openGraph3 === void 0 ? void 0 : _seoConfig_openGraph3.image) ? [
                {
                    url: seoConfig.openGraph.image,
                    width: 1200,
                    height: 630,
                    alt: ((_seoConfig_openGraph4 = seoConfig.openGraph) === null || _seoConfig_openGraph4 === void 0 ? void 0 : _seoConfig_openGraph4.title) || seoConfig.title
                }
            ] : [],
            locale: ((_seoConfig_openGraph5 = seoConfig.openGraph) === null || _seoConfig_openGraph5 === void 0 ? void 0 : _seoConfig_openGraph5.locale) || defaultSEO.locale,
            type: ((_seoConfig_openGraph6 = seoConfig.openGraph) === null || _seoConfig_openGraph6 === void 0 ? void 0 : _seoConfig_openGraph6.type) || "website"
        },
        twitter: {
            card: ((_seoConfig_twitter = seoConfig.twitter) === null || _seoConfig_twitter === void 0 ? void 0 : _seoConfig_twitter.card) || "summary_large_image",
            title: ((_seoConfig_twitter1 = seoConfig.twitter) === null || _seoConfig_twitter1 === void 0 ? void 0 : _seoConfig_twitter1.title) || seoConfig.title,
            description: ((_seoConfig_twitter2 = seoConfig.twitter) === null || _seoConfig_twitter2 === void 0 ? void 0 : _seoConfig_twitter2.description) || seoConfig.description,
            images: ((_seoConfig_twitter3 = seoConfig.twitter) === null || _seoConfig_twitter3 === void 0 ? void 0 : _seoConfig_twitter3.image) ? [
                seoConfig.twitter.image
            ] : []
        },
        robots: {
            index: true,
            follow: true,
            googleBot: {
                index: true,
                follow: true,
                "max-video-preview": -1,
                "max-image-preview": "large",
                "max-snippet": -1
            }
        }
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/use-seo.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useAuthSEO",
    ()=>useAuthSEO,
    "useLegalSEO",
    ()=>useLegalSEO,
    "useProductSEO",
    ()=>useProductSEO,
    "useSEO",
    ()=>useSEO
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$seo$2d$data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/seo-data.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature(), _s3 = __turbopack_context__.k.signature();
"use client";
;
;
function useSEO(pageKey) {
    let customSEO = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, breadcrumbs = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : [];
    _s();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const baseUrl = ("TURBOPACK compile-time value", "http://localhost:3000") || "https://newbi.fr";
    const currentUrl = "".concat(baseUrl).concat(pathname);
    // Récupération des données SEO de base
    const baseSEO = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$seo$2d$data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSEOData"])(pageKey);
    // Fusion avec les données personnalisées
    const seoData = {
        ...baseSEO,
        ...customSEO,
        canonical: customSEO.canonical || currentUrl,
        openGraph: {
            ...baseSEO.openGraph,
            ...customSEO.openGraph,
            url: customSEO.canonical || currentUrl
        },
        twitter: {
            ...baseSEO.twitter,
            ...customSEO.twitter
        }
    };
    // Génération du JSON-LD de base si pas fourni
    if (!seoData.jsonLd && pageKey) {
        seoData.jsonLd = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$seo$2d$data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateBasicJsonLd"])(seoData.title, seoData.description, currentUrl);
    }
    // Ajout des breadcrumbs JSON-LD si fournis
    if (breadcrumbs.length > 0) {
        const breadcrumbsJsonLd = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$seo$2d$data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateBreadcrumbsJsonLd"])(breadcrumbs);
        // Si on a déjà du JSON-LD, on crée un tableau
        if (seoData.jsonLd) {
            seoData.jsonLd = [
                seoData.jsonLd,
                breadcrumbsJsonLd
            ];
        } else {
            seoData.jsonLd = breadcrumbsJsonLd;
        }
    }
    return seoData;
}
_s(useSEO, "xbyQPtUVMO7MNj7WjJlpdWqRcTo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"]
    ];
});
function useProductSEO(productName) {
    let customSEO = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
    _s1();
    const breadcrumbs = [
        {
            name: "Accueil",
            url: ("TURBOPACK compile-time value", "http://localhost:3000") || "https://newbi.fr"
        },
        {
            name: "Produits",
            url: "".concat(("TURBOPACK compile-time value", "http://localhost:3000") || "https://newbi.fr", "/produits")
        },
        {
            name: productName,
            url: "".concat(("TURBOPACK compile-time value", "http://localhost:3000") || "https://newbi.fr", "/produits/").concat(productName.toLowerCase())
        }
    ];
    return useSEO(productName.toLowerCase(), customSEO, breadcrumbs);
}
_s1(useProductSEO, "6rSydtRzpsPOyyHBRlWg+zmNlls=", false, function() {
    return [
        useSEO
    ];
});
function useAuthSEO(authType) {
    let customSEO = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
    _s2();
    const breadcrumbs = [
        {
            name: "Accueil",
            url: ("TURBOPACK compile-time value", "http://localhost:3000") || "https://newbi.fr"
        },
        {
            name: authType === "login" ? "Connexion" : "Inscription",
            url: "".concat(("TURBOPACK compile-time value", "http://localhost:3000") || "https://newbi.fr", "/auth/").concat(authType)
        }
    ];
    return useSEO(authType, customSEO, breadcrumbs);
}
_s2(useAuthSEO, "6rSydtRzpsPOyyHBRlWg+zmNlls=", false, function() {
    return [
        useSEO
    ];
});
function useLegalSEO(legalType) {
    let customSEO = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
    _s3();
    const pageNames = {
        "mentions-legales": "Mentions Légales",
        "politique-de-confidentialite": "Politique de Confidentialité"
    };
    const breadcrumbs = [
        {
            name: "Accueil",
            url: ("TURBOPACK compile-time value", "http://localhost:3000") || "https://newbi.fr"
        },
        {
            name: pageNames[legalType],
            url: "".concat(("TURBOPACK compile-time value", "http://localhost:3000") || "https://newbi.fr", "/").concat(legalType)
        }
    ];
    const pageKey = legalType === "mentions-legales" ? "mentionsLegales" : "politiqueConfidentialite";
    return useSEO(pageKey, customSEO, breadcrumbs);
}
_s3(useLegalSEO, "6rSydtRzpsPOyyHBRlWg+zmNlls=", false, function() {
    return [
        useSEO
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/auth/signup/page.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>SignUpPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/button.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$separator$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/separator.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/auth-client.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$auth$2f$signup$2f$registerForm$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/auth/signup/registerForm.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$sonner$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/sonner.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$typewriter$2d$text$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/typewriter-text.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$arrow$2d$up$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CircleArrowUp$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/circle-arrow-up.js [app-client] (ecmascript) <export default as CircleArrowUp>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$seo$2f$seo$2d$head$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/seo/seo-head.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$seo$2f$seo$2d$metadata$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/seo/seo-metadata.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$seo$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/use-seo.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
const GoogleIcon = (props)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        viewBox: "0 0 24 24",
        ...props,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z",
                fill: "#4285F4"
            }, void 0, false, {
                fileName: "[project]/app/auth/signup/page.jsx",
                lineNumber: 19,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z",
                fill: "#34A853"
            }, void 0, false, {
                fileName: "[project]/app/auth/signup/page.jsx",
                lineNumber: 20,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z",
                fill: "#FBBC05"
            }, void 0, false, {
                fileName: "[project]/app/auth/signup/page.jsx",
                lineNumber: 21,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z",
                fill: "#EA4335"
            }, void 0, false, {
                fileName: "[project]/app/auth/signup/page.jsx",
                lineNumber: 22,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/app/auth/signup/page.jsx",
        lineNumber: 18,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
_c = GoogleIcon;
function SignUpPage() {
    _s();
    const seoData = {
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$seo$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuthSEO"])("signup"),
        robots: "noindex,nofollow"
    };
    const signInWithProvider = async (provider)=>{
        // Vider tous les caches avant la connexion OAuth
        try {
            console.log("🧹 Nettoyage des caches avant connexion OAuth...");
            // Vider le cache utilisateur
            localStorage.removeItem("user-cache");
            // Vider tous les caches d'abonnement (on ne connaît pas l'ID à l'avance)
            Object.keys(localStorage).forEach((key)=>{
                if (key.startsWith("subscription-")) {
                    localStorage.removeItem(key);
                    console.log("🗑️ Cache supprimé: ".concat(key));
                }
            });
            console.log("✅ Caches nettoyés avec succès");
        } catch (error) {
            console.warn("⚠️ Erreur lors du nettoyage des caches:", error);
        }
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["signIn"].social({
            provider,
            callbackURL: "/dashboard"
        }, {
            onSuccess: ()=>{},
            onError: (error)=>{
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$sonner$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error("Erreur lors de la connexion avec ".concat(provider));
                throw error;
            }
        });
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$seo$2f$seo$2d$head$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                ...seoData
            }, void 0, false, {
                fileName: "[project]/app/auth/signup/page.jsx",
                lineNumber: 67,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$seo$2f$seo$2d$metadata$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["JsonLd"], {
                jsonLd: seoData.jsonLd
            }, void 0, false, {
                fileName: "[project]/app/auth/signup/page.jsx",
                lineNumber: 68,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "hidden md:flex h-screen",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-1/2 flex items-center justify-center p-8",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mx-auto sm:max-w-md w-full",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            className: "text-3xl font-medium text-foreground dark:text-foreground",
                                            children: "Inscrivez-vous"
                                        }, void 0, false, {
                                            fileName: "[project]/app/auth/signup/page.jsx",
                                            lineNumber: 74,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "mt-2 text-sm text-muted-foreground dark:text-muted-foreground",
                                            children: [
                                                "Vous avez déjà un compte ?",
                                                " ",
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    href: "/auth/login",
                                                    className: "font-medium text-primary hover:text-primary/90 dark:text-primary hover:dark:text-primary/90",
                                                    children: "Se connecter"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/auth/signup/page.jsx",
                                                    lineNumber: 79,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/auth/signup/page.jsx",
                                            lineNumber: 77,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "mt-8",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                                variant: "outline",
                                                className: "w-full items-center justify-center",
                                                onClick: ()=>signInWithProvider("google"),
                                                asChild: true,
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                    href: "#",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(GoogleIcon, {
                                                            className: "size-4",
                                                            "aria-hidden": true
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/auth/signup/page.jsx",
                                                            lineNumber: 94,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "text-sm font-medium",
                                                            children: "Connexion avec Google"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/auth/signup/page.jsx",
                                                            lineNumber: 95,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/auth/signup/page.jsx",
                                                    lineNumber: 93,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/app/auth/signup/page.jsx",
                                                lineNumber: 87,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/auth/signup/page.jsx",
                                            lineNumber: 86,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "relative my-6",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "absolute inset-0 flex items-center",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$separator$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Separator"], {
                                                        className: "w-full"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/auth/signup/page.jsx",
                                                        lineNumber: 104,
                                                        columnNumber: 19
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/app/auth/signup/page.jsx",
                                                    lineNumber: 103,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "relative flex justify-center text-xs uppercase",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "bg-background px-2 text-muted-foreground",
                                                        children: "ou"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/auth/signup/page.jsx",
                                                        lineNumber: 107,
                                                        columnNumber: 19
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/app/auth/signup/page.jsx",
                                                    lineNumber: 106,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/auth/signup/page.jsx",
                                            lineNumber: 102,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$auth$2f$signup$2f$registerForm$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                            fileName: "[project]/app/auth/signup/page.jsx",
                                            lineNumber: 113,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/auth/signup/page.jsx",
                                    lineNumber: 73,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/auth/signup/page.jsx",
                                lineNumber: 72,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-1/2 p-2 flex items-center min-h-screen justify-center",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex p-5 items-center justify-center w-full h-full rounded-lg bg-[#5A50FF]/30 relative",
                                    style: {
                                        transform: "rotate(180deg)"
                                    },
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "bg-white/80 shadow-md rounded-2xl p-6 w-110 mx-auto",
                                            style: {
                                                transform: "rotate(180deg)"
                                            },
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-lg min-h-[27px] flex items-center justify-between",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex-1",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$typewriter$2d$text$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Typewriter"], {
                                                            text: [
                                                                "Créez votre compte en quelques secondes.",
                                                                "Rejoignez notre communauté.",
                                                                "Commencez votre aventure dès maintenant."
                                                            ],
                                                            speed: 30,
                                                            deleteSpeed: 30,
                                                            delay: 2000,
                                                            loop: true,
                                                            className: "font-medium text-left text-[#1C1C1C] text-[15px]"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/auth/signup/page.jsx",
                                                            lineNumber: 129,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/auth/signup/page.jsx",
                                                        lineNumber: 128,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$arrow$2d$up$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CircleArrowUp$3e$__["CircleArrowUp"], {
                                                        className: "ml-4 text-[#1C1C1C] flex-shrink-0"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/auth/signup/page.jsx",
                                                        lineNumber: 142,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/auth/signup/page.jsx",
                                                lineNumber: 127,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/auth/signup/page.jsx",
                                            lineNumber: 123,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                            src: "/ni.svg",
                                            alt: "Newbi Logo",
                                            className: "absolute bottom-2 right-3 w-5 h-auto filter brightness-0 invert",
                                            style: {
                                                opacity: 0.9
                                            }
                                        }, void 0, false, {
                                            fileName: "[project]/app/auth/signup/page.jsx",
                                            lineNumber: 145,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/auth/signup/page.jsx",
                                    lineNumber: 117,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/auth/signup/page.jsx",
                                lineNumber: 116,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/auth/signup/page.jsx",
                        lineNumber: 71,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "md:hidden min-h-screen bg-background flex flex-col",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "pt-10 flex justify-center",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                    src: "/newbiLetter.png",
                                    alt: "Newbi",
                                    className: "h-5 w-auto object-contain"
                                }, void 0, false, {
                                    fileName: "[project]/app/auth/signup/page.jsx",
                                    lineNumber: 159,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/auth/signup/page.jsx",
                                lineNumber: 158,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex-1 flex items-center justify-center px-6",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "w-full max-w-sm",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            className: "text-2xl font-medium text-foreground text-center mb-8",
                                            children: "Inscription"
                                        }, void 0, false, {
                                            fileName: "[project]/app/auth/signup/page.jsx",
                                            lineNumber: 165,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                            variant: "outline",
                                            size: "lg",
                                            className: "w-full items-center justify-center cursor-pointer",
                                            onClick: ()=>signInWithProvider("google"),
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(GoogleIcon, {
                                                    className: "size-4",
                                                    "aria-hidden": true
                                                }, void 0, false, {
                                                    fileName: "[project]/app/auth/signup/page.jsx",
                                                    lineNumber: 175,
                                                    columnNumber: 17
                                                }, this),
                                                "Inscription avec Google"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/auth/signup/page.jsx",
                                            lineNumber: 169,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "relative my-6",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "absolute inset-0 flex items-center",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$separator$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Separator"], {
                                                        className: "w-full"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/auth/signup/page.jsx",
                                                        lineNumber: 181,
                                                        columnNumber: 19
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/app/auth/signup/page.jsx",
                                                    lineNumber: 180,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "relative flex justify-center text-xs uppercase",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "bg-background px-2 text-muted-foreground",
                                                        children: "ou"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/auth/signup/page.jsx",
                                                        lineNumber: 184,
                                                        columnNumber: 19
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/app/auth/signup/page.jsx",
                                                    lineNumber: 183,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/auth/signup/page.jsx",
                                            lineNumber: 179,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$auth$2f$signup$2f$registerForm$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                            fileName: "[project]/app/auth/signup/page.jsx",
                                            lineNumber: 188,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/auth/signup/page.jsx",
                                    lineNumber: 164,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/auth/signup/page.jsx",
                                lineNumber: 163,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "pb-6 px-6 text-center space-y-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-xs text-muted-foreground",
                                        children: [
                                            "Vous avez déjà un compte ?",
                                            " ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                href: "/auth/login",
                                                className: "font-medium text-primary hover:text-primary/90",
                                                children: "Se connecter"
                                            }, void 0, false, {
                                                fileName: "[project]/app/auth/signup/page.jsx",
                                                lineNumber: 196,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/auth/signup/page.jsx",
                                        lineNumber: 194,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-[11px] text-muted-foreground/60",
                                        children: [
                                            "En continuant, vous acceptez nos",
                                            " ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                href: "/mentions-legales",
                                                className: "underline",
                                                children: "Conditions générales"
                                            }, void 0, false, {
                                                fileName: "[project]/app/auth/signup/page.jsx",
                                                lineNumber: 205,
                                                columnNumber: 15
                                            }, this),
                                            " ",
                                            "et",
                                            " ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                href: "/politique-confidentialite",
                                                className: "underline",
                                                children: "Politique de confidentialité"
                                            }, void 0, false, {
                                                fileName: "[project]/app/auth/signup/page.jsx",
                                                lineNumber: 207,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/auth/signup/page.jsx",
                                        lineNumber: 203,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/auth/signup/page.jsx",
                                lineNumber: 193,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/auth/signup/page.jsx",
                        lineNumber: 156,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/auth/signup/page.jsx",
                lineNumber: 69,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(SignUpPage, "OpHAuaI6Ak16cA5eWOm2lm3IETQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$seo$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuthSEO"]
    ];
});
_c1 = SignUpPage;
var _c, _c1;
__turbopack_context__.k.register(_c, "GoogleIcon");
__turbopack_context__.k.register(_c1, "SignUpPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=_cf883065._.js.map