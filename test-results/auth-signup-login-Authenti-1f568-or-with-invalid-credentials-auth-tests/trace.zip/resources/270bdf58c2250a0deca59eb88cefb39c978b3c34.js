(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_ceaa2696._.js",
  "static/chunks/node_modules_fb40c17f._.js"
],
    source: "dynamic"
});
