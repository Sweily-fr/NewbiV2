(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/ui/separator.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Separator",
    ()=>Separator
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$separator$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-separator/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.js [app-client] (ecmascript)");
"use client";
;
;
;
function Separator(param) {
    let { className, orientation = "horizontal", decorative = true, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$separator$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Root"], {
        "data-slot": "separator",
        decorative: decorative,
        orientation: orientation,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("bg-border shrink-0 data-[orientation=horizontal]:h-px data-[orientation=horizontal]:w-full data-[orientation=vertical]:h-full data-[orientation=vertical]:w-px", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/separator.tsx",
        lineNumber: 15,
        columnNumber: 5
    }, this);
}
_c = Separator;
;
var _c;
__turbopack_context__.k.register(_c, "Separator");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/submit-button.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SubmitButton",
    ()=>SubmitButton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react-dom/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/button.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LoaderCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/loader-circle.js [app-client] (ecmascript) <export default as LoaderCircle>");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
const SubmitButton = (props)=>{
    _s();
    const { pending } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFormStatus"])();
    const { children, isLoading, ...rest } = props;
    // Utiliser soit isLoading (pour react-hook-form) soit pending (pour React Server Actions)
    const loading = isLoading || pending;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
        ...rest,
        disabled: props.disabled || loading,
        className: "".concat(props.className || "", " relative"),
        children: [
            loading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "absolute inset-0 flex items-center justify-center",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LoaderCircle$3e$__["LoaderCircle"], {
                    className: "h-4 w-4 animate-spin"
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/submit-button.jsx",
                    lineNumber: 18,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/components/ui/submit-button.jsx",
                lineNumber: 17,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: loading ? "invisible" : "",
                children: children
            }, void 0, false, {
                fileName: "[project]/src/components/ui/submit-button.jsx",
                lineNumber: 21,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/submit-button.jsx",
        lineNumber: 15,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(SubmitButton, "ChN3pfldoIBH4a0f1nBGB7ED+p0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFormStatus"]
    ];
});
_c = SubmitButton;
;
var _c;
__turbopack_context__.k.register(_c, "SubmitButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/label.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Label",
    ()=>Label
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$label$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Label$3e$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-label/dist/index.mjs [app-client] (ecmascript) <export * as Label>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.js [app-client] (ecmascript)");
"use client";
;
;
;
function Label(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$label$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Label$3e$__["Label"].Root, {
        "data-slot": "label",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("text-foreground text-sm leading-4 font-medium select-none group-data-[disabled=true]:pointer-events-none group-data-[disabled=true]:opacity-50 peer-disabled:cursor-not-allowed peer-disabled:opacity-50", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/label.tsx",
        lineNumber: 13,
        columnNumber: 5
    }, this);
}
_c = Label;
;
var _c;
__turbopack_context__.k.register(_c, "Label");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/input.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Input",
    ()=>Input,
    "InputEmail",
    ()=>InputEmail,
    "InputEndAddOn",
    ()=>InputEndAddOn,
    "InputLoader",
    ()=>InputLoader,
    "InputPassword",
    ()=>InputPassword,
    "InputPhone",
    ()=>InputPhone,
    "inputVariants",
    ()=>inputVariants
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__EyeIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/eye.js [app-client] (ecmascript) <export default as EyeIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2d$off$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__EyeOffIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/eye-off.js [app-client] (ecmascript) <export default as EyeOffIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$phone$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PhoneIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/phone.js [app-client] (ecmascript) <export default as PhoneIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$at$2d$sign$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AtSignIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/at-sign.js [app-client] (ecmascript) <export default as AtSignIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LoaderCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/loader-circle.js [app-client] (ecmascript) <export default as LoaderCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__SearchIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/search.js [app-client] (ecmascript) <export default as SearchIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/label.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature(), _s3 = __turbopack_context__.k.signature(), _s4 = __turbopack_context__.k.signature();
;
;
;
;
;
;
const inputVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("outline-none bg-transparent m-0 flex w-full tracking-[-0.01em] font-medium text-[#242529] placeholder:text-[rgba(0,0,0,0.35)] disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50 dark:text-white dark:placeholder:text-[rgba(255,255,255,0.35)]", {
    variants: {
        variant: {
            default: "border border-[#e6e7ea] hover:border-[#D1D3D8] dark:border-[#2E2E32] dark:hover:border-[#44444A] h-8 rounded-[9px] px-2.5 transition-[border] duration-[80ms] ease-in-out",
            ghost: "border-none p-0 flex-1 h-full"
        },
        size: {
            default: "text-sm leading-5",
            sm: "text-xs leading-4",
            lg: "text-base leading-6"
        }
    },
    defaultVariants: {
        variant: "default",
        size: "default"
    }
});
const Input = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"]((param, ref)=>{
    let { className, variant, size, type = "text", ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
        ref: ref,
        type: type,
        "data-slot": "input",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])(inputVariants({
            variant,
            size,
            className
        })),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/input.jsx",
        lineNumber: 41,
        columnNumber: 7
    }, ("TURBOPACK compile-time value", void 0));
});
_c = Input;
Input.displayName = "Input";
function InputPassword(param) {
    let { className, label, placeholder, ...props } = param;
    _s();
    const id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])();
    const [isVisible, setIsVisible] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const toggleVisibility = ()=>setIsVisible((prevState)=>!prevState);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "*:not-first:mt-2",
        children: [
            label && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                htmlFor: id,
                children: label
            }, void 0, false, {
                fileName: "[project]/src/components/ui/input.jsx",
                lineNumber: 61,
                columnNumber: 17
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Input, {
                        id: id,
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("pe-9", className),
                        placeholder: placeholder,
                        type: isVisible ? "text" : "password",
                        ...props
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/input.jsx",
                        lineNumber: 63,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: "text-[rgba(0,0,0,0.35)] hover:text-[#242529] dark:text-[rgba(255,255,255,0.35)] dark:hover:text-white absolute inset-y-0 end-0 flex h-full w-9 items-center justify-center rounded-e-[9px] transition-colors outline-none focus:z-10 disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50",
                        type: "button",
                        onClick: toggleVisibility,
                        "aria-label": isVisible ? "Masquer le mot de passe" : "Afficher le mot de passe",
                        "aria-pressed": isVisible,
                        "aria-controls": id,
                        children: isVisible ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2d$off$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__EyeOffIcon$3e$__["EyeOffIcon"], {
                            size: 16,
                            "aria-hidden": "true"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/input.jsx",
                            lineNumber: 81,
                            columnNumber: 13
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__EyeIcon$3e$__["EyeIcon"], {
                            size: 16,
                            "aria-hidden": "true"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/input.jsx",
                            lineNumber: 83,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/input.jsx",
                        lineNumber: 70,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ui/input.jsx",
                lineNumber: 62,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/input.jsx",
        lineNumber: 60,
        columnNumber: 5
    }, this);
}
_s(InputPassword, "C12BMw8Iv3tohZ5yEnZ9kw/8AHg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"]
    ];
});
_c1 = InputPassword;
function InputEmail(param) {
    let { className, label, placeholder, ...props } = param;
    _s1();
    const id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "*:not-first:mt-2",
        children: [
            label && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                htmlFor: id,
                children: label
            }, void 0, false, {
                fileName: "[project]/src/components/ui/input.jsx",
                lineNumber: 95,
                columnNumber: 17
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Input, {
                        id: id,
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("peer ps-9", className),
                        placeholder: placeholder,
                        type: "email",
                        ...props
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/input.jsx",
                        lineNumber: 97,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-[rgba(0,0,0,0.35)] dark:text-[rgba(255,255,255,0.35)] pointer-events-none absolute inset-y-0 start-0 flex items-center justify-center ps-3 peer-disabled:opacity-50",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$at$2d$sign$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AtSignIcon$3e$__["AtSignIcon"], {
                            size: 16,
                            "aria-hidden": "true"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/input.jsx",
                            lineNumber: 105,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/input.jsx",
                        lineNumber: 104,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ui/input.jsx",
                lineNumber: 96,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/input.jsx",
        lineNumber: 94,
        columnNumber: 5
    }, this);
}
_s1(InputEmail, "WhsuKpSQZEWeFcB7gWlfDRQktoQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"]
    ];
});
_c2 = InputEmail;
function InputPhone(param) {
    let { className, label, placeholder = "Numéro de téléphone", ...props } = param;
    _s2();
    const id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "*:not-first:mt-2",
        children: [
            label && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                htmlFor: id,
                children: label
            }, void 0, false, {
                fileName: "[project]/src/components/ui/input.jsx",
                lineNumber: 122,
                columnNumber: 17
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Input, {
                        id: id,
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("peer ps-9", className),
                        placeholder: placeholder,
                        type: "tel",
                        ...props
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/input.jsx",
                        lineNumber: 124,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-[rgba(0,0,0,0.35)] dark:text-[rgba(255,255,255,0.35)] pointer-events-none absolute inset-y-0 start-0 flex items-center justify-center ps-3 peer-disabled:opacity-50",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$phone$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PhoneIcon$3e$__["PhoneIcon"], {
                            size: 16,
                            "aria-hidden": "true"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/input.jsx",
                            lineNumber: 132,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/input.jsx",
                        lineNumber: 131,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ui/input.jsx",
                lineNumber: 123,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/input.jsx",
        lineNumber: 121,
        columnNumber: 5
    }, this);
}
_s2(InputPhone, "WhsuKpSQZEWeFcB7gWlfDRQktoQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"]
    ];
});
_c3 = InputPhone;
function InputEndAddOn(param) {
    let { className, label, placeholder, ...props } = param;
    _s3();
    const id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "*:not-first:mt-2",
        children: [
            label && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                htmlFor: id,
                children: label
            }, void 0, false, {
                fileName: "[project]/src/components/ui/input.jsx",
                lineNumber: 143,
                columnNumber: 17
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "border border-[#e6e7ea] dark:border-[#2E2E32] bg-transparent text-[#242529] dark:text-white -z-10 inline-flex items-center rounded-s-[9px] border-e-0 px-3 text-sm font-medium",
                        children: "https://"
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/input.jsx",
                        lineNumber: 145,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Input, {
                        id: id,
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("rounded-s-none border-s-0", className),
                        placeholder: placeholder,
                        type: "text",
                        ...props
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/input.jsx",
                        lineNumber: 148,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ui/input.jsx",
                lineNumber: 144,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/input.jsx",
        lineNumber: 142,
        columnNumber: 5
    }, this);
}
_s3(InputEndAddOn, "WhsuKpSQZEWeFcB7gWlfDRQktoQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"]
    ];
});
_c4 = InputEndAddOn;
function InputLoader(param) {
    let { className, label, placeholder, ...props } = param;
    _s4();
    const id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])();
    const [inputValue, setInputValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "InputLoader.useEffect": ()=>{
            if (inputValue) {
                setIsLoading(true);
                const timer = setTimeout({
                    "InputLoader.useEffect.timer": ()=>{
                        setIsLoading(false);
                    }
                }["InputLoader.useEffect.timer"], 500);
                return ({
                    "InputLoader.useEffect": ()=>clearTimeout(timer)
                })["InputLoader.useEffect"];
            }
            setIsLoading(false);
        }
    }["InputLoader.useEffect"], [
        inputValue
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "*:not-first:mt-2",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                htmlFor: id,
                children: label
            }, void 0, false, {
                fileName: "[project]/src/components/ui/input.jsx",
                lineNumber: 178,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Input, {
                        id: id,
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("peer ps-9", className),
                        placeholder: placeholder,
                        type: "search",
                        value: inputValue,
                        onChange: (e)=>setInputValue(e.target.value)
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/input.jsx",
                        lineNumber: 180,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-[rgba(0,0,0,0.35)] dark:text-[rgba(255,255,255,0.35)] pointer-events-none absolute inset-y-0 start-0 flex items-center justify-center ps-3 peer-disabled:opacity-50",
                        children: isLoading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LoaderCircle$3e$__["LoaderCircle"], {
                            className: "animate-spin",
                            size: 16,
                            role: "status",
                            "aria-label": "Loading..."
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/input.jsx",
                            lineNumber: 190,
                            columnNumber: 13
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__SearchIcon$3e$__["SearchIcon"], {
                            size: 16,
                            "aria-hidden": "true"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/input.jsx",
                            lineNumber: 197,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/input.jsx",
                        lineNumber: 188,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ui/input.jsx",
                lineNumber: 179,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/input.jsx",
        lineNumber: 177,
        columnNumber: 5
    }, this);
}
_s4(InputLoader, "v1LfJkBREdwQ2Uci8a2usuJxJd8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"]
    ];
});
_c5 = InputLoader;
;
var _c, _c1, _c2, _c3, _c4, _c5;
__turbopack_context__.k.register(_c, "Input");
__turbopack_context__.k.register(_c1, "InputPassword");
__turbopack_context__.k.register(_c2, "InputEmail");
__turbopack_context__.k.register(_c3, "InputPhone");
__turbopack_context__.k.register(_c4, "InputEndAddOn");
__turbopack_context__.k.register(_c5, "InputLoader");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/visually-hidden.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "VisuallyHidden",
    ()=>VisuallyHidden
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.js [app-client] (ecmascript)");
"use client";
;
;
/**
 * VisuallyHidden component hides content visually but keeps it accessible to screen readers.
 * Use this to meet accessibility requirements while maintaining visual design.
 */ function VisuallyHidden(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("absolute h-px w-px overflow-hidden whitespace-nowrap border-0 p-0", "[clip:rect(0,0,0,0)]", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/visually-hidden.tsx",
        lineNumber: 15,
        columnNumber: 5
    }, this);
}
_c = VisuallyHidden;
;
var _c;
__turbopack_context__.k.register(_c, "VisuallyHidden");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/dialog.jsx [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Dialog",
    ()=>Dialog,
    "DialogClose",
    ()=>DialogClose,
    "DialogContent",
    ()=>DialogContent,
    "DialogDescription",
    ()=>DialogDescription,
    "DialogFooter",
    ()=>DialogFooter,
    "DialogHeader",
    ()=>DialogHeader,
    "DialogOverlay",
    ()=>DialogOverlay,
    "DialogPortal",
    ()=>DialogPortal,
    "DialogTitle",
    ()=>DialogTitle,
    "DialogTrigger",
    ()=>DialogTrigger
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-dialog/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/x.js [app-client] (ecmascript) <export default as XIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$visually$2d$hidden$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/visually-hidden.tsx [app-client] (ecmascript)");
"use client";
;
;
;
;
;
;
function Dialog(param) {
    let { ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Root"], {
        "data-slot": "dialog",
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/dialog.jsx",
        lineNumber: 11,
        columnNumber: 10
    }, this);
}
_c = Dialog;
function DialogTrigger(param) {
    let { ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Trigger"], {
        "data-slot": "dialog-trigger",
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/dialog.jsx",
        lineNumber: 15,
        columnNumber: 10
    }, this);
}
_c1 = DialogTrigger;
function DialogPortal(param) {
    let { ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Portal"], {
        "data-slot": "dialog-portal",
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/dialog.jsx",
        lineNumber: 19,
        columnNumber: 10
    }, this);
}
_c2 = DialogPortal;
function DialogClose(param) {
    let { ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Close"], {
        "data-slot": "dialog-close",
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/dialog.jsx",
        lineNumber: 23,
        columnNumber: 10
    }, this);
}
_c3 = DialogClose;
function DialogOverlay(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Overlay"], {
        "data-slot": "dialog-overlay",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 fixed inset-0 z-50 bg-black/35", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/dialog.jsx",
        lineNumber: 28,
        columnNumber: 5
    }, this);
}
_c4 = DialogOverlay;
function DialogContent(param) {
    let { className, children, showCloseButton = true, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(DialogPortal, {
        "data-slot": "dialog-portal",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(DialogOverlay, {}, void 0, false, {
                fileName: "[project]/src/components/ui/dialog.jsx",
                lineNumber: 47,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Content"], {
                "data-slot": "dialog-content",
                style: {
                    boxShadow: "rgba(255, 255, 255, 0) 0px 0px 0px 1px inset, rgba(28, 40, 64, 0.12) 0px 8px 28px -6px, rgba(28, 40, 64, 0.16) 0px 18px 88px -4px"
                },
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("bg-background data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 fixed top-[50%] left-[50%] z-50 grid w-full max-w-[calc(100%-2rem)] translate-x-[-50%] translate-y-[-50%] gap-4 rounded-xl border p-6 duration-200 sm:max-w-lg", className),
                ...props,
                children: [
                    children,
                    showCloseButton && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Close"], {
                        "data-slot": "dialog-close",
                        className: "ring-offset-background focus:ring-ring data-[state=open]:bg-accent data-[state=open]:text-muted-foreground absolute top-4 right-4 rounded-xs opacity-70 transition-opacity hover:opacity-100 focus:ring-2 focus:ring-offset-2 focus:outline-hidden disabled:pointer-events-none cursor-pointer [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XIcon$3e$__["XIcon"], {}, void 0, false, {
                                fileName: "[project]/src/components/ui/dialog.jsx",
                                lineNumber: 63,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "sr-only",
                                children: "Close"
                            }, void 0, false, {
                                fileName: "[project]/src/components/ui/dialog.jsx",
                                lineNumber: 64,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/ui/dialog.jsx",
                        lineNumber: 59,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ui/dialog.jsx",
                lineNumber: 48,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/dialog.jsx",
        lineNumber: 46,
        columnNumber: 5
    }, this);
}
_c5 = DialogContent;
function DialogHeader(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "dialog-header",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex flex-col gap-2 text-center sm:text-left", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/dialog.jsx",
        lineNumber: 74,
        columnNumber: 5
    }, this);
}
_c6 = DialogHeader;
function DialogFooter(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "dialog-footer",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex flex-col-reverse gap-2 sm:flex-row sm:justify-end", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/dialog.jsx",
        lineNumber: 84,
        columnNumber: 5
    }, this);
}
_c7 = DialogFooter;
function DialogTitle(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Title"], {
        "data-slot": "dialog-title",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("text-lg leading-none font-semibold", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/dialog.jsx",
        lineNumber: 97,
        columnNumber: 5
    }, this);
}
_c8 = DialogTitle;
function DialogDescription(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Description"], {
        "data-slot": "dialog-description",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("text-muted-foreground text-sm", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/dialog.jsx",
        lineNumber: 107,
        columnNumber: 5
    }, this);
}
_c9 = DialogDescription;
;
var _c, _c1, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9;
__turbopack_context__.k.register(_c, "Dialog");
__turbopack_context__.k.register(_c1, "DialogTrigger");
__turbopack_context__.k.register(_c2, "DialogPortal");
__turbopack_context__.k.register(_c3, "DialogClose");
__turbopack_context__.k.register(_c4, "DialogOverlay");
__turbopack_context__.k.register(_c5, "DialogContent");
__turbopack_context__.k.register(_c6, "DialogHeader");
__turbopack_context__.k.register(_c7, "DialogFooter");
__turbopack_context__.k.register(_c8, "DialogTitle");
__turbopack_context__.k.register(_c9, "DialogDescription");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/otp-input.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "OtpInput",
    ()=>OtpInput
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$input$2d$otp$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/input-otp/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$minus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MinusIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/minus.js [app-client] (ecmascript) <export default as MinusIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/label.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
function OtpInput(param) {
    let { value, onChange, maxLength = 6, label, className, disabled = false, ...props } = param;
    _s();
    const id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("space-y-2", className),
        children: [
            label && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                htmlFor: id,
                className: "text-sm font-normal",
                children: label
            }, void 0, false, {
                fileName: "[project]/src/components/otp-input.jsx",
                lineNumber: 24,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$input$2d$otp$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OTPInput"], {
                id: id,
                value: value,
                onChange: (newValue)=>{
                    onChange(newValue);
                },
                maxLength: maxLength,
                disabled: disabled,
                containerClassName: "flex items-center gap-3 has-disabled:opacity-50",
                render: (param)=>{
                    let { slots } = param;
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex",
                                children: slots.slice(0, 3).map((slot, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Slot, {
                                        ...slot
                                    }, idx, false, {
                                        fileName: "[project]/src/components/otp-input.jsx",
                                        lineNumber: 41,
                                        columnNumber: 17
                                    }, void 0))
                            }, void 0, false, {
                                fileName: "[project]/src/components/otp-input.jsx",
                                lineNumber: 39,
                                columnNumber: 13
                            }, void 0),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-muted-foreground/80",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$minus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MinusIcon$3e$__["MinusIcon"], {
                                    size: 16,
                                    "aria-hidden": "true"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/otp-input.jsx",
                                    lineNumber: 46,
                                    columnNumber: 15
                                }, void 0)
                            }, void 0, false, {
                                fileName: "[project]/src/components/otp-input.jsx",
                                lineNumber: 45,
                                columnNumber: 13
                            }, void 0),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex",
                                children: slots.slice(3).map((slot, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Slot, {
                                        ...slot
                                    }, idx, false, {
                                        fileName: "[project]/src/components/otp-input.jsx",
                                        lineNumber: 51,
                                        columnNumber: 17
                                    }, void 0))
                            }, void 0, false, {
                                fileName: "[project]/src/components/otp-input.jsx",
                                lineNumber: 49,
                                columnNumber: 13
                            }, void 0)
                        ]
                    }, void 0, true);
                },
                ...props
            }, void 0, false, {
                fileName: "[project]/src/components/otp-input.jsx",
                lineNumber: 28,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/otp-input.jsx",
        lineNumber: 22,
        columnNumber: 5
    }, this);
}
_s(OtpInput, "WhsuKpSQZEWeFcB7gWlfDRQktoQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"]
    ];
});
_c = OtpInput;
function Slot(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("border-input bg-background text-foreground relative -ms-px flex size-9 items-center justify-center border font-medium shadow-xs transition-[color,box-shadow] first:ms-0 first:rounded-s-md last:rounded-e-md", {
            "border-ring ring-ring/50 z-10 ring-[3px]": props.isActive
        }),
        children: props.char !== null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: props.char
        }, void 0, false, {
            fileName: "[project]/src/components/otp-input.jsx",
            lineNumber: 70,
            columnNumber: 31
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/otp-input.jsx",
        lineNumber: 64,
        columnNumber: 5
    }, this);
}
_c1 = Slot;
var _c, _c1;
__turbopack_context__.k.register(_c, "OtpInput");
__turbopack_context__.k.register(_c1, "Slot");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/auth/login/components/TwoFactorModal.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TwoFactorModal",
    ()=>TwoFactorModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/components/ui/dialog.jsx [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/label.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$otp$2d$input$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/otp-input.jsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
function TwoFactorModal(param) {
    let { isOpen, onClose, onVerify } = param;
    _s();
    const [verificationCode, setVerificationCode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const handleVerifyCodeWithValue = async (code)=>{
        if (!code || code.length !== 6) return;
        setIsLoading(true);
        try {
            const success = await onVerify(code);
            if (success) {
                onClose();
            } else {
                setVerificationCode("");
            }
        } catch (error) {
            console.error("Erreur vérification 2FA:", error);
            setVerificationCode("");
        } finally{
            setIsLoading(false);
        }
    };
    const handleClose = ()=>{
        setVerificationCode("");
        setIsLoading(false);
        onClose();
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Dialog"], {
        open: isOpen,
        onOpenChange: handleClose,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["DialogContent"], {
            className: "sm:max-w-[425px]",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["DialogHeader"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["DialogTitle"], {
                            children: "Vérification en 2 étapes"
                        }, void 0, false, {
                            fileName: "[project]/app/auth/login/components/TwoFactorModal.jsx",
                            lineNumber: 48,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["DialogDescription"], {
                            children: "Saisissez le code de vérification à 6 chiffres que vous avez reçu."
                        }, void 0, false, {
                            fileName: "[project]/app/auth/login/components/TwoFactorModal.jsx",
                            lineNumber: 49,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/auth/login/components/TwoFactorModal.jsx",
                    lineNumber: 47,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "space-y-4",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-center",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                htmlFor: "verification-code",
                                children: "Code de vérification"
                            }, void 0, false, {
                                fileName: "[project]/app/auth/login/components/TwoFactorModal.jsx",
                                lineNumber: 56,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mt-4 flex justify-center",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$otp$2d$input$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OtpInput"], {
                                    value: verificationCode,
                                    onChange: (value)=>{
                                        setVerificationCode(value);
                                        // Vérification automatique quand le code est complet
                                        if (value.length === 6) {
                                            handleVerifyCodeWithValue(value);
                                        }
                                    },
                                    maxLength: 6,
                                    disabled: isLoading
                                }, void 0, false, {
                                    fileName: "[project]/app/auth/login/components/TwoFactorModal.jsx",
                                    lineNumber: 58,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/auth/login/components/TwoFactorModal.jsx",
                                lineNumber: 57,
                                columnNumber: 13
                            }, this),
                            isLoading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mt-4 text-sm text-muted-foreground",
                                children: "Vérification en cours..."
                            }, void 0, false, {
                                fileName: "[project]/app/auth/login/components/TwoFactorModal.jsx",
                                lineNumber: 72,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/auth/login/components/TwoFactorModal.jsx",
                        lineNumber: 55,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/auth/login/components/TwoFactorModal.jsx",
                    lineNumber: 54,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/auth/login/components/TwoFactorModal.jsx",
            lineNumber: 46,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/auth/login/components/TwoFactorModal.jsx",
        lineNumber: 45,
        columnNumber: 5
    }, this);
}
_s(TwoFactorModal, "VxAY9fo7jP4uPUiuY2PK1UWVgwQ=");
_c = TwoFactorModal;
var _c;
__turbopack_context__.k.register(_c, "TwoFactorModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/alert-dialog.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AlertDialog",
    ()=>AlertDialog,
    "AlertDialogAction",
    ()=>AlertDialogAction,
    "AlertDialogCancel",
    ()=>AlertDialogCancel,
    "AlertDialogContent",
    ()=>AlertDialogContent,
    "AlertDialogDescription",
    ()=>AlertDialogDescription,
    "AlertDialogFooter",
    ()=>AlertDialogFooter,
    "AlertDialogHeader",
    ()=>AlertDialogHeader,
    "AlertDialogOverlay",
    ()=>AlertDialogOverlay,
    "AlertDialogPortal",
    ()=>AlertDialogPortal,
    "AlertDialogTitle",
    ()=>AlertDialogTitle,
    "AlertDialogTrigger",
    ()=>AlertDialogTrigger
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$alert$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-alert-dialog/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/button.jsx [app-client] (ecmascript)");
"use client";
;
;
;
;
;
function AlertDialog(param) {
    let { ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$alert$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Root"], {
        "data-slot": "alert-dialog",
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/alert-dialog.jsx",
        lineNumber: 12,
        columnNumber: 10
    }, this);
}
_c = AlertDialog;
function AlertDialogTrigger(param) {
    let { ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$alert$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Trigger"], {
        "data-slot": "alert-dialog-trigger",
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/alert-dialog.jsx",
        lineNumber: 19,
        columnNumber: 5
    }, this);
}
_c1 = AlertDialogTrigger;
function AlertDialogPortal(param) {
    let { ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$alert$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Portal"], {
        "data-slot": "alert-dialog-portal",
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/alert-dialog.jsx",
        lineNumber: 27,
        columnNumber: 5
    }, this);
}
_c2 = AlertDialogPortal;
function AlertDialogOverlay(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$alert$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Overlay"], {
        "data-slot": "alert-dialog-overlay",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 fixed inset-0 z-50 bg-black/50", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/alert-dialog.jsx",
        lineNumber: 36,
        columnNumber: 5
    }, this);
}
_c3 = AlertDialogOverlay;
function AlertDialogContent(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(AlertDialogPortal, {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(AlertDialogOverlay, {}, void 0, false, {
                fileName: "[project]/src/components/ui/alert-dialog.jsx",
                lineNumber: 53,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$alert$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Content"], {
                "data-slot": "alert-dialog-content",
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("bg-background data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 fixed top-[50%] left-[50%] z-50 grid w-full max-w-[calc(100%-2rem)] translate-x-[-50%] translate-y-[-50%] gap-4 rounded-2xl border p-6 shadow-lg duration-200 sm:max-w-fit", className),
                ...props
            }, void 0, false, {
                fileName: "[project]/src/components/ui/alert-dialog.jsx",
                lineNumber: 54,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/alert-dialog.jsx",
        lineNumber: 52,
        columnNumber: 5
    }, this);
}
_c4 = AlertDialogContent;
function AlertDialogHeader(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "alert-dialog-header",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex flex-col gap-2 text-center sm:text-left", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/alert-dialog.jsx",
        lineNumber: 71,
        columnNumber: 5
    }, this);
}
_c5 = AlertDialogHeader;
function AlertDialogFooter(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "alert-dialog-footer",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex flex-col-reverse gap-2 sm:flex-row sm:justify-end", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/alert-dialog.jsx",
        lineNumber: 84,
        columnNumber: 5
    }, this);
}
_c6 = AlertDialogFooter;
function AlertDialogTitle(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$alert$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Title"], {
        "data-slot": "alert-dialog-title",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("text-lg font-medium", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/alert-dialog.jsx",
        lineNumber: 100,
        columnNumber: 5
    }, this);
}
_c7 = AlertDialogTitle;
function AlertDialogDescription(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$alert$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Description"], {
        "data-slot": "alert-dialog-description",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("text-muted-foreground text-sm", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/alert-dialog.jsx",
        lineNumber: 113,
        columnNumber: 5
    }, this);
}
_c8 = AlertDialogDescription;
function AlertDialogAction(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$alert$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Action"], {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buttonVariants"])(), className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/alert-dialog.jsx",
        lineNumber: 126,
        columnNumber: 5
    }, this);
}
_c9 = AlertDialogAction;
function AlertDialogCancel(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$alert$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Cancel"], {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buttonVariants"])({
            variant: "outline"
        }), className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/alert-dialog.jsx",
        lineNumber: 138,
        columnNumber: 5
    }, this);
}
_c10 = AlertDialogCancel;
;
var _c, _c1, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10;
__turbopack_context__.k.register(_c, "AlertDialog");
__turbopack_context__.k.register(_c1, "AlertDialogTrigger");
__turbopack_context__.k.register(_c2, "AlertDialogPortal");
__turbopack_context__.k.register(_c3, "AlertDialogOverlay");
__turbopack_context__.k.register(_c4, "AlertDialogContent");
__turbopack_context__.k.register(_c5, "AlertDialogHeader");
__turbopack_context__.k.register(_c6, "AlertDialogFooter");
__turbopack_context__.k.register(_c7, "AlertDialogTitle");
__turbopack_context__.k.register(_c8, "AlertDialogDescription");
__turbopack_context__.k.register(_c9, "AlertDialogAction");
__turbopack_context__.k.register(_c10, "AlertDialogCancel");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/auth/login/components/EmailVerificationDialog.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "EmailVerificationDialog",
    ()=>EmailVerificationDialog
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$alert$2d$dialog$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/alert-dialog.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/button.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$submit$2d$button$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/submit-button.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$sonner$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/sonner.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/auth-client.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mail$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Mail$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/mail.js [app-client] (ecmascript) <export default as Mail>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2d$big$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/circle-check-big.js [app-client] (ecmascript) <export default as CheckCircle>");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
const EmailVerificationDialog = (param)=>{
    let { isOpen, onClose, userEmail } = param;
    _s();
    const [isResending, setIsResending] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const handleResendVerification = async ()=>{
        setIsResending(true);
        try {
            // Utiliser l'API Better Auth pour renvoyer l'email de vérification
            const response = await fetch("/api/auth/send-verification-email", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    email: userEmail,
                    callbackURL: "".concat(window.location.origin, "/auth/verify-email")
                })
            });
            if (response.ok) {
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$sonner$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].success("Email de vérification envoyé avec succès !");
            } else {
                const errorData = await response.json();
                console.error("Erreur lors de l'envoi de l'email:", errorData);
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$sonner$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error("Erreur lors de l'envoi de l'email de vérification");
            }
        } catch (error) {
            console.error("Erreur lors de l'envoi de l'email:", error);
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$sonner$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error("Erreur lors de l'envoi de l'email de vérification");
        } finally{
            setIsResending(false);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: isOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "fixed inset-0 z-50 flex items-center justify-center",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "fixed inset-0 bg-black/50 backdrop-blur-sm",
                    onClick: onClose
                }, void 0, false, {
                    fileName: "[project]/app/auth/login/components/EmailVerificationDialog.jsx",
                    lineNumber: 58,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "relative z-[60] w-full max-w-md mx-4 bg-white dark:bg-gray-900 rounded-lg shadow-lg border p-6 animate-in fade-in-0 zoom-in-95 duration-200",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col gap-2 text-center sm:text-left mb-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    className: "text-lg font-semibold",
                                    children: "Vérification d'email requise"
                                }, void 0, false, {
                                    fileName: "[project]/app/auth/login/components/EmailVerificationDialog.jsx",
                                    lineNumber: 66,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-muted-foreground text-sm",
                                    children: "Votre compte n'a pas encore été vérifié. Pour des raisons de sécurité, vous devez vérifier votre adresse email avant de pouvoir vous connecter."
                                }, void 0, false, {
                                    fileName: "[project]/app/auth/login/components/EmailVerificationDialog.jsx",
                                    lineNumber: 69,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/auth/login/components/EmailVerificationDialog.jsx",
                            lineNumber: 65,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "space-y-4 mb-6",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "bg-[#5a50ff]/10 dark:bg-[#5a50ff]/20 p-3 rounded-lg border border-[#5a50ff]/20",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-start gap-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2d$big$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle$3e$__["CheckCircle"], {
                                                className: "h-4 w-4 text-[#5a50ff] mt-0.5 flex-shrink-0"
                                            }, void 0, false, {
                                                fileName: "[project]/app/auth/login/components/EmailVerificationDialog.jsx",
                                                lineNumber: 79,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-sm text-[#5a50ff] dark:text-[#5a50ff]",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "font-medium mb-1",
                                                        children: "Vérifiez votre boîte email :"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/auth/login/components/EmailVerificationDialog.jsx",
                                                        lineNumber: 81,
                                                        columnNumber: 21
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "text-[#5a50ff] dark:text-[#5a50ff] font-mono text-xs bg-[#5a50ff]/10 px-2 py-1 rounded",
                                                        children: userEmail
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/auth/login/components/EmailVerificationDialog.jsx",
                                                        lineNumber: 84,
                                                        columnNumber: 21
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/auth/login/components/EmailVerificationDialog.jsx",
                                                lineNumber: 80,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/auth/login/components/EmailVerificationDialog.jsx",
                                        lineNumber: 78,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/app/auth/login/components/EmailVerificationDialog.jsx",
                                    lineNumber: 77,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-sm text-muted-foreground",
                                    children: "Si vous n'avez pas reçu l'email, vérifiez vos spams ou cliquez sur le bouton ci-dessous pour en recevoir un nouveau."
                                }, void 0, false, {
                                    fileName: "[project]/app/auth/login/components/EmailVerificationDialog.jsx",
                                    lineNumber: 90,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/auth/login/components/EmailVerificationDialog.jsx",
                            lineNumber: 76,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col sm:flex-row gap-2 sm:justify-end",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                    variant: "outline",
                                    onClick: onClose,
                                    className: "w-full sm:w-auto",
                                    children: "Fermer"
                                }, void 0, false, {
                                    fileName: "[project]/app/auth/login/components/EmailVerificationDialog.jsx",
                                    lineNumber: 97,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$submit$2d$button$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SubmitButton"], {
                                    onClick: handleResendVerification,
                                    isLoading: isResending,
                                    className: "w-full sm:w-auto sm:min-w-[180px] font-normal cursor-pointer",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mail$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Mail$3e$__["Mail"], {
                                            className: "h-4 w-4 mr-2"
                                        }, void 0, false, {
                                            fileName: "[project]/app/auth/login/components/EmailVerificationDialog.jsx",
                                            lineNumber: 109,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        "Renvoyer l'email"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/auth/login/components/EmailVerificationDialog.jsx",
                                    lineNumber: 104,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/auth/login/components/EmailVerificationDialog.jsx",
                            lineNumber: 96,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/auth/login/components/EmailVerificationDialog.jsx",
                    lineNumber: 64,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/app/auth/login/components/EmailVerificationDialog.jsx",
            lineNumber: 56,
            columnNumber: 9
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false);
};
_s(EmailVerificationDialog, "wnrCR5NI6MuLBQGoLdXJ5xFbReY=");
_c = EmailVerificationDialog;
var _c;
__turbopack_context__.k.register(_c, "EmailVerificationDialog");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/auth/login/loginForm.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hook$2d$form$2f$dist$2f$index$2e$esm$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-hook-form/dist/index.esm.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$submit$2d$button$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/submit-button.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$input$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/input.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/label.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$sonner$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/sonner.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/auth-client.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$auth$2f$login$2f$components$2f$TwoFactorModal$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/auth/login/components/TwoFactorModal.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$auth$2f$login$2f$components$2f$EmailVerificationDialog$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/auth/login/components/EmailVerificationDialog.jsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
// Fonction pour s'assurer qu'une organisation active est définie
const ensureActiveOrganization = async ()=>{
    try {
        console.log("🔍 [ENSURE ORG] Vérification de l'organisation active...");
        // Vérifier s'il y a déjà une organisation active
        const { data: activeOrg } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authClient"].organization.getActive();
        if (activeOrg) {
            console.log("✅ [ENSURE ORG] Organisation active déjà définie: ".concat(activeOrg.id));
            return;
        }
        console.log("⚠️ [ENSURE ORG] Aucune organisation active, tentative de définition...");
        // Récupérer les organisations de l'utilisateur
        const { data: organizations, error: orgsError } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authClient"].organization.list();
        if (orgsError) {
            console.error("❌ [ENSURE ORG] Erreur lors de la récupération des organisations:", orgsError);
            return;
        }
        console.log("📊 [ENSURE ORG] ".concat((organizations === null || organizations === void 0 ? void 0 : organizations.length) || 0, " organisation(s) trouvée(s)"));
        // Si pas d'organisation active et qu'il y a des organisations disponibles
        if (organizations && organizations.length > 0) {
            let selectedOrg = null;
            // Fast path : une seule org → pas besoin de vérifier les rôles
            if (organizations.length === 1) {
                selectedOrg = organizations[0];
                console.log("✅ [ENSURE ORG] Organisation unique sélectionnée: ".concat(selectedOrg.id));
            } else {
                var _session_user;
                // Multiple orgs : sélection par priorité de rôle
                // Récupérer la session UNE SEULE FOIS avant la boucle
                const { data: session } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authClient"].getSession();
                const currentUserId = session === null || session === void 0 ? void 0 : (_session_user = session.user) === null || _session_user === void 0 ? void 0 : _session_user.id;
                for (const org of organizations){
                    try {
                        const { data: fullOrg } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authClient"].organization.getFullOrganization({
                            organizationId: org.id
                        });
                        if (fullOrg) {
                            var _fullOrg_members;
                            const currentUserMember = (_fullOrg_members = fullOrg.members) === null || _fullOrg_members === void 0 ? void 0 : _fullOrg_members.find((m)=>m.userId === currentUserId);
                            if ((currentUserMember === null || currentUserMember === void 0 ? void 0 : currentUserMember.role) === "owner") {
                                selectedOrg = org;
                                console.log("✅ [ENSURE ORG] Organisation owner trouvée: ".concat(org.id));
                                break; // Priorité maximale, on arrête la recherche
                            } else if ((currentUserMember === null || currentUserMember === void 0 ? void 0 : currentUserMember.role) === "admin" && !selectedOrg) {
                                selectedOrg = org;
                                console.log("✅ [ENSURE ORG] Organisation admin trouvée: ".concat(org.id));
                            }
                        }
                    } catch (error) {
                        console.warn("⚠️ [ENSURE ORG] Erreur récupération org ".concat(org.id, ":"), error);
                    }
                }
                // Si aucune organisation owner/admin trouvée, prendre la première
                if (!selectedOrg) {
                    selectedOrg = organizations[0];
                    console.log("✅ [ENSURE ORG] Première organisation sélectionnée: ".concat(selectedOrg.id));
                }
            }
            const { error: setActiveError } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authClient"].organization.setActive({
                organizationId: selectedOrg.id
            });
            if (setActiveError) {
                console.error("❌ [ENSURE ORG] Erreur lors de la définition de l'organisation active:", setActiveError);
            } else {
                console.log("✅ [ENSURE ORG] Organisation active définie avec succès: ".concat(selectedOrg.id));
            }
        } else {
            console.log("⚠️ [ENSURE ORG] Aucune organisation trouvée, création d'une nouvelle...");
            try {
                // Récupérer l'utilisateur actuel depuis la session
                const { data: session } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authClient"].getSession();
                const user = session === null || session === void 0 ? void 0 : session.user;
                if (!user || !user.id) {
                    console.error("❌ Utilisateur non disponible dans la session:", session);
                    return;
                }
                // Générer le nom et le slug de l'organisation
                const organizationName = user.name || "Espace ".concat(user.email.split("@")[0], "'s");
                const organizationSlug = "org-".concat(user.id.slice(-8));
                console.log("🔄 Création organisation pour ".concat(user.email, "..."));
                // ⚠️ IMPORTANT: Ne plus créer de trial organisation
                // L'utilisateur devra souscrire via Stripe (avec 30 jours d'essai Stripe)
                const result = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authClient"].organization.create({
                    name: organizationName,
                    slug: organizationSlug,
                    metadata: {
                        autoCreated: true,
                        createdAt: new Date().toISOString()
                    },
                    keepCurrentActiveOrganization: false
                });
                if (result.error) {
                    console.error("❌ Erreur lors de la création de l'organisation:", result.error);
                } else {
                    console.log("✅ Organisation créée:", result.data);
                // Pas de toast ici, l'utilisateur sera redirigé vers l'onboarding pour s'abonner
                }
            } catch (error) {
                console.error("❌ Erreur lors de la création automatique:", error);
            }
        }
    } catch (error) {
        console.error("Erreur lors de la vérification de l'organisation active:", error);
    }
};
const LoginForm = ()=>{
    _s();
    const { register, handleSubmit, formState: { errors, isSubmitting }, setError: setFormError } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hook$2d$form$2f$dist$2f$index$2e$esm$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useForm"])();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const [show2FA, setShow2FA] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](false);
    const [twoFactorData, setTwoFactorData] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](null);
    const [showEmailVerification, setShowEmailVerification] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](false);
    const [userEmailForVerification, setUserEmailForVerification] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]("");
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "LoginForm.useEffect": ()=>{}
    }["LoginForm.useEffect"], [
        showEmailVerification,
        userEmailForVerification
    ]);
    const onSubmit = async (formData)=>{
        console.log("🔐 [LOGIN] Tentative de connexion...");
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authClient"].signIn.email(formData, {
            onSuccess: async (ctx)=>{
                console.log("✅ [LOGIN] Connexion réussie, ctx:", ctx);
                // Vérifier si l'utilisateur doit passer par la 2FA
                if (ctx.data.twoFactorRedirect) {
                    console.log("🔒 [LOGIN] Redirection 2FA détectée");
                    console.log("🔒 [LOGIN] Better Auth va rediriger vers /auth/verify-2fa");
                    // ✅ Better Auth gère automatiquement la redirection via onTwoFactorRedirect
                    // Pas besoin d'envoyer d'OTP ici car :
                    // - Pour TOTP (authenticator app) : pas besoin d'OTP, l'utilisateur utilise son app
                    // - Pour OTP (email/SMS) : Better Auth envoie automatiquement l'OTP lors de la connexion
                    setTwoFactorData(ctx.data);
                    setShow2FA(true);
                    return;
                }
                // Connexion réussie — le cookie better-auth.session_token est automatiquement défini
                // Vérifier la limite de sessions ET définir l'organisation active en parallèle
                // Ces deux opérations sont indépendantes l'une de l'autre
                console.log("🔍 [LOGIN] Vérification sessions + organisation en parallèle...");
                const [sessionLimitResult] = await Promise.all([
                    // 1. Vérifier la limite de sessions
                    fetch("/api/check-session-limit", {
                        method: "GET",
                        credentials: "include",
                        headers: {
                            "Content-Type": "application/json"
                        }
                    }).then(async (res)=>{
                        if (res.ok) {
                            const data = await res.json();
                            console.log("📊 [LOGIN] Résultat vérification sessions:", data);
                            return data;
                        }
                        console.warn("⚠️ [LOGIN] Impossible de vérifier la limite de sessions");
                        return null;
                    }).catch((err)=>{
                        console.error("❌ [LOGIN] Erreur vérification sessions:", err);
                        return null; // Continuer la connexion même en cas d'erreur
                    }),
                    // 2. Définir l'organisation active
                    ensureActiveOrganization()
                ]);
                // Vérifier le résultat de la limite de sessions
                if (sessionLimitResult === null || sessionLimitResult === void 0 ? void 0 : sessionLimitResult.hasReachedLimit) {
                    console.log("⚠️ [LOGIN] Limite de sessions atteinte, redirection vers /auth/manage-devices");
                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$sonner$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].info("Vous êtes déjà connecté sur un autre appareil");
                    router.push("/auth/manage-devices");
                    return;
                }
                // Vérifier s'il y a des paramètres d'invitation dans l'URL
                const urlParams = new URLSearchParams(window.location.search);
                let invitationId = urlParams.get("invitation");
                let invitationEmail = urlParams.get("email");
                const callbackUrl = urlParams.get("callbackUrl");
                // Si pas dans l'URL, vérifier dans localStorage (pour les nouveaux utilisateurs)
                if (!invitationId) {
                    const pendingInvitation = localStorage.getItem("pendingInvitation");
                    if (pendingInvitation) {
                        try {
                            const invitation = JSON.parse(pendingInvitation);
                            // Vérifier que l'invitation n'est pas trop ancienne (7 jours max)
                            const sevenDaysInMs = 7 * 24 * 60 * 60 * 1000;
                            if (Date.now() - invitation.timestamp < sevenDaysInMs) {
                                invitationId = invitation.invitationId;
                                invitationEmail = invitation.email;
                                console.log("📋 Invitation récupérée depuis localStorage: ".concat(invitationId));
                            } else {
                                console.log("⚠️ Invitation expirée, suppression");
                                localStorage.removeItem("pendingInvitation");
                            }
                        } catch (error) {
                            console.error("Erreur parsing invitation:", error);
                        }
                    }
                }
                // Si c'est une connexion via invitation, accepter automatiquement l'invitation
                if (invitationId && invitationEmail) {
                    try {
                        const response = await fetch("/api/invitations/".concat(invitationId), {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/json"
                            },
                            body: JSON.stringify({
                                action: "accept"
                            })
                        });
                        const result = await response.json();
                        if (response.ok) {
                            var _session_user;
                            console.log("✅ Invitation acceptée:", result);
                            // ✅ CRITIQUE: Stocker l'organizationId dans localStorage pour Apollo Client
                            if (result.organizationId) {
                                localStorage.setItem("active_organization_id", result.organizationId);
                                console.log("📦 [LOGIN] Organization ID stocké: ".concat(result.organizationId));
                                // ✅ Définir l'organisation active côté client Better Auth
                                await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authClient"].organization.setActive({
                                    organizationId: result.organizationId
                                });
                                console.log("🔄 [LOGIN] Organisation active définie côté client");
                            }
                            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$sonner$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].success("Invitation acceptée ! Bienvenue dans l'organisation.");
                            // ✅ Nettoyer le localStorage après succès
                            localStorage.removeItem("pendingInvitation");
                            // ✅ Vérifier si l'utilisateur est un invité (pas d'org propre)
                            // Dans ce cas, marquer l'onboarding comme vu et rediriger vers le dashboard
                            const { data: session } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authClient"].getSession();
                            const isInvitedUser = session === null || session === void 0 ? void 0 : (_session_user = session.user) === null || _session_user === void 0 ? void 0 : _session_user.isInvitedUser;
                            if (isInvitedUser) {
                                console.log("📨 [LOGIN] Utilisateur invité détecté, skip onboarding");
                                await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authClient"].updateUser({
                                    hasSeenOnboarding: true
                                });
                                router.push("/dashboard?welcome=invited");
                                return;
                            }
                        } else {
                            console.error("❌ Erreur lors de l'acceptation automatique de l'invitation");
                            console.error("Status:", response.status);
                            console.error("Détails:", result);
                            // ✅ Nettoyer le localStorage en cas d'erreur définitive
                            // (invitation expirée, déjà acceptée, etc.)
                            if (response.status === 410 || response.status === 400) {
                                localStorage.removeItem("pendingInvitation");
                                console.log("🗑️ [LOGIN] Invitation invalide, localStorage nettoyé");
                            }
                            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$sonner$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error(result.error || "Erreur lors de l'acceptation de l'invitation");
                        }
                    } catch (error) {
                        console.error("❌ Erreur lors de l'acceptation automatique:", error);
                        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$sonner$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error("Erreur lors de l'acceptation de l'invitation");
                    }
                }
                if (callbackUrl) {
                    router.push(callbackUrl);
                } else {
                    // Vérifier l'abonnement Stripe AVANT de rediriger
                    try {
                        var _session_session, _session_user1, _session_user2, _session_user3;
                        const { data: session } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authClient"].getSession();
                        const organizationId = session === null || session === void 0 ? void 0 : (_session_session = session.session) === null || _session_session === void 0 ? void 0 : _session_session.activeOrganizationId;
                        const hasSeenOnboarding = session === null || session === void 0 ? void 0 : (_session_user1 = session.user) === null || _session_user1 === void 0 ? void 0 : _session_user1.hasSeenOnboarding;
                        const userRedirectPage = session === null || session === void 0 ? void 0 : (_session_user2 = session.user) === null || _session_user2 === void 0 ? void 0 : _session_user2.redirect_after_login;
                        const isInvitedUser = session === null || session === void 0 ? void 0 : (_session_user3 = session.user) === null || _session_user3 === void 0 ? void 0 : _session_user3.isInvitedUser;
                        // ✅ Les utilisateurs invités n'ont pas besoin d'abonnement (ils utilisent celui de l'owner)
                        if (isInvitedUser) {
                            console.log("🎯 [LOGIN] Utilisateur invité, redirection vers dashboard");
                            if (!hasSeenOnboarding) {
                                await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authClient"].updateUser({
                                    hasSeenOnboarding: true
                                });
                            }
                            router.push("/dashboard?welcome=invited");
                            return;
                        }
                        // ⚠️ IMPORTANT: Vérifier l'abonnement Stripe en priorité
                        let hasActiveSubscription = false;
                        if (organizationId) {
                            const { data: subscriptions } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authClient"].subscription.list({
                                query: {
                                    referenceId: organizationId
                                }
                            });
                            hasActiveSubscription = subscriptions === null || subscriptions === void 0 ? void 0 : subscriptions.some((sub)=>sub.status === "active" || sub.status === "trialing");
                        }
                        // Si pas d'abonnement Stripe actif, TOUJOURS rediriger vers onboarding
                        if (!hasActiveSubscription) {
                            console.log("🎯 [LOGIN] Pas d'abonnement Stripe actif, redirection vers onboarding");
                            router.push("/onboarding");
                            return;
                        }
                        // Si l'utilisateur n'a pas vu l'onboarding mais a un abonnement, le rediriger quand même
                        if (!hasSeenOnboarding) {
                            console.log("🎯 [LOGIN] Première connexion avec abonnement, redirection vers onboarding");
                            router.push("/onboarding");
                            return;
                        }
                        // L'utilisateur a un abonnement actif, rediriger vers sa page préférée
                        let redirectPath = "/dashboard";
                        if (userRedirectPage && userRedirectPage !== "last-page") {
                            // Mapper les pages vers leurs vraies routes
                            const routeMap = {
                                dashboard: "/dashboard",
                                outils: "/dashboard",
                                kanban: "/dashboard/outils/kanban",
                                calendar: "/dashboard/calendar",
                                factures: "/dashboard/outils/factures",
                                devis: "/dashboard/outils/devis",
                                clients: "/dashboard/clients",
                                transactions: "/dashboard/outils/transactions",
                                depenses: "/dashboard/outils/transactions",
                                signatures: "/dashboard/outils/signatures-mail",
                                transferts: "/dashboard/outils/transferts-fichiers",
                                "documents-partages": "/dashboard/outils/documents-partages",
                                catalogues: "/dashboard/catalogues",
                                collaborateurs: "/dashboard/collaborateurs"
                            };
                            redirectPath = routeMap[userRedirectPage] || "/dashboard";
                        }
                        router.push(redirectPath);
                    } catch (error) {
                        console.error("Erreur lors de la vérification de l'abonnement:", error);
                        // En cas d'erreur, rediriger vers /onboarding par sécurité
                        router.push("/onboarding");
                    }
                }
            },
            onError: async (error)=>{
                console.log("❌ [LOGIN] Erreur de connexion:", error);
                console.log("❌ [LOGIN] Type d'erreur:", typeof error);
                console.log("❌ [LOGIN] Erreur complète:", JSON.stringify(error, null, 2));
                // Essayer différents formats d'erreur
                let errorMessage = null;
                if (error.message) {
                    errorMessage = error.message;
                } else if (error.error && error.error.message) {
                    errorMessage = error.error.message;
                } else if (typeof error === "string") {
                    errorMessage = error;
                }
                console.log("📝 [LOGIN] Message d'erreur extrait:", errorMessage);
                // Vérifier si c'est une erreur de limite de sessions
                if (errorMessage && (errorMessage.toLowerCase().includes("maximum") || errorMessage.toLowerCase().includes("session") || errorMessage.toLowerCase().includes("limit") || errorMessage.toLowerCase().includes("too many"))) {
                    console.log("⚠️ [LOGIN] Erreur de limite de sessions détectée, redirection...");
                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$sonner$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error("Vous êtes déjà connecté sur un autre appareil");
                    router.push("/auth/manage-devices");
                    return;
                }
                // Vérifier si c'est une erreur de compte désactivé
                if (errorMessage && (errorMessage.includes("désactivé") || errorMessage.includes("réactivation"))) {
                    console.log("🚫 [LOGIN] Compte désactivé");
                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$sonner$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error(errorMessage);
                    return;
                }
                // Vérifier si c'est une erreur de vérification d'email
                if (errorMessage && (errorMessage.includes("vérifier votre adresse email") || errorMessage.includes("email avant de vous connecter") || errorMessage.includes("Veuillez vérifier"))) {
                    console.log("📧 [LOGIN] Email non vérifié");
                    // L'utilisateur existe mais n'a pas vérifié son email
                    setUserEmailForVerification(formData.email);
                    setShowEmailVerification(true);
                    return;
                }
                // Vérifier si l'utilisateur existe mais n'a pas vérifié son email (fallback)
                if (formData.email) {
                    try {
                        const response = await fetch("/api/auth/check-user", {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/json"
                            },
                            body: JSON.stringify({
                                email: formData.email
                            })
                        });
                        if (response.ok) {
                            const userData = await response.json();
                            if (userData.exists && !userData.emailVerified) {
                                // L'utilisateur existe mais n'a pas vérifié son email
                                setUserEmailForVerification(formData.email);
                                setShowEmailVerification(true);
                                return;
                            }
                        }
                    } catch (checkError) {
                        console.log("❌ Erreur lors de la vérification de l'utilisateur:", checkError);
                    }
                }
                // Erreur générique pour les autres cas
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$sonner$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error("Email ou mot de passe incorrect");
            }
        });
    };
    const handleSend2FA = async ()=>{
        try {
            const { data, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authClient"].twoFactor.sendOtp();
            if (error) {
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$sonner$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error("Erreur lors de l'envoi du code de vérification");
                return;
            }
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$sonner$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].success("Code de vérification envoyé");
        } catch (error) {
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$sonner$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error("Erreur lors de l'envoi du code de vérification");
        }
    };
    const handleVerify2FA = async (code)=>{
        try {
            const { data, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authClient"].twoFactor.verifyOtp({
                code: code
            });
            if (error) {
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$sonner$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error("Code de vérification incorrect");
                return false;
            }
            // Définir l'organisation active après la vérification 2FA
            await ensureActiveOrganization();
            // Redirection après vérification 2FA réussie
            const urlParams = new URLSearchParams(window.location.search);
            const invitationId = urlParams.get("invitation");
            const invitationEmail = urlParams.get("email");
            const callbackUrl = urlParams.get("callbackUrl");
            // Si c'est une connexion via invitation, accepter automatiquement l'invitation
            if (invitationId && invitationEmail) {
                try {
                    const response = await fetch("/api/invitations/".concat(invitationId), {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify({
                            action: "accept"
                        })
                    });
                    const result = await response.json();
                    if (response.ok) {
                        var _session_user;
                        // ✅ CRITIQUE: Stocker l'organizationId dans localStorage pour Apollo Client
                        if (result.organizationId) {
                            localStorage.setItem("active_organization_id", result.organizationId);
                            console.log("📦 [2FA] Organization ID stocké: ".concat(result.organizationId));
                            // ✅ Définir l'organisation active côté client Better Auth
                            await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authClient"].organization.setActive({
                                organizationId: result.organizationId
                            });
                            console.log("🔄 [2FA] Organisation active définie côté client");
                        }
                        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$sonner$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].success("Invitation acceptée ! Bienvenue dans l'organisation.");
                        // ✅ Nettoyer le localStorage après succès
                        localStorage.removeItem("pendingInvitation");
                        // ✅ Vérifier si l'utilisateur est un invité (pas d'org propre)
                        const { data: session } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authClient"].getSession();
                        const isInvitedUser = session === null || session === void 0 ? void 0 : (_session_user = session.user) === null || _session_user === void 0 ? void 0 : _session_user.isInvitedUser;
                        if (isInvitedUser) {
                            console.log("📨 [2FA] Utilisateur invité détecté, skip onboarding");
                            await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authClient"].updateUser({
                                hasSeenOnboarding: true
                            });
                            router.push("/dashboard?welcome=invited");
                            return true;
                        }
                    } else {
                        // ✅ Nettoyer le localStorage en cas d'erreur définitive
                        if (response.status === 410 || response.status === 400) {
                            localStorage.removeItem("pendingInvitation");
                        }
                        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$sonner$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error(result.error || "Erreur lors de l'acceptation de l'invitation");
                    }
                } catch (error) {
                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$sonner$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error("Erreur lors de l'acceptation de l'invitation");
                }
            }
            if (callbackUrl) {
                router.push(callbackUrl);
            } else {
                // Vérifier l'abonnement Stripe AVANT de rediriger
                try {
                    var _session_session, _session_user1, _session_user2, _session_user3;
                    const { data: session } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authClient"].getSession();
                    const organizationId = session === null || session === void 0 ? void 0 : (_session_session = session.session) === null || _session_session === void 0 ? void 0 : _session_session.activeOrganizationId;
                    const hasSeenOnboarding = session === null || session === void 0 ? void 0 : (_session_user1 = session.user) === null || _session_user1 === void 0 ? void 0 : _session_user1.hasSeenOnboarding;
                    const userRedirectPage = session === null || session === void 0 ? void 0 : (_session_user2 = session.user) === null || _session_user2 === void 0 ? void 0 : _session_user2.redirect_after_login;
                    const isInvitedUser = session === null || session === void 0 ? void 0 : (_session_user3 = session.user) === null || _session_user3 === void 0 ? void 0 : _session_user3.isInvitedUser;
                    // ✅ Les utilisateurs invités n'ont pas besoin d'abonnement (ils utilisent celui de l'owner)
                    if (isInvitedUser) {
                        console.log("🎯 [2FA] Utilisateur invité, redirection vers dashboard");
                        if (!hasSeenOnboarding) {
                            await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authClient"].updateUser({
                                hasSeenOnboarding: true
                            });
                        }
                        router.push("/dashboard?welcome=invited");
                        return true;
                    }
                    // ⚠️ IMPORTANT: Vérifier l'abonnement Stripe en priorité
                    let hasActiveSubscription = false;
                    if (organizationId) {
                        const { data: subscriptions } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authClient"].subscription.list({
                            query: {
                                referenceId: organizationId
                            }
                        });
                        hasActiveSubscription = subscriptions === null || subscriptions === void 0 ? void 0 : subscriptions.some((sub)=>sub.status === "active" || sub.status === "trialing");
                    }
                    // Si pas d'abonnement Stripe actif, TOUJOURS rediriger vers onboarding
                    if (!hasActiveSubscription) {
                        console.log("🎯 [2FA] Pas d'abonnement Stripe actif, redirection vers onboarding");
                        router.push("/onboarding");
                        return true;
                    }
                    // Si l'utilisateur n'a pas vu l'onboarding mais a un abonnement, le rediriger quand même
                    if (!hasSeenOnboarding) {
                        console.log("🎯 [2FA] Première connexion avec abonnement, redirection vers onboarding");
                        router.push("/onboarding");
                        return true;
                    }
                    // L'utilisateur a un abonnement actif, rediriger vers sa page préférée
                    let redirectPath = "/dashboard";
                    if (userRedirectPage && userRedirectPage !== "last-page") {
                        // Mapper les pages vers leurs vraies routes
                        const routeMap = {
                            dashboard: "/dashboard",
                            outils: "/dashboard",
                            kanban: "/dashboard/outils/kanban",
                            calendar: "/dashboard/calendar",
                            factures: "/dashboard/outils/factures",
                            devis: "/dashboard/outils/devis",
                            clients: "/dashboard/clients",
                            transactions: "/dashboard/outils/transactions",
                            depenses: "/dashboard/outils/transactions",
                            signatures: "/dashboard/outils/signatures-mail",
                            transferts: "/dashboard/outils/transferts-fichiers",
                            "documents-partages": "/dashboard/outils/documents-partages",
                            catalogues: "/dashboard/catalogues",
                            collaborateurs: "/dashboard/collaborateurs",
                            analytics: "/dashboard/analytics",
                            favoris: "/dashboard/favoris"
                        };
                        redirectPath = routeMap[userRedirectPage] || "/dashboard";
                    }
                    router.push(redirectPath);
                } catch (error) {
                    console.error("Erreur lors de la vérification de l'abonnement:", error);
                    // En cas d'erreur, rediriger vers /onboarding par sécurité
                    router.push("/onboarding");
                }
            }
            return true;
        } catch (error) {
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$sonner$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error("Code de vérification incorrect");
            return false;
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
        action: "#",
        method: "post",
        className: "mt-6 space-y-4",
        onSubmit: handleSubmit(onSubmit),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                        htmlFor: "email",
                        className: "text-sm font-medium text-foreground dark:text-foreground",
                        children: "Email"
                    }, void 0, false, {
                        fileName: "[project]/app/auth/login/loginForm.jsx",
                        lineNumber: 756,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$input$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InputEmail"], {
                        id: "email",
                        name: "email",
                        autoComplete: "email",
                        placeholder: "Email",
                        className: "mt-2",
                        ...register("email", {
                            required: "Email est requis",
                            pattern: {
                                value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
                                message: "Email invalide"
                            }
                        })
                    }, void 0, false, {
                        fileName: "[project]/app/auth/login/loginForm.jsx",
                        lineNumber: 762,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    errors.email && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "mt-2 text-sm text-red-500",
                        children: errors.email.message
                    }, void 0, false, {
                        fileName: "[project]/app/auth/login/loginForm.jsx",
                        lineNumber: 777,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/app/auth/login/loginForm.jsx",
                lineNumber: 755,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                        htmlFor: "password",
                        className: "text-sm font-medium text-foreground dark:text-foreground",
                        children: "Mot de passe"
                    }, void 0, false, {
                        fileName: "[project]/app/auth/login/loginForm.jsx",
                        lineNumber: 781,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$input$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InputPassword"], {
                        id: "password",
                        name: "password",
                        autoComplete: "password",
                        placeholder: "Saisissez votre mot de passe",
                        className: "mt-2",
                        ...register("password", {
                            required: "Mot de passe est requis"
                        })
                    }, void 0, false, {
                        fileName: "[project]/app/auth/login/loginForm.jsx",
                        lineNumber: 787,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    errors.password && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "mt-2 text-sm text-red-500",
                        children: errors.password.message
                    }, void 0, false, {
                        fileName: "[project]/app/auth/login/loginForm.jsx",
                        lineNumber: 798,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/app/auth/login/loginForm.jsx",
                lineNumber: 780,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$submit$2d$button$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SubmitButton"], {
                type: "submit",
                size: "lg",
                className: "mt-4 w-full cursor-pointer",
                isLoading: isSubmitting,
                children: "Se connecter"
            }, void 0, false, {
                fileName: "[project]/app/auth/login/loginForm.jsx",
                lineNumber: 801,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$auth$2f$login$2f$components$2f$EmailVerificationDialog$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EmailVerificationDialog"], {
                isOpen: showEmailVerification,
                onClose: ()=>setShowEmailVerification(false),
                userEmail: userEmailForVerification
            }, void 0, false, {
                fileName: "[project]/app/auth/login/loginForm.jsx",
                lineNumber: 818,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/app/auth/login/loginForm.jsx",
        lineNumber: 749,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(LoginForm, "YbEUrXL6CyH13JjTzJ0KxtYIko4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hook$2d$form$2f$dist$2f$index$2e$esm$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useForm"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = LoginForm;
const __TURBOPACK__default__export__ = LoginForm;
var _c;
__turbopack_context__.k.register(_c, "LoginForm");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/auth/api.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getCurrentUser",
    ()=>getCurrentUser,
    "getGoogleAccessToken",
    ()=>getGoogleAccessToken,
    "getGoogleUserProfile",
    ()=>getGoogleUserProfile,
    "loginUser",
    ()=>loginUser,
    "logoutUser",
    ()=>logoutUser,
    "registerUser",
    ()=>registerUser,
    "signInGithub",
    ()=>signInGithub,
    "signInGoogle",
    ()=>signInGoogle,
    "updateUserProfile",
    ()=>updateUserProfile,
    "verifyEmail",
    ()=>verifyEmail
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$api$2d$utils$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/api-utils/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/auth-client.js [app-client] (ecmascript)");
;
;
async function loginUser(formData) {
    let rememberMe = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : false;
    try {
        const { data, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authClient"].signIn.email({
            email: formData.email,
            password: formData.password,
            // callbackURL: "/dashboard",
            rememberMe: rememberMe
        }, {
            onSuccess: ()=>{
                console.log("login");
            //   toast.success("Connexion reussie");
            },
            onError: (error)=>{
                toast.error(error.message);
            }
        });
        if (error) {
            throw new Error(error.message || "Erreur de connexion");
        }
        return data;
    } catch (err) {
        throw new Error(err.message || "Erreur de connexion");
    }
}
async function registerUser(formData) {
    try {
        // Format selon la documentation Better Auth
        const { data, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authClient"].signUp.email({
            email: formData.email,
            password: formData.password,
            name: formData.name,
            // Supprimer passwordConfirmation car non supporté par l'API
            callbackURL: "/dashboard"
        });
        if (error) {
            // Propager le message d'erreur exact de Better Auth
            const errorMessage = error.message || "Erreur lors de l'inscription";
            // Gérer les erreurs spécifiques
            if (errorMessage.toLowerCase().includes("email") && errorMessage.toLowerCase().includes("exist")) {
                throw new Error("Cet email est déjà utilisé");
            } else if (errorMessage.toLowerCase().includes("already")) {
                throw new Error("Cet email est déjà utilisé");
            }
            throw new Error(errorMessage);
        }
        return data;
    } catch (err) {
        // Propager l'erreur sans la modifier
        throw err;
    }
}
async function logoutUser() {
    try {
        const { error } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authClient"].signOut({
            fetchOptions: {
                onSuccess: ()=>{
                    console.log("logout");
                }
            }
        });
        console.log(error);
        if (error) {
            throw new Error(error.message || "Erreur lors de la déconnexion");
        }
        return true;
    } catch (err) {
        throw new Error(err.message || "Erreur lors de la déconnexion");
    }
}
async function getCurrentUser() {
    try {
        const { data, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authClient"].getSession();
        if (error) {
            return null;
        }
        return (data === null || data === void 0 ? void 0 : data.user) || null;
    } catch (err) {
        return null;
    }
}
async function updateUserProfile(formData) {
    try {
        console.log(formData, "update profile");
        // Utiliser l'API Better Auth pour mettre à jour le profil utilisateur
        // Envoyer uniquement les champs fournis dans formData
        const { data, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authClient"].updateUser(formData);
        if (error) {
            throw new Error(error.message || "Erreur lors de la mise à jour du profil");
        }
        return data;
    } catch (err) {
        throw new Error(err.message || "Erreur lors de la mise à jour du profil");
    }
}
const verifyEmail = async (email)=>{
    try {
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authClient"].sendVerificationEmail({
            email: email,
            callbackURL: "/dashboard"
        });
    } catch (err) {
        throw new Error(err.message || "Erreur lors de la vérification de l'email");
    }
};
const signInGoogle = async ()=>{
    try {
        const data = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authClient"].signIn.social({
            provider: "google",
            callbackURL: "/dashboard"
        });
        return data;
    } catch (err) {
        console.error("Erreur lors de la connexion avec Google:", err);
        throw err;
    }
};
const signInGithub = async ()=>{
    try {
        const data = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authClient"].signIn.social({
            provider: "github",
            callbackURL: "/dashboard"
        });
        return data;
    } catch (err) {
        console.error("Erreur lors de la connexion avec Github:", err);
        throw err;
    }
};
const getGoogleAccessToken = async (accountId)=>{
    try {
        const { accessToken } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authClient"].getAccessToken({
            providerId: "google",
            accountId: accountId
        });
        return {
            accessToken
        };
    } catch (err) {
        throw new Error(err.message || "Impossible de récupérer le token Google");
    }
};
const getGoogleUserProfile = async (accessToken)=>{
    try {
        const response = await fetch("https://www.googleapis.com/oauth2/v2/userinfo", {
            headers: {
                Authorization: "Bearer ".concat(accessToken)
            }
        });
        if (!response.ok) {
            throw new Error("Erreur API Google: ".concat(response.status));
        }
        const profileData = await response.json();
        return profileData;
    } catch (err) {
        console.error("Erreur lors de la récupération du profil Google:", err);
        throw new Error(err.message || "Impossible de récupérer le profil Google");
    }
}; // export const accounts = await authClient.listAccounts();
 // console.log(accounts);
 // export const accountsGoogle = accounts.data.filter(
 //   (account) => account.providerId === "google"
 // );
 // console.log(accountsGoogle, "accountsGoogle");
 // export const accounts = await authClient.listAccounts();
 // const accountID = accounts.data.filter(
 //   (account) => account.provider === "google"
 // )[0];
 // console.log(accountID);
 // export const getGoogleTokenForAccount = async () => {
 //   try {
 //     // Récupérer la liste des comptes
 //     const accountsResponse = await authClient.listAccounts();
 //     console.log("Tous les comptes:", accountsResponse);
 //     // Filtrer pour trouver le compte Google
 //     const googleAccount = accountsResponse.data.find(
 //       (account) => account.provider === "google"
 //     );
 //     if (!googleAccount) {
 //       console.error("Aucun compte Google trouvé");
 //       return null;
 //     }
 //     console.log("Compte Google trouvé:", googleAccount);
 //     // Vérifier si l'utilisateur est authentifié
 //     const session = await authClient.getSession();
 //     console.log("Session utilisateur:", session);
 //     if (!session) {
 //       console.error("Utilisateur non authentifié");
 //       return null;
 //     }
 //     // Appel à getAccessToken avec l'ID du compte Google
 //     console.log(
 //       "Tentative de récupération du token pour le compte:",
 //       googleAccount.id
 //     );
 //     const result = await authClient.getAccessToken({
 //       providerId: "google",
 //       accountId: googleAccount.id,
 //     });
 //     console.log("Résultat de getAccessToken:", result);
 //     return result.data.accessToken;
 //   } catch (err) {
 //     console.error("Erreur lors de la récupération du token:", err);
 //     console.error("Détails de l'erreur:", err.response?.data || err.message);
 //     return null;
 //   }
 // };
 // /**
 //  * Vérifie si l'utilisateur est connecté via Google
 //  * @returns {Promise<boolean>} - True si l'utilisateur est connecté via Google
 //  */
 // export const isConnectedWithGoogle = async () => {
 //   try {
 //     // Récupérer la session utilisateur
 //     const session = await authClient.getSession();
 //     if (!session || !session.user) {
 //       return false;
 //     }
 //     // Vérifier si l'utilisateur a un compte Google associé
 //     const accounts = session.user.accounts || [];
 //     return accounts.some((account) => account.providerId === "google");
 //   } catch (err) {
 //     console.error(
 //       "Erreur lors de la vérification de la connexion Google:",
 //       err
 //     );
 //     return false;
 //   }
 // };
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/typewriter-text.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Typewriter",
    ()=>Typewriter
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function Typewriter(param) {
    let { text, speed = 100, cursor = "|", loop = false, deleteSpeed = 50, delay = 1500, className } = param;
    _s();
    const [displayText, setDisplayText] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [currentIndex, setCurrentIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [isDeleting, setIsDeleting] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [textArrayIndex, setTextArrayIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    // Validate and process input text
    const textArray = Array.isArray(text) ? text : [
        text
    ];
    const currentText = textArray[textArrayIndex] || "";
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Typewriter.useEffect": ()=>{
            if (!currentText) return;
            const timeout = setTimeout({
                "Typewriter.useEffect.timeout": ()=>{
                    if (!isDeleting) {
                        if (currentIndex < currentText.length) {
                            setDisplayText({
                                "Typewriter.useEffect.timeout": (prev)=>prev + currentText[currentIndex]
                            }["Typewriter.useEffect.timeout"]);
                            setCurrentIndex({
                                "Typewriter.useEffect.timeout": (prev)=>prev + 1
                            }["Typewriter.useEffect.timeout"]);
                        } else if (loop) {
                            setTimeout({
                                "Typewriter.useEffect.timeout": ()=>setIsDeleting(true)
                            }["Typewriter.useEffect.timeout"], delay);
                        }
                    } else {
                        if (displayText.length > 0) {
                            setDisplayText({
                                "Typewriter.useEffect.timeout": (prev)=>prev.slice(0, -1)
                            }["Typewriter.useEffect.timeout"]);
                        } else {
                            setIsDeleting(false);
                            setCurrentIndex(0);
                            setTextArrayIndex({
                                "Typewriter.useEffect.timeout": (prev)=>(prev + 1) % textArray.length
                            }["Typewriter.useEffect.timeout"]);
                        }
                    }
                }
            }["Typewriter.useEffect.timeout"], isDeleting ? deleteSpeed : speed);
            return ({
                "Typewriter.useEffect": ()=>clearTimeout(timeout)
            })["Typewriter.useEffect"];
        }
    }["Typewriter.useEffect"], [
        currentIndex,
        isDeleting,
        currentText,
        loop,
        speed,
        deleteSpeed,
        delay,
        displayText,
        text
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        className: className,
        children: [
            displayText,
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "animate-pulse",
                children: cursor
            }, void 0, false, {
                fileName: "[project]/src/components/ui/typewriter-text.jsx",
                lineNumber: 65,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/typewriter-text.jsx",
        lineNumber: 63,
        columnNumber: 5
    }, this);
}
_s(Typewriter, "p87dQqAt9kwjvtFjU6ANjx4NS2o=");
_c = Typewriter;
var _c;
__turbopack_context__.k.register(_c, "Typewriter");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/seo/seo-head.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>SEOHead
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$noop$2d$head$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/components/noop-head.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function SEOHead(param) {
    let { title, description, keywords, canonical, openGraph = {}, twitter = {}, jsonLd, robots = "index,follow", author = "Newbi", language = "fr-FR" } = param;
    _s();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const baseUrl = ("TURBOPACK compile-time value", "http://localhost:3000") || "https://newbi.fr";
    // Construction de l'URL canonique
    const canonicalUrl = canonical || "".concat(baseUrl).concat(pathname);
    // Configuration Open Graph par défaut
    const defaultOpenGraph = {
        type: "website",
        locale: "fr_FR",
        url: canonicalUrl,
        siteName: "Newbi - Solution de gestion pour entrepreneurs",
        title: title,
        description: description,
        image: "/images/op-newbi.png",
        imageWidth: 1200,
        imageHeight: 1200,
        ...openGraph
    };
    // Configuration Twitter Card par défaut
    const defaultTwitter = {
        card: "summary_large_image",
        site: "@newbi_fr",
        creator: "@newbi_fr",
        title: title,
        description: description,
        image: "/images/op-newbi.png",
        ...twitter
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$noop$2d$head$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("title", {
                children: title
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 66,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                name: "description",
                content: description
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 67,
                columnNumber: 7
            }, this),
            keywords && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                name: "keywords",
                content: keywords
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 68,
                columnNumber: 20
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                name: "author",
                content: author
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 69,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                name: "robots",
                content: robots
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 70,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                name: "language",
                content: language
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 71,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("link", {
                rel: "canonical",
                href: canonicalUrl
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 74,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                httpEquiv: "content-language",
                content: "fr"
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 77,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                name: "geo.region",
                content: "FR"
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 78,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                name: "geo.country",
                content: "France"
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 79,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                property: "og:type",
                content: defaultOpenGraph.type
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 82,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                property: "og:locale",
                content: defaultOpenGraph.locale
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 83,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                property: "og:url",
                content: defaultOpenGraph.url
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 84,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                property: "og:site_name",
                content: defaultOpenGraph.siteName
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 85,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                property: "og:title",
                content: defaultOpenGraph.title
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 86,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                property: "og:description",
                content: defaultOpenGraph.description
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 87,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                property: "og:image",
                content: defaultOpenGraph.image
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 88,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                property: "og:image:width",
                content: defaultOpenGraph.imageWidth
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 89,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                property: "og:image:height",
                content: defaultOpenGraph.imageHeight
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 90,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                property: "og:image:alt",
                content: defaultOpenGraph.title
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 91,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                name: "twitter:card",
                content: defaultTwitter.card
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 94,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                name: "twitter:site",
                content: defaultTwitter.site
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 95,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                name: "twitter:creator",
                content: defaultTwitter.creator
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 96,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                name: "twitter:title",
                content: defaultTwitter.title
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 97,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                name: "twitter:description",
                content: defaultTwitter.description
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 98,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                name: "twitter:image",
                content: defaultTwitter.image
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 99,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                name: "viewport",
                content: "width=device-width, initial-scale=1.0"
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 102,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                name: "format-detection",
                content: "telephone=no"
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 103,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                name: "revisit-after",
                content: "7 days"
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 106,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                name: "rating",
                content: "general"
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 107,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("link", {
                rel: "icon",
                type: "image/x-icon",
                href: "/favicon.ico"
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 110,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("link", {
                rel: "icon",
                type: "image/png",
                sizes: "32x32",
                href: "/favicon-32x32.png"
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 111,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("link", {
                rel: "icon",
                type: "image/png",
                sizes: "16x16",
                href: "/favicon-16x16.png"
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 112,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("link", {
                rel: "apple-touch-icon",
                sizes: "180x180",
                href: "/apple-touch-icon.png"
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 113,
                columnNumber: 7
            }, this),
            jsonLd && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("script", {
                type: "application/ld+json",
                dangerouslySetInnerHTML: {
                    __html: JSON.stringify(jsonLd)
                }
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 117,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("link", {
                rel: "preconnect",
                href: "https://fonts.googleapis.com"
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 126,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("link", {
                rel: "preconnect",
                href: "https://fonts.gstatic.com",
                crossOrigin: "anonymous"
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-head.jsx",
                lineNumber: 127,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/seo/seo-head.jsx",
        lineNumber: 64,
        columnNumber: 5
    }, this);
}
_s(SEOHead, "xbyQPtUVMO7MNj7WjJlpdWqRcTo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"]
    ];
});
_c = SEOHead;
var _c;
__turbopack_context__.k.register(_c, "SEOHead");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/seo/seo-metadata.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Favicons",
    ()=>Favicons,
    "JsonLd",
    ()=>JsonLd,
    "PerformanceOptimizations",
    ()=>PerformanceOptimizations,
    "SEOProvider",
    ()=>SEOProvider,
    "generateMetadata",
    ()=>generateMetadata
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
"use client";
;
function generateMetadata(seoData) {
    var _window_location, _window, _window_location1, _window1, _window_location2, _window2;
    const { title, description, keywords, canonical, openGraph = {}, twitter = {}, robots = "index,follow", author = "Newbi", language = "fr-FR" } = seoData;
    const baseUrl = ("TURBOPACK compile-time value", "http://localhost:3000") || "https://newbi.fr";
    return {
        title,
        description,
        keywords: keywords === null || keywords === void 0 ? void 0 : keywords.split(", "),
        authors: [
            {
                name: author
            }
        ],
        robots,
        alternates: {
            canonical: canonical || "".concat(baseUrl).concat(((_window = window) === null || _window === void 0 ? void 0 : (_window_location = _window.location) === null || _window_location === void 0 ? void 0 : _window_location.pathname) || ""),
            languages: {
                "fr-FR": canonical || "".concat(baseUrl).concat(((_window1 = window) === null || _window1 === void 0 ? void 0 : (_window_location1 = _window1.location) === null || _window_location1 === void 0 ? void 0 : _window_location1.pathname) || "")
            }
        },
        openGraph: {
            type: "website",
            locale: "fr_FR",
            url: canonical || "".concat(baseUrl).concat(((_window2 = window) === null || _window2 === void 0 ? void 0 : (_window_location2 = _window2.location) === null || _window_location2 === void 0 ? void 0 : _window_location2.pathname) || ""),
            siteName: "Newbi - Solution de gestion pour entrepreneurs",
            title: openGraph.title || title,
            description: openGraph.description || description,
            images: [
                {
                    url: "/images/op-newbi.png",
                    width: openGraph.imageWidth || 1200,
                    height: openGraph.imageHeight || 1200,
                    alt: openGraph.title || title
                }
            ],
            ...openGraph
        },
        twitter: {
            card: "summary_large_image",
            site: "@newbi_fr",
            creator: "@newbi_fr",
            title: twitter.title || title,
            description: twitter.description || description,
            images: [
                "/images/op-newbi.png"
            ],
            ...twitter
        },
        other: {
            "geo.region": "FR",
            "geo.country": "France",
            "language": language,
            "revisit-after": "7 days",
            "rating": "general"
        }
    };
}
function JsonLd(param) {
    let { jsonLd } = param;
    if (!jsonLd) return null;
    // Si c'est un tableau de JSON-LD, on les rend tous
    if (Array.isArray(jsonLd)) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: jsonLd.map((data, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("script", {
                    type: "application/ld+json",
                    dangerouslySetInnerHTML: {
                        __html: JSON.stringify(data)
                    }
                }, index, false, {
                    fileName: "[project]/src/components/seo/seo-metadata.jsx",
                    lineNumber: 88,
                    columnNumber: 11
                }, this))
        }, void 0, false);
    }
    // Sinon, on rend un seul JSON-LD
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("script", {
        type: "application/ld+json",
        dangerouslySetInnerHTML: {
            __html: JSON.stringify(jsonLd)
        }
    }, void 0, false, {
        fileName: "[project]/src/components/seo/seo-metadata.jsx",
        lineNumber: 102,
        columnNumber: 5
    }, this);
}
_c = JsonLd;
function Favicons() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("link", {
                rel: "icon",
                type: "image/x-icon",
                href: "/favicon.ico"
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-metadata.jsx",
                lineNumber: 117,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("link", {
                rel: "icon",
                type: "image/png",
                sizes: "32x32",
                href: "/favicon-32x32.png"
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-metadata.jsx",
                lineNumber: 118,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("link", {
                rel: "icon",
                type: "image/png",
                sizes: "16x16",
                href: "/favicon-16x16.png"
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-metadata.jsx",
                lineNumber: 119,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("link", {
                rel: "apple-touch-icon",
                sizes: "180x180",
                href: "/apple-touch-icon.png"
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-metadata.jsx",
                lineNumber: 120,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("link", {
                rel: "manifest",
                href: "/site.webmanifest"
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-metadata.jsx",
                lineNumber: 121,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                name: "theme-color",
                content: "#5B4FFF"
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-metadata.jsx",
                lineNumber: 122,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                name: "msapplication-TileColor",
                content: "#5B4FFF"
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-metadata.jsx",
                lineNumber: 123,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_c1 = Favicons;
function PerformanceOptimizations() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("link", {
                rel: "preconnect",
                href: "https://fonts.googleapis.com"
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-metadata.jsx",
                lineNumber: 134,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("link", {
                rel: "preconnect",
                href: "https://fonts.gstatic.com",
                crossOrigin: "anonymous"
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-metadata.jsx",
                lineNumber: 135,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("link", {
                rel: "dns-prefetch",
                href: "https://api.newbi.fr"
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-metadata.jsx",
                lineNumber: 136,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("link", {
                rel: "dns-prefetch",
                href: "https://cdn.newbi.fr"
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-metadata.jsx",
                lineNumber: 137,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_c2 = PerformanceOptimizations;
function SEOProvider(param) {
    let { children, jsonLd } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Favicons, {}, void 0, false, {
                fileName: "[project]/src/components/seo/seo-metadata.jsx",
                lineNumber: 149,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(PerformanceOptimizations, {}, void 0, false, {
                fileName: "[project]/src/components/seo/seo-metadata.jsx",
                lineNumber: 150,
                columnNumber: 7
            }, this),
            jsonLd && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(JsonLd, {
                jsonLd: jsonLd
            }, void 0, false, {
                fileName: "[project]/src/components/seo/seo-metadata.jsx",
                lineNumber: 151,
                columnNumber: 18
            }, this),
            children
        ]
    }, void 0, true);
}
_c3 = SEOProvider;
var _c, _c1, _c2, _c3;
__turbopack_context__.k.register(_c, "JsonLd");
__turbopack_context__.k.register(_c1, "Favicons");
__turbopack_context__.k.register(_c2, "PerformanceOptimizations");
__turbopack_context__.k.register(_c3, "SEOProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/seo-data.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Configuration SEO centralisée pour toutes les pages du site
 * Contient les métadonnées, descriptions, mots-clés et données structurées
 */ __turbopack_context__.s([
    "defaultSEO",
    ()=>defaultSEO,
    "generateBasicJsonLd",
    ()=>generateBasicJsonLd,
    "generateBreadcrumbsJsonLd",
    ()=>generateBreadcrumbsJsonLd,
    "generateFAQJsonLd",
    ()=>generateFAQJsonLd,
    "generateMetaTags",
    ()=>generateMetaTags,
    "generateNextMetadata",
    ()=>generateNextMetadata,
    "generateReviewsJsonLd",
    ()=>generateReviewsJsonLd,
    "generateSitemap",
    ()=>generateSitemap,
    "getSEOData",
    ()=>getSEOData,
    "seoData",
    ()=>seoData,
    "validateSEOData",
    ()=>validateSEOData
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
const baseUrl = ("TURBOPACK compile-time value", "http://localhost:3000") || "https://newbi.fr";
const defaultSEO = {
    siteName: "Newbi - Solution de gestion pour entrepreneurs",
    author: "Newbi",
    language: "fr-FR",
    locale: "fr_FR",
    defaultImage: "/images/op-newbi.png",
    favicon: "".concat(baseUrl, "/NewbiV2/public/newbi.svg"),
    themeColor: "#3B82F6",
    // Informations de contact et localisation
    contact: {
        email: "contact@newbi.fr",
        supportEmail: "contact@newbi.fr",
        country: "France",
        region: "Europe"
    },
    // Configuration des réseaux sociaux
    social: {
        instagram: "https://www.instagram.com/newbi_fr?igsh=dnVwZ3NndTU3bWw5"
    }
};
const seoData = {
    // Page d'accueil
    home: {
        title: "Newbi - Solution de gestion complète pour entrepreneurs et freelances",
        description: "Simplifiez votre gestion d'entreprise avec Newbi : facturation, devis, signatures de mail, kanban, transferts de fichiers, gestion de trésorerie. Essai gratuit de 30 jours sans engagement.",
        keywords: "gestion entreprise, facturation, devis, signature de mail, kanban, freelance, entrepreneur, comptabilité, CRM, logiciel gestion, auto-entrepreneur, TPE, PME",
        canonical: "".concat(baseUrl),
        alternates: {
            canonical: "".concat(baseUrl)
        },
        openGraph: {
            title: "Newbi - La solution tout-en-un pour entrepreneurs",
            description: "Gérez votre entreprise efficacement : facturation, devis, signatures, organisation. Plus de 200 entrepreneurs nous font confiance.",
            image: "/images/op-newbi.png",
            type: "website",
            locale: "fr_FR",
            siteName: "Newbi"
        },
        twitter: {
            card: "summary_large_image",
            title: "Newbi - La solution tout-en-un pour entrepreneurs",
            description: "Gérez votre entreprise efficacement : facturation, devis, signatures, organisation.",
            image: "/images/op-newbi.png"
        },
        jsonLd: {
            "@context": "https://schema.org",
            "@type": "Organization",
            name: "Newbi",
            url: baseUrl,
            logo: "/images/op-newbi.png",
            description: "Solution de gestion complète pour entrepreneurs et freelances",
            foundingDate: "2023",
            address: {
                "@type": "PostalAddress",
                addressCountry: "FR",
                addressRegion: "France"
            },
            contactPoint: {
                "@type": "ContactPoint",
                email: "contact@newbi.fr",
                contactType: "customer service",
                availableLanguage: [
                    "French",
                    "fr"
                ]
            },
            sameAs: [
                "https://www.instagram.com/newbi_fr?igsh=dnVwZ3NndTU3bWw5"
            ],
            offers: {
                "@type": "Offer",
                description: "Essai gratuit de 30 jours",
                price: "0",
                priceCurrency: "EUR"
            },
            applicationCategory: "BusinessApplication",
            operatingSystem: "Web Browser"
        }
    },
    // Page Factures
    factures: {
        title: "Logiciel de Facturation Professionnel - Newbi",
        description: "Créez, envoyez et gérez vos factures professionnelles en quelques clics. Suivi des paiements, relances automatiques et conformité légale garantie.",
        keywords: "logiciel facturation, facture professionnelle, gestion factures, suivi paiements, relance automatique, TVA, comptabilité, facturation en ligne, auto-entrepreneur",
        canonical: "".concat(baseUrl, "/produits/factures"),
        openGraph: {
            title: "Facturation Professionnelle Simplifiée - Newbi",
            description: "Automatisez votre facturation et suivez vos paiements. Interface intuitive, conformité légale et gain de temps garanti.",
            image: "/images/op-newbi.png",
            type: "website",
            locale: "fr_FR"
        },
        twitter: {
            card: "summary_large_image",
            title: "Facturation Professionnelle Simplifiée - Newbi",
            description: "Automatisez votre facturation et suivez vos paiements.",
            image: "/images/op-newbi.png"
        },
        jsonLd: {
            "@context": "https://schema.org",
            "@type": "SoftwareApplication",
            name: "Newbi Facturation",
            applicationCategory: "BusinessApplication",
            operatingSystem: "Web",
            description: "Logiciel de facturation professionnel pour entrepreneurs et freelances",
            url: "".concat(baseUrl, "/produits/factures"),
            publisher: {
                "@type": "Organization",
                name: "Newbi"
            },
            offers: {
                "@type": "Offer",
                price: "0",
                priceCurrency: "EUR",
                description: "Essai gratuit de 30 jours"
            },
            featureList: [
                "Création de factures professionnelles",
                "Suivi des paiements",
                "Relances automatiques",
                "Conformité légale française",
                "Export comptable",
                "Gestion de la TVA",
                "Templates personnalisables"
            ],
            aggregateRating: {
                "@type": "AggregateRating",
                ratingValue: "4.8",
                reviewCount: "150"
            }
        }
    },
    // Page Devis
    devis: {
        title: "Créateur de Devis Professionnel en Ligne - Newbi",
        description: "Créez des devis professionnels personnalisés en quelques minutes. Conversion automatique en facture, suivi client et taux de conversion optimisé.",
        keywords: "créateur devis, devis professionnel, estimation, proposition commerciale, conversion facture, suivi client, devis en ligne, auto-entrepreneur",
        canonical: "".concat(baseUrl, "/produits/devis"),
        openGraph: {
            title: "Devis Professionnels en Ligne - Newbi",
            description: "Impressionnez vos clients avec des devis professionnels. Conversion facile en facture et suivi des acceptations.",
            image: "/images/op-newbi.png",
            type: "website",
            locale: "fr_FR"
        },
        twitter: {
            card: "summary_large_image",
            title: "Devis Professionnels en Ligne - Newbi",
            description: "Impressionnez vos clients avec des devis professionnels.",
            image: "/images/op-newbi.png"
        },
        jsonLd: {
            "@context": "https://schema.org",
            "@type": "SoftwareApplication",
            name: "Newbi Devis",
            applicationCategory: "BusinessApplication",
            operatingSystem: "Web",
            description: "Créateur de devis professionnel pour entrepreneurs",
            url: "".concat(baseUrl, "/produits/devis"),
            publisher: {
                "@type": "Organization",
                name: "Newbi"
            },
            offers: {
                "@type": "Offer",
                price: "0",
                priceCurrency: "EUR",
                description: "Essai gratuit de 30 jours"
            },
            featureList: [
                "Création de devis personnalisés",
                "Templates professionnels",
                "Conversion automatique en facture",
                "Suivi des acceptations",
                "Signature électronique intégrée",
                "Recherche d'entreprises françaises",
                "Calcul automatique de TVA"
            ],
            aggregateRating: {
                "@type": "AggregateRating",
                ratingValue: "4.7",
                reviewCount: "120"
            }
        }
    },
    // Page Signatures
    signatures: {
        title: "Générateur de Signature Mail Gratuit | Newbi",
        description: "Créez des signatures mail professionnelles gratuitement. Compatible Gmail, Outlook et Apple Mail. Templates personnalisables, export HTML et prévisualisation en temps réel.",
        keywords: "générateur signature mail gratuit, créer signature email professionnelle, signature gmail, signature outlook, template signature mail, signature email HTML, outil signature mail gratuit en ligne",
        canonical: "".concat(baseUrl, "/produits/signatures"),
        openGraph: {
            title: "Créez des Signatures Mail Professionnelles Gratuitement | Newbi",
            description: "Renforcez votre image de marque avec des signatures mail élégantes. Templates prêts à l'emploi, compatible tous clients email. 100% gratuit.",
            image: "/images/op-newbi.png",
            type: "website",
            locale: "fr_FR"
        },
        twitter: {
            card: "summary_large_image",
            title: "Signatures Mail Professionnelles Gratuites | Newbi",
            description: "Générateur de signatures mail gratuit. Templates pro, compatible Gmail, Outlook et Apple Mail.",
            image: "/images/op-newbi.png"
        },
        jsonLd: {
            "@context": "https://schema.org",
            "@type": "SoftwareApplication",
            name: "Newbi - Générateur de Signatures Mail",
            applicationCategory: "BusinessApplication",
            operatingSystem: "Web",
            description: "Générateur gratuit de signatures mail professionnelles compatible Gmail, Outlook et Apple Mail",
            url: "".concat(baseUrl, "/produits/signatures"),
            publisher: {
                "@type": "Organization",
                name: "Newbi"
            },
            offers: {
                "@type": "Offer",
                price: "0",
                priceCurrency: "EUR",
                description: "Outil entièrement gratuit"
            },
            featureList: [
                "Création de signatures email",
                "Templates personnalisables",
                "Conformité légale",
                "Intégration facile",
                "Design responsive",
                "Export HTML/CSS",
                "Prévisualisation en temps réel"
            ],
            aggregateRating: {
                "@type": "AggregateRating",
                ratingValue: "4.9",
                reviewCount: "200"
            }
        }
    },
    // Page Kanban
    kanban: {
        title: "Tableau Kanban - Gestion de Projets Agile - Newbi",
        description: "Organisez vos projets avec des tableaux Kanban intuitifs. Collaboration en équipe, suivi des tâches et productivité optimisée. Outil gratuit.",
        keywords: "kanban, gestion projet, organisation, productivité, collaboration équipe, suivi tâches, méthode agile, tableau kanban, outil gratuit",
        canonical: "".concat(baseUrl, "/dashboard/outils/kanban"),
        openGraph: {
            title: "Gestion de Projets Kanban - Newbi",
            description: "Boostez votre productivité avec nos tableaux Kanban. Organisation visuelle et collaboration simplifiée.",
            image: "/images/op-newbi.png",
            type: "website",
            locale: "fr_FR"
        },
        twitter: {
            card: "summary_large_image",
            title: "Gestion de Projets Kanban - Newbi",
            description: "Boostez votre productivité avec nos tableaux Kanban.",
            image: "/images/op-newbi.png"
        },
        jsonLd: {
            "@context": "https://schema.org",
            "@type": "SoftwareApplication",
            name: "Newbi Kanban",
            applicationCategory: "BusinessApplication",
            operatingSystem: "Web",
            description: "Outil de gestion de projets avec tableaux Kanban",
            url: "".concat(baseUrl, "/dashboard/outils/kanban"),
            publisher: {
                "@type": "Organization",
                name: "Newbi"
            },
            offers: {
                "@type": "Offer",
                price: "0",
                priceCurrency: "EUR",
                description: "Outil entièrement gratuit"
            },
            featureList: [
                "Tableaux Kanban personnalisables",
                "Collaboration en temps réel",
                "Suivi des tâches",
                "Notifications automatiques",
                "Rapports de productivité",
                "Interface drag & drop",
                "Organisation par colonnes"
            ],
            aggregateRating: {
                "@type": "AggregateRating",
                ratingValue: "4.6",
                reviewCount: "95"
            }
        }
    },
    // Page Transferts
    transfers: {
        title: "Transfert de Fichiers Sécurisé - Partage Professionnel - Newbi",
        description: "Partagez vos fichiers volumineux en toute sécurité. Transferts cryptés, liens temporaires et suivi des téléchargements pour professionnels.",
        keywords: "transfert fichiers, partage sécurisé, envoi gros fichiers, partage professionnel, cryptage, sécurité données, wetransfer alternatif",
        canonical: "".concat(baseUrl, "/dashboard/outils/transferts"),
        openGraph: {
            title: "Transfert de Fichiers Sécurisé - Newbi",
            description: "Partagez vos fichiers professionnels en toute sécurité. Cryptage avancé et contrôle total sur vos partages.",
            image: "/images/op-newbi.png",
            type: "website",
            locale: "fr_FR"
        },
        twitter: {
            card: "summary_large_image",
            title: "Transfert de Fichiers Sécurisé - Newbi",
            description: "Partagez vos fichiers professionnels en toute sécurité.",
            image: "/images/op-newbi.png"
        },
        jsonLd: {
            "@context": "https://schema.org",
            "@type": "SoftwareApplication",
            name: "Newbi Transferts",
            applicationCategory: "BusinessApplication",
            operatingSystem: "Web",
            description: "Solution de transfert de fichiers sécurisé pour professionnels",
            url: "".concat(baseUrl, "/dashboard/outils/transferts"),
            publisher: {
                "@type": "Organization",
                name: "Newbi"
            },
            offers: {
                "@type": "Offer",
                price: "0",
                priceCurrency: "EUR",
                description: "Essai gratuit de 30 jours"
            },
            featureList: [
                "Transferts cryptés",
                "Liens temporaires",
                "Suivi des téléchargements",
                "Contrôle d'accès",
                "Notifications en temps réel",
                "Stockage cloud sécurisé",
                "Interface drag & drop"
            ],
            aggregateRating: {
                "@type": "AggregateRating",
                ratingValue: "4.5",
                reviewCount: "80"
            }
        }
    },
    // Page Connexion
    login: {
        title: "Connexion - Accédez à votre espace Newbi",
        description: "Connectez-vous à votre compte Newbi pour accéder à tous vos outils de gestion d'entreprise : facturation, devis, signatures et plus.",
        keywords: "connexion newbi, login, espace client, compte utilisateur, authentification",
        robots: "noindex,nofollow",
        openGraph: {
            title: "Connexion à votre espace Newbi",
            description: "Accédez à votre tableau de bord et gérez votre entreprise efficacement."
        }
    },
    // Page Inscription
    signup: {
        title: "Inscription Gratuite - Créez votre compte Newbi",
        description: "Créez votre compte Newbi gratuitement et accédez à tous nos outils de gestion d'entreprise. Essai gratuit sans engagement, activation immédiate.",
        keywords: "inscription newbi, créer compte, essai gratuit, registration, nouveau compte",
        openGraph: {
            title: "Créez votre compte Newbi gratuitement",
            description: "Rejoignez plus de 1000 entrepreneurs qui font confiance à Newbi. Inscription gratuite et activation immédiate."
        },
        jsonLd: {
            "@context": "https://schema.org",
            "@type": "WebPage",
            name: "Inscription Newbi",
            description: "Page d'inscription pour créer un compte Newbi gratuit",
            offers: {
                "@type": "Offer",
                price: "0",
                priceCurrency: "EUR",
                description: "Compte gratuit avec accès aux fonctionnalités de base"
            }
        }
    },
    // Page Mentions Légales
    mentionsLegales: {
        title: "Mentions Légales - Newbi",
        description: "Mentions légales, informations sur l'éditeur, hébergement et conditions d'utilisation de la plateforme Newbi.",
        keywords: "mentions légales, éditeur, hébergement, conditions utilisation, RGPD, données personnelles",
        robots: "index,nofollow",
        openGraph: {
            title: "Mentions Légales - Newbi",
            description: "Informations légales et réglementaires concernant l'utilisation de Newbi."
        }
    },
    // Page Politique de Confidentialité
    politiqueConfidentialite: {
        title: "Politique de Confidentialité - Protection des Données - Newbi",
        description: "Notre politique de confidentialité détaille comment nous collectons, utilisons et protégeons vos données personnelles conformément au RGPD.",
        keywords: "politique confidentialité, protection données, RGPD, vie privée, cookies, données personnelles",
        robots: "index,nofollow",
        canonical: "".concat(baseUrl, "/politique-confidentialite"),
        openGraph: {
            title: "Politique de Confidentialité - Newbi",
            description: "Découvrez comment nous protégeons vos données personnelles et respectons votre vie privée.",
            type: "website",
            locale: "fr_FR"
        },
        jsonLd: {
            "@context": "https://schema.org",
            "@type": "WebPage",
            name: "Politique de Confidentialité",
            description: "Politique de confidentialité et protection des données personnelles de Newbi",
            url: "".concat(baseUrl, "/politique-confidentialite")
        }
    },
    // Page Tarifs
    pricing: {
        title: "Tarifs et Abonnements - Plans Newbi pour Entrepreneurs",
        description: "Découvrez nos tarifs transparents pour votre gestion d'entreprise. Essai gratuit de 30 jours, puis abonnement flexible. Fonctionnalités complètes incluses.",
        keywords: "tarifs newbi, prix abonnement, plan entrepreneur, facturation prix, devis tarif, essai gratuit, abonnement mensuel",
        canonical: "".concat(baseUrl, "/pricing"),
        openGraph: {
            title: "Tarifs Newbi - Plans pour Entrepreneurs",
            description: "Plans flexibles pour votre gestion d'entreprise. Essai gratuit de 30 jours inclus.",
            image: "/images/op-newbi.png",
            type: "website",
            locale: "fr_FR"
        },
        twitter: {
            card: "summary_large_image",
            title: "Tarifs Newbi - Plans pour Entrepreneurs",
            description: "Plans flexibles pour votre gestion d'entreprise.",
            image: "/images/op-newbi.png"
        },
        jsonLd: {
            "@context": "https://schema.org",
            "@type": "Product",
            name: "Newbi - Solution de gestion d'entreprise",
            description: "Solution complète de gestion pour entrepreneurs et freelances",
            url: "".concat(baseUrl, "/pricing"),
            brand: {
                "@type": "Brand",
                name: "Newbi"
            },
            offers: [
                {
                    "@type": "Offer",
                    name: "Essai Gratuit",
                    price: "0",
                    priceCurrency: "EUR",
                    description: "Essai gratuit de 30 jours - Toutes fonctionnalités incluses",
                    availability: "https://schema.org/InStock"
                },
                {
                    "@type": "Offer",
                    name: "Plan Professionnel",
                    price: "29",
                    priceCurrency: "EUR",
                    description: "Abonnement mensuel - Accès complet",
                    availability: "https://schema.org/InStock"
                }
            ]
        }
    },
    // Page FAQ
    faq: {
        title: "FAQ - Questions Fréquentes sur Newbi",
        description: "Trouvez rapidement les réponses à vos questions sur Newbi : facturation, devis, signatures, tarifs, fonctionnalités. Support et aide complète.",
        keywords: "faq newbi, questions fréquentes, aide newbi, support client, guide utilisation, facturation aide, devis questions, tarifs newbi",
        canonical: "".concat(baseUrl, "/faq"),
        robots: "index,follow",
        openGraph: {
            title: "FAQ - Toutes vos questions sur Newbi",
            description: "Découvrez les réponses aux questions les plus fréquentes sur Newbi. Support complet et aide détaillée.",
            image: "/images/op-newbi.png",
            type: "website",
            locale: "fr_FR"
        },
        twitter: {
            card: "summary_large_image",
            title: "FAQ - Toutes vos questions sur Newbi",
            description: "Découvrez les réponses aux questions les plus fréquentes sur Newbi.",
            image: "/images/op-newbi.png"
        },
        jsonLd: {
            "@context": "https://schema.org",
            "@type": "FAQPage",
            name: "FAQ Newbi",
            description: "Questions fréquentes et réponses sur l'utilisation de Newbi",
            url: "".concat(baseUrl, "/faq"),
            mainEntity: [
                {
                    "@type": "Question",
                    name: "Qu'est-ce que Newbi ?",
                    acceptedAnswer: {
                        "@type": "Answer",
                        text: "Newbi est une plateforme tout-en-un pour gérer simplement et efficacement votre activité: devis, factures, signature de mail, gestion de tâches en Kanban et transfert de fichiers sécurisé."
                    }
                },
                {
                    "@type": "Question",
                    name: "À qui s'adresse Newbi ?",
                    acceptedAnswer: {
                        "@type": "Answer",
                        text: "Newbi est une plateforme pensée pour les indépendants, TPE/PME, agences et associations qui veulent centraliser leurs outils commerciaux et administratifs, sans complexité."
                    }
                },
                {
                    "@type": "Question",
                    name: "Y a-t-il un essai gratuit ?",
                    acceptedAnswer: {
                        "@type": "Answer",
                        text: "Oui, vous bénéficiez de 30 jours gratuits à l'inscription, durant lesquels vous pouvez résilier votre abonnement à tout moment."
                    }
                }
            ]
        }
    },
    // Page CGV
    cgv: {
        title: "Conditions Générales de Vente - CGV Newbi",
        description: "Consultez les conditions générales de vente de Newbi : modalités d'abonnement, facturation, résiliation, garanties et conditions d'utilisation.",
        keywords: "cgv newbi, conditions générales vente, modalités abonnement, facturation, résiliation, garanties, conditions utilisation",
        canonical: "".concat(baseUrl, "/cgv"),
        robots: "index,nofollow",
        openGraph: {
            title: "Conditions Générales de Vente - Newbi",
            description: "Découvrez les conditions générales de vente et d'utilisation de la plateforme Newbi.",
            image: "/images/op-newbi.png",
            type: "website",
            locale: "fr_FR"
        },
        twitter: {
            card: "summary_large_image",
            title: "Conditions Générales de Vente - Newbi",
            description: "Conditions générales de vente et d'utilisation de Newbi.",
            image: "/images/op-newbi.png"
        },
        jsonLd: {
            "@context": "https://schema.org",
            "@type": "WebPage",
            name: "Conditions Générales de Vente",
            description: "Conditions générales de vente et d'utilisation de la plateforme Newbi",
            url: "".concat(baseUrl, "/cgv"),
            isPartOf: {
                "@type": "WebSite",
                name: "Newbi",
                url: baseUrl
            },
            inLanguage: "fr-FR",
            dateModified: "2024-01-01",
            publisher: {
                "@type": "Organization",
                name: "Newbi",
                url: baseUrl
            }
        }
    }
};
function getSEOData(pageKey) {
    const pageSEO = seoData[pageKey] || {};
    return {
        ...defaultSEO,
        ...pageSEO,
        openGraph: {
            siteName: defaultSEO.siteName,
            locale: defaultSEO.locale,
            type: "website",
            ...pageSEO.openGraph
        },
        twitter: {
            card: "summary_large_image",
            site: "@newbi_fr",
            creator: "@newbi_fr",
            ...pageSEO.twitter
        }
    };
}
function generateBasicJsonLd(title, description, url) {
    return {
        "@context": "https://schema.org",
        "@type": "WebPage",
        name: title,
        description: description,
        url: url,
        isPartOf: {
            "@type": "WebSite",
            name: defaultSEO.siteName,
            url: baseUrl
        },
        inLanguage: "fr-FR",
        potentialAction: {
            "@type": "ReadAction",
            target: url
        }
    };
}
function generateBreadcrumbsJsonLd(breadcrumbs) {
    return {
        "@context": "https://schema.org",
        "@type": "BreadcrumbList",
        itemListElement: breadcrumbs.map((item, index)=>({
                "@type": "ListItem",
                position: index + 1,
                name: item.name,
                item: item.url
            }))
    };
}
function generateSitemap() {
    const pages = Object.keys(seoData).filter((key)=>{
        var _seoData_key_robots;
        return !((_seoData_key_robots = seoData[key].robots) === null || _seoData_key_robots === void 0 ? void 0 : _seoData_key_robots.includes("noindex"));
    });
    const urls = pages.map((pageKey)=>{
        const page = seoData[pageKey];
        const url = page.canonical || "".concat(baseUrl, "/").concat(pageKey);
        const priority = pageKey === "home" ? "1.0" : "0.8";
        const changefreq = pageKey === "home" ? "weekly" : "monthly";
        return "\n    <url>\n      <loc>".concat(url, "</loc>\n      <changefreq>").concat(changefreq, "</changefreq>\n      <priority>").concat(priority, "</priority>\n      <lastmod>").concat(new Date().toISOString().split("T")[0], "</lastmod>\n    </url>");
    }).join("");
    return '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n  '.concat(urls, "\n</urlset>");
}
function generateMetaTags(pageKey) {
    let currentUrl = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "";
    var _seo_openGraph, _seo_openGraph1, _seo_openGraph2, _seo_openGraph3, _seo_openGraph4, _seo_openGraph5, _seo_openGraph6, _seo_twitter, _seo_twitter1, _seo_twitter2, _seo_twitter3, _seo_twitter4, _seo_twitter5, _seo_openGraph7;
    const seo = getSEOData(pageKey);
    return {
        title: seo.title,
        description: seo.description,
        keywords: seo.keywords,
        canonical: seo.canonical || currentUrl,
        robots: seo.robots || "index,follow",
        // Open Graph
        openGraph: {
            title: ((_seo_openGraph = seo.openGraph) === null || _seo_openGraph === void 0 ? void 0 : _seo_openGraph.title) || seo.title,
            description: ((_seo_openGraph1 = seo.openGraph) === null || _seo_openGraph1 === void 0 ? void 0 : _seo_openGraph1.description) || seo.description,
            url: currentUrl,
            siteName: ((_seo_openGraph2 = seo.openGraph) === null || _seo_openGraph2 === void 0 ? void 0 : _seo_openGraph2.siteName) || defaultSEO.siteName,
            images: [
                {
                    url: ((_seo_openGraph3 = seo.openGraph) === null || _seo_openGraph3 === void 0 ? void 0 : _seo_openGraph3.image) || defaultSEO.defaultImage,
                    width: 1200,
                    height: 630,
                    alt: ((_seo_openGraph4 = seo.openGraph) === null || _seo_openGraph4 === void 0 ? void 0 : _seo_openGraph4.title) || seo.title
                }
            ],
            locale: ((_seo_openGraph5 = seo.openGraph) === null || _seo_openGraph5 === void 0 ? void 0 : _seo_openGraph5.locale) || defaultSEO.locale,
            type: ((_seo_openGraph6 = seo.openGraph) === null || _seo_openGraph6 === void 0 ? void 0 : _seo_openGraph6.type) || "website"
        },
        // Twitter
        twitter: {
            card: ((_seo_twitter = seo.twitter) === null || _seo_twitter === void 0 ? void 0 : _seo_twitter.card) || "summary_large_image",
            site: ((_seo_twitter1 = seo.twitter) === null || _seo_twitter1 === void 0 ? void 0 : _seo_twitter1.site) || "@newbi_fr",
            creator: ((_seo_twitter2 = seo.twitter) === null || _seo_twitter2 === void 0 ? void 0 : _seo_twitter2.creator) || "@newbi_fr",
            title: ((_seo_twitter3 = seo.twitter) === null || _seo_twitter3 === void 0 ? void 0 : _seo_twitter3.title) || seo.title,
            description: ((_seo_twitter4 = seo.twitter) === null || _seo_twitter4 === void 0 ? void 0 : _seo_twitter4.description) || seo.description,
            images: [
                ((_seo_twitter5 = seo.twitter) === null || _seo_twitter5 === void 0 ? void 0 : _seo_twitter5.image) || ((_seo_openGraph7 = seo.openGraph) === null || _seo_openGraph7 === void 0 ? void 0 : _seo_openGraph7.image) || defaultSEO.defaultImage
            ]
        },
        // Autres meta tags
        other: {
            "theme-color": defaultSEO.themeColor,
            "application-name": "Newbi",
            "apple-mobile-web-app-title": "Newbi",
            "apple-mobile-web-app-capable": "yes",
            "apple-mobile-web-app-status-bar-style": "default",
            "format-detection": "telephone=no",
            "mobile-web-app-capable": "yes",
            "msapplication-config": "".concat(baseUrl, "/browserconfig.xml"),
            "msapplication-TileColor": defaultSEO.themeColor
        }
    };
}
function generateFAQJsonLd(faqs) {
    return {
        "@context": "https://schema.org",
        "@type": "FAQPage",
        mainEntity: faqs.map((faq)=>({
                "@type": "Question",
                name: faq.question,
                acceptedAnswer: {
                    "@type": "Answer",
                    text: faq.answer
                }
            }))
    };
}
function generateReviewsJsonLd(reviews) {
    return {
        "@context": "https://schema.org",
        "@type": "Product",
        name: "Newbi - Solution de gestion d'entreprise",
        aggregateRating: {
            "@type": "AggregateRating",
            ratingValue: reviews.reduce((sum, review)=>sum + review.rating, 0) / reviews.length,
            reviewCount: reviews.length,
            bestRating: 5,
            worstRating: 1
        },
        review: reviews.map((review)=>({
                "@type": "Review",
                author: {
                    "@type": "Person",
                    name: review.author
                },
                reviewRating: {
                    "@type": "Rating",
                    ratingValue: review.rating,
                    bestRating: 5,
                    worstRating: 1
                },
                reviewBody: review.text,
                datePublished: review.date
            }))
    };
}
function validateSEOData(pageKey) {
    var _seo_openGraph, _seo_openGraph1, _seo_openGraph2;
    const seo = seoData[pageKey];
    const errors = [];
    const warnings = [];
    if (!seo) {
        errors.push('Page "'.concat(pageKey, '" non trouvée dans seoData'));
        return {
            valid: false,
            errors,
            warnings
        };
    }
    // Validation du titre
    if (!seo.title) {
        errors.push("Titre manquant");
    } else if (seo.title.length > 60) {
        warnings.push("Titre trop long (".concat(seo.title.length, " caractères, recommandé: <60)"));
    } else if (seo.title.length < 30) {
        warnings.push("Titre court (".concat(seo.title.length, " caractères, recommandé: 30-60)"));
    }
    // Validation de la description
    if (!seo.description) {
        errors.push("Description manquante");
    } else if (seo.description.length > 160) {
        warnings.push("Description trop longue (".concat(seo.description.length, " caractères, recommandé: <160)"));
    } else if (seo.description.length < 120) {
        warnings.push("Description courte (".concat(seo.description.length, " caractères, recommandé: 120-160)"));
    }
    // Validation des mots-clés
    if (!seo.keywords) {
        warnings.push("Mots-clés manquants");
    } else {
        const keywordCount = seo.keywords.split(",").length;
        if (keywordCount > 10) {
            warnings.push("Trop de mots-clés (".concat(keywordCount, ", recommandé: <10)"));
        }
    }
    // Validation Open Graph
    if (!((_seo_openGraph = seo.openGraph) === null || _seo_openGraph === void 0 ? void 0 : _seo_openGraph.title)) {
        warnings.push("Titre Open Graph manquant");
    }
    if (!((_seo_openGraph1 = seo.openGraph) === null || _seo_openGraph1 === void 0 ? void 0 : _seo_openGraph1.description)) {
        warnings.push("Description Open Graph manquante");
    }
    if (!((_seo_openGraph2 = seo.openGraph) === null || _seo_openGraph2 === void 0 ? void 0 : _seo_openGraph2.image)) {
        warnings.push("Image Open Graph manquante");
    }
    return {
        valid: errors.length === 0,
        errors,
        warnings,
        score: Math.max(0, 100 - errors.length * 20 - warnings.length * 5)
    };
}
function generateNextMetadata(pageKey) {
    var _seoConfig_openGraph, _seoConfig_openGraph1, _seoConfig_openGraph2, _seoConfig_openGraph3, _seoConfig_openGraph4, _seoConfig_openGraph5, _seoConfig_openGraph6, _seoConfig_twitter, _seoConfig_twitter1, _seoConfig_twitter2, _seoConfig_twitter3;
    const seoConfig = getSEOData(pageKey);
    return {
        title: seoConfig.title,
        description: seoConfig.description,
        keywords: seoConfig.keywords,
        authors: [
            {
                name: seoConfig.author || defaultSEO.author
            }
        ],
        creator: seoConfig.author || defaultSEO.author,
        publisher: defaultSEO.siteName,
        alternates: {
            canonical: seoConfig.canonical
        },
        openGraph: {
            title: ((_seoConfig_openGraph = seoConfig.openGraph) === null || _seoConfig_openGraph === void 0 ? void 0 : _seoConfig_openGraph.title) || seoConfig.title,
            description: ((_seoConfig_openGraph1 = seoConfig.openGraph) === null || _seoConfig_openGraph1 === void 0 ? void 0 : _seoConfig_openGraph1.description) || seoConfig.description,
            url: seoConfig.canonical,
            siteName: ((_seoConfig_openGraph2 = seoConfig.openGraph) === null || _seoConfig_openGraph2 === void 0 ? void 0 : _seoConfig_openGraph2.siteName) || defaultSEO.siteName,
            images: ((_seoConfig_openGraph3 = seoConfig.openGraph) === null || _seoConfig_openGraph3 === void 0 ? void 0 : _seoConfig_openGraph3.image) ? [
                {
                    url: seoConfig.openGraph.image,
                    width: 1200,
                    height: 630,
                    alt: ((_seoConfig_openGraph4 = seoConfig.openGraph) === null || _seoConfig_openGraph4 === void 0 ? void 0 : _seoConfig_openGraph4.title) || seoConfig.title
                }
            ] : [],
            locale: ((_seoConfig_openGraph5 = seoConfig.openGraph) === null || _seoConfig_openGraph5 === void 0 ? void 0 : _seoConfig_openGraph5.locale) || defaultSEO.locale,
            type: ((_seoConfig_openGraph6 = seoConfig.openGraph) === null || _seoConfig_openGraph6 === void 0 ? void 0 : _seoConfig_openGraph6.type) || "website"
        },
        twitter: {
            card: ((_seoConfig_twitter = seoConfig.twitter) === null || _seoConfig_twitter === void 0 ? void 0 : _seoConfig_twitter.card) || "summary_large_image",
            title: ((_seoConfig_twitter1 = seoConfig.twitter) === null || _seoConfig_twitter1 === void 0 ? void 0 : _seoConfig_twitter1.title) || seoConfig.title,
            description: ((_seoConfig_twitter2 = seoConfig.twitter) === null || _seoConfig_twitter2 === void 0 ? void 0 : _seoConfig_twitter2.description) || seoConfig.description,
            images: ((_seoConfig_twitter3 = seoConfig.twitter) === null || _seoConfig_twitter3 === void 0 ? void 0 : _seoConfig_twitter3.image) ? [
                seoConfig.twitter.image
            ] : []
        },
        robots: {
            index: true,
            follow: true,
            googleBot: {
                index: true,
                follow: true,
                "max-video-preview": -1,
                "max-image-preview": "large",
                "max-snippet": -1
            }
        }
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/use-seo.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useAuthSEO",
    ()=>useAuthSEO,
    "useLegalSEO",
    ()=>useLegalSEO,
    "useProductSEO",
    ()=>useProductSEO,
    "useSEO",
    ()=>useSEO
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$seo$2d$data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/seo-data.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature(), _s3 = __turbopack_context__.k.signature();
"use client";
;
;
function useSEO(pageKey) {
    let customSEO = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, breadcrumbs = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : [];
    _s();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const baseUrl = ("TURBOPACK compile-time value", "http://localhost:3000") || "https://newbi.fr";
    const currentUrl = "".concat(baseUrl).concat(pathname);
    // Récupération des données SEO de base
    const baseSEO = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$seo$2d$data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSEOData"])(pageKey);
    // Fusion avec les données personnalisées
    const seoData = {
        ...baseSEO,
        ...customSEO,
        canonical: customSEO.canonical || currentUrl,
        openGraph: {
            ...baseSEO.openGraph,
            ...customSEO.openGraph,
            url: customSEO.canonical || currentUrl
        },
        twitter: {
            ...baseSEO.twitter,
            ...customSEO.twitter
        }
    };
    // Génération du JSON-LD de base si pas fourni
    if (!seoData.jsonLd && pageKey) {
        seoData.jsonLd = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$seo$2d$data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateBasicJsonLd"])(seoData.title, seoData.description, currentUrl);
    }
    // Ajout des breadcrumbs JSON-LD si fournis
    if (breadcrumbs.length > 0) {
        const breadcrumbsJsonLd = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$seo$2d$data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateBreadcrumbsJsonLd"])(breadcrumbs);
        // Si on a déjà du JSON-LD, on crée un tableau
        if (seoData.jsonLd) {
            seoData.jsonLd = [
                seoData.jsonLd,
                breadcrumbsJsonLd
            ];
        } else {
            seoData.jsonLd = breadcrumbsJsonLd;
        }
    }
    return seoData;
}
_s(useSEO, "xbyQPtUVMO7MNj7WjJlpdWqRcTo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"]
    ];
});
function useProductSEO(productName) {
    let customSEO = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
    _s1();
    const breadcrumbs = [
        {
            name: "Accueil",
            url: ("TURBOPACK compile-time value", "http://localhost:3000") || "https://newbi.fr"
        },
        {
            name: "Produits",
            url: "".concat(("TURBOPACK compile-time value", "http://localhost:3000") || "https://newbi.fr", "/produits")
        },
        {
            name: productName,
            url: "".concat(("TURBOPACK compile-time value", "http://localhost:3000") || "https://newbi.fr", "/produits/").concat(productName.toLowerCase())
        }
    ];
    return useSEO(productName.toLowerCase(), customSEO, breadcrumbs);
}
_s1(useProductSEO, "6rSydtRzpsPOyyHBRlWg+zmNlls=", false, function() {
    return [
        useSEO
    ];
});
function useAuthSEO(authType) {
    let customSEO = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
    _s2();
    const breadcrumbs = [
        {
            name: "Accueil",
            url: ("TURBOPACK compile-time value", "http://localhost:3000") || "https://newbi.fr"
        },
        {
            name: authType === "login" ? "Connexion" : "Inscription",
            url: "".concat(("TURBOPACK compile-time value", "http://localhost:3000") || "https://newbi.fr", "/auth/").concat(authType)
        }
    ];
    return useSEO(authType, customSEO, breadcrumbs);
}
_s2(useAuthSEO, "6rSydtRzpsPOyyHBRlWg+zmNlls=", false, function() {
    return [
        useSEO
    ];
});
function useLegalSEO(legalType) {
    let customSEO = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
    _s3();
    const pageNames = {
        "mentions-legales": "Mentions Légales",
        "politique-de-confidentialite": "Politique de Confidentialité"
    };
    const breadcrumbs = [
        {
            name: "Accueil",
            url: ("TURBOPACK compile-time value", "http://localhost:3000") || "https://newbi.fr"
        },
        {
            name: pageNames[legalType],
            url: "".concat(("TURBOPACK compile-time value", "http://localhost:3000") || "https://newbi.fr", "/").concat(legalType)
        }
    ];
    const pageKey = legalType === "mentions-legales" ? "mentionsLegales" : "politiqueConfidentialite";
    return useSEO(pageKey, customSEO, breadcrumbs);
}
_s3(useLegalSEO, "6rSydtRzpsPOyyHBRlWg+zmNlls=", false, function() {
    return [
        useSEO
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/auth/login/page.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>LoginPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/button.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$separator$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/separator.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$auth$2f$login$2f$loginForm$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/auth/login/loginForm.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/auth/api.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$router$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/router.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/auth-client.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$sonner$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/sonner.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$typewriter$2d$text$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/typewriter-text.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$arrow$2d$up$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CircleArrowUp$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/circle-arrow-up.js [app-client] (ecmascript) <export default as CircleArrowUp>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$seo$2f$seo$2d$head$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/seo/seo-head.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$seo$2f$seo$2d$metadata$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/seo/seo-metadata.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$seo$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/use-seo.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const GoogleIcon = (props)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        viewBox: "0 0 24 24",
        ...props,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z",
                fill: "#4285F4"
            }, void 0, false, {
                fileName: "[project]/app/auth/login/page.jsx",
                lineNumber: 22,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z",
                fill: "#34A853"
            }, void 0, false, {
                fileName: "[project]/app/auth/login/page.jsx",
                lineNumber: 23,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z",
                fill: "#FBBC05"
            }, void 0, false, {
                fileName: "[project]/app/auth/login/page.jsx",
                lineNumber: 24,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z",
                fill: "#EA4335"
            }, void 0, false, {
                fileName: "[project]/app/auth/login/page.jsx",
                lineNumber: 25,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/app/auth/login/page.jsx",
        lineNumber: 21,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
_c = GoogleIcon;
const Logo = (param)=>{
    let { className } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        viewBox: "0 0 78 18",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        className: cn("h-5 w-auto", className),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M3 0H5V18H3V0ZM13 0H15V18H13V0ZM18 3V5H0V3H18ZM0 15V13H18V15H0Z",
                fill: "url(#logo-gradient)"
            }, void 0, false, {
                fileName: "[project]/app/auth/login/page.jsx",
                lineNumber: 37,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M27.06 7.054V12.239C27.06 12.5903 27.1393 12.8453 27.298 13.004C27.468 13.1513 27.7513 13.225 28.148 13.225H29.338V14.84H27.808C26.9353 14.84 26.2667 14.636 25.802 14.228C25.3373 13.82 25.105 13.157 25.105 12.239V7.054H24V5.473H25.105V3.144H27.06V5.473H29.338V7.054H27.06ZM30.4782 10.114C30.4782 9.17333 30.6709 8.34033 31.0562 7.615C31.4529 6.88967 31.9855 6.32867 32.6542 5.932C33.3342 5.524 34.0822 5.32 34.8982 5.32C35.6349 5.32 36.2752 5.46733 36.8192 5.762C37.3745 6.04533 37.8165 6.40233 38.1452 6.833V5.473H40.1002V14.84H38.1452V13.446C37.8165 13.888 37.3689 14.2563 36.8022 14.551C36.2355 14.8457 35.5895 14.993 34.8642 14.993C34.0595 14.993 33.3229 14.789 32.6542 14.381C31.9855 13.9617 31.4529 13.3837 31.0562 12.647C30.6709 11.899 30.4782 11.0547 30.4782 10.114ZM38.1452 10.148C38.1452 9.502 38.0092 8.941 37.7372 8.465C37.4765 7.989 37.1309 7.62633 36.7002 7.377C36.2695 7.12767 35.8049 7.003 35.3062 7.003C34.8075 7.003 34.3429 7.12767 33.9122 7.377C33.4815 7.615 33.1302 7.972 32.8582 8.448C32.5975 8.91267 32.4672 9.468 32.4672 10.114C32.4672 10.76 32.5975 11.3267 32.8582 11.814C33.1302 12.3013 33.4815 12.6753 33.9122 12.936C34.3542 13.1853 34.8189 13.31 35.3062 13.31C35.8049 13.31 36.2695 13.1853 36.7002 12.936C37.1309 12.6867 37.4765 12.324 37.7372 11.848C38.0092 11.3607 38.1452 10.794 38.1452 10.148ZM43.6317 4.232C43.2803 4.232 42.9857 4.113 42.7477 3.875C42.5097 3.637 42.3907 3.34233 42.3907 2.991C42.3907 2.63967 42.5097 2.345 42.7477 2.107C42.9857 1.869 43.2803 1.75 43.6317 1.75C43.9717 1.75 44.2607 1.869 44.4987 2.107C44.7367 2.345 44.8557 2.63967 44.8557 2.991C44.8557 3.34233 44.7367 3.637 44.4987 3.875C44.2607 4.113 43.9717 4.232 43.6317 4.232ZM44.5837 5.473V14.84H42.6457V5.473H44.5837ZM49.0661 2.26V14.84H47.1281V2.26H49.0661ZM50.9645 10.114C50.9645 9.17333 51.1572 8.34033 51.5425 7.615C51.9392 6.88967 52.4719 6.32867 53.1405 5.932C53.8205 5.524 54.5685 5.32 55.3845 5.32C56.1212 5.32 56.7615 5.46733 57.3055 5.762C57.8609 6.04533 58.3029 6.40233 58.6315 6.833V5.473H60.5865V14.84H58.6315V13.446C58.3029 13.888 57.8552 14.2563 57.2885 14.551C56.7219 14.8457 56.0759 14.993 55.3505 14.993C54.5459 14.993 53.8092 14.789 53.1405 14.381C52.4719 13.9617 51.9392 13.3837 51.5425 12.647C51.1572 11.899 50.9645 11.0547 50.9645 10.114ZM58.6315 10.148C58.6315 9.502 58.4955 8.941 58.2235 8.465C57.9629 7.989 57.6172 7.62633 57.1865 7.377C56.7559 7.12767 56.2912 7.003 55.7925 7.003C55.2939 7.003 54.8292 7.12767 54.3985 7.377C53.9679 7.615 53.6165 7.972 53.3445 8.448C53.0839 8.91267 52.9535 9.468 52.9535 10.114C52.9535 10.76 53.0839 11.3267 53.3445 11.814C53.6165 12.3013 53.9679 12.6753 54.3985 12.936C54.8405 13.1853 55.3052 13.31 55.7925 13.31C56.2912 13.31 56.7559 13.1853 57.1865 12.936C57.6172 12.6867 57.9629 12.324 58.2235 11.848C58.4955 11.3607 58.6315 10.794 58.6315 10.148ZM65.07 6.833C65.3533 6.357 65.7273 5.98867 66.192 5.728C66.668 5.456 67.229 5.32 67.875 5.32V7.326H67.382C66.6227 7.326 66.0447 7.51867 65.648 7.904C65.2627 8.28933 65.07 8.958 65.07 9.91V14.84H63.132V5.473H65.07V6.833ZM73.3624 10.165L77.6804 14.84H75.0624L71.5944 10.811V14.84H69.6564V2.26H71.5944V9.57L74.9944 5.473H77.6804L73.3624 10.165Z",
                fill: "currentColor"
            }, void 0, false, {
                fileName: "[project]/app/auth/login/page.jsx",
                lineNumber: 41,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("linearGradient", {
                    id: "logo-gradient",
                    x1: "10",
                    y1: "0",
                    x2: "10",
                    y2: "20",
                    gradientUnits: "userSpaceOnUse",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                            stopColor: "#9B99FE"
                        }, void 0, false, {
                            fileName: "[project]/app/auth/login/page.jsx",
                            lineNumber: 54,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("stop", {
                            offset: "1",
                            stopColor: "#2BC8B7"
                        }, void 0, false, {
                            fileName: "[project]/app/auth/login/page.jsx",
                            lineNumber: 55,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/auth/login/page.jsx",
                    lineNumber: 46,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/app/auth/login/page.jsx",
                lineNumber: 45,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/app/auth/login/page.jsx",
        lineNumber: 31,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c1 = Logo;
const signInWithProvider = async (provider)=>{
    // Vider tous les caches avant la connexion OAuth
    try {
        console.log("🧹 Nettoyage des caches avant connexion OAuth...");
        // Vider le cache utilisateur
        localStorage.removeItem("user-cache");
        // Vider tous les caches d'abonnement (on ne connaît pas l'ID à l'avance)
        Object.keys(localStorage).forEach((key)=>{
            if (key.startsWith("subscription-")) {
                localStorage.removeItem(key);
                console.log("🗑️ Cache supprimé: ".concat(key));
            }
        });
        console.log("✅ Caches nettoyés avec succès");
    } catch (error) {
        console.warn("⚠️ Erreur lors du nettoyage des caches:", error);
    }
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["signIn"].social({
        provider,
        callbackURL: "/dashboard"
    }, {
        onSuccess: ()=>{},
        onError: (error)=>{
            console.error("Erreur de connexion ".concat(provider, ":"), error);
            // Vérifier si c'est une erreur de compte désactivé
            if (error.message && error.message.includes("désactivé")) {
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$sonner$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error(error.message);
            } else if (error.message && error.message.includes("réactivation")) {
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$sonner$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error(error.message);
            } else {
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$sonner$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error("Erreur lors de la connexion avec ".concat(provider));
            }
            throw error;
        }
    });
};
function LoginPage() {
    _s();
    const seoData = {
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$seo$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuthSEO"])("login"),
        robots: "noindex,nofollow"
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$seo$2f$seo$2d$head$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                ...seoData
            }, void 0, false, {
                fileName: "[project]/app/auth/login/page.jsx",
                lineNumber: 112,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$seo$2f$seo$2d$metadata$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["JsonLd"], {
                jsonLd: seoData.jsonLd
            }, void 0, false, {
                fileName: "[project]/app/auth/login/page.jsx",
                lineNumber: 113,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "hidden md:flex h-screen",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-1/2 flex items-center justify-center p-8",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mx-auto sm:max-w-md w-full",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            className: "text-3xl font-medium text-foreground dark:text-foreground",
                                            children: "Connectez-vous"
                                        }, void 0, false, {
                                            fileName: "[project]/app/auth/login/page.jsx",
                                            lineNumber: 119,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "mt-2 text-sm text-muted-foreground dark:text-muted-foreground",
                                            children: [
                                                "Vous n'avez pas de compte ?",
                                                " ",
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    href: "/auth/signup",
                                                    className: "font-medium text-primary hover:text-primary/90 dark:text-primary hover:dark:text-primary/90",
                                                    children: "Inscription"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/auth/login/page.jsx",
                                                    lineNumber: 124,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/auth/login/page.jsx",
                                            lineNumber: 122,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "mt-8",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                                variant: "outline",
                                                size: "lg",
                                                className: "w-full items-center justify-center cursor-pointer",
                                                onClick: ()=>signInWithProvider("google"),
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(GoogleIcon, {
                                                        className: "size-4",
                                                        "aria-hidden": true
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/auth/login/page.jsx",
                                                        lineNumber: 138,
                                                        columnNumber: 19
                                                    }, this),
                                                    "Connexion avec Google"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/auth/login/page.jsx",
                                                lineNumber: 132,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/auth/login/page.jsx",
                                            lineNumber: 131,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "relative my-6",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "absolute inset-0 flex items-center",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$separator$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Separator"], {
                                                        className: "w-full"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/auth/login/page.jsx",
                                                        lineNumber: 145,
                                                        columnNumber: 19
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/app/auth/login/page.jsx",
                                                    lineNumber: 144,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "relative flex justify-center text-xs uppercase",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "bg-background px-2 text-muted-foreground",
                                                        children: "ou"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/auth/login/page.jsx",
                                                        lineNumber: 148,
                                                        columnNumber: 19
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/app/auth/login/page.jsx",
                                                    lineNumber: 147,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/auth/login/page.jsx",
                                            lineNumber: 143,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$auth$2f$login$2f$loginForm$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                            fileName: "[project]/app/auth/login/page.jsx",
                                            lineNumber: 154,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "mt-6 text-sm text-muted-foreground dark:text-muted-foreground",
                                            children: [
                                                "Mot de passe oublié?",
                                                " ",
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    href: "/auth/forget-password",
                                                    className: "font-medium text-primary hover:text-primary/90 dark:text-primary hover:dark:text-primary/90",
                                                    children: "Réinitialiser mot de passe"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/auth/login/page.jsx",
                                                    lineNumber: 157,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/auth/login/page.jsx",
                                            lineNumber: 155,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/auth/login/page.jsx",
                                    lineNumber: 118,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/auth/login/page.jsx",
                                lineNumber: 117,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-1/2 p-2 flex items-center min-h-screen justify-center",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex p-5 items-center justify-center w-full h-full rounded-lg bg-[#5A50FF]/30 relative",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "bg-white/80 shadow-md rounded-2xl p-6 w-110 mx-auto",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-lg min-h-[27px] flex items-center justify-between",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex-1",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$typewriter$2d$text$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Typewriter"], {
                                                            text: [
                                                                "Créez votre compte en quelques secondes.",
                                                                "Rejoignez notre communauté.",
                                                                "Commencez votre aventure dès maintenant."
                                                            ],
                                                            speed: 30,
                                                            deleteSpeed: 30,
                                                            delay: 2000,
                                                            loop: true,
                                                            className: "font-medium text-left text-[#1C1C1C] text-[15px]"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/auth/login/page.jsx",
                                                            lineNumber: 171,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/auth/login/page.jsx",
                                                        lineNumber: 170,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$arrow$2d$up$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CircleArrowUp$3e$__["CircleArrowUp"], {
                                                        className: "ml-4 text-[#1C1C1C] flex-shrink-0"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/auth/login/page.jsx",
                                                        lineNumber: 184,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/auth/login/page.jsx",
                                                lineNumber: 169,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/auth/login/page.jsx",
                                            lineNumber: 168,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                            src: "/ni.svg",
                                            alt: "Newbi Logo",
                                            className: "absolute bottom-2 right-3 w-5 h-auto filter brightness-0 invert",
                                            style: {
                                                opacity: 0.9
                                            }
                                        }, void 0, false, {
                                            fileName: "[project]/app/auth/login/page.jsx",
                                            lineNumber: 187,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/auth/login/page.jsx",
                                    lineNumber: 167,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/auth/login/page.jsx",
                                lineNumber: 166,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/auth/login/page.jsx",
                        lineNumber: 116,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "md:hidden min-h-screen bg-background flex flex-col",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "pt-10 flex justify-center",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                    src: "/newbiLetter.png",
                                    alt: "Newbi",
                                    className: "h-5 w-auto object-contain"
                                }, void 0, false, {
                                    fileName: "[project]/app/auth/login/page.jsx",
                                    lineNumber: 201,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/auth/login/page.jsx",
                                lineNumber: 200,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex-1 flex items-center justify-center px-6",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "w-full max-w-sm",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            className: "text-2xl font-medium text-foreground text-center mb-8",
                                            children: "Connexion"
                                        }, void 0, false, {
                                            fileName: "[project]/app/auth/login/page.jsx",
                                            lineNumber: 207,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                            variant: "outline",
                                            size: "lg",
                                            className: "w-full items-center justify-center cursor-pointer",
                                            onClick: ()=>signInWithProvider("google"),
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(GoogleIcon, {
                                                    className: "size-4",
                                                    "aria-hidden": true
                                                }, void 0, false, {
                                                    fileName: "[project]/app/auth/login/page.jsx",
                                                    lineNumber: 217,
                                                    columnNumber: 17
                                                }, this),
                                                "Connexion avec Google"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/auth/login/page.jsx",
                                            lineNumber: 211,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "relative my-6",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "absolute inset-0 flex items-center",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$separator$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Separator"], {
                                                        className: "w-full"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/auth/login/page.jsx",
                                                        lineNumber: 223,
                                                        columnNumber: 19
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/app/auth/login/page.jsx",
                                                    lineNumber: 222,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "relative flex justify-center text-xs uppercase",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "bg-background px-2 text-muted-foreground",
                                                        children: "ou"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/auth/login/page.jsx",
                                                        lineNumber: 226,
                                                        columnNumber: 19
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/app/auth/login/page.jsx",
                                                    lineNumber: 225,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/auth/login/page.jsx",
                                            lineNumber: 221,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$auth$2f$login$2f$loginForm$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                            fileName: "[project]/app/auth/login/page.jsx",
                                            lineNumber: 230,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "mt-4 text-sm text-muted-foreground text-center",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                href: "/auth/forget-password",
                                                className: "font-medium text-primary hover:text-primary/90",
                                                children: "Mot de passe oublié ?"
                                            }, void 0, false, {
                                                fileName: "[project]/app/auth/login/page.jsx",
                                                lineNumber: 233,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/auth/login/page.jsx",
                                            lineNumber: 232,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/auth/login/page.jsx",
                                    lineNumber: 206,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/auth/login/page.jsx",
                                lineNumber: 205,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "pb-6 px-6 text-center space-y-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-xs text-muted-foreground",
                                        children: [
                                            "Vous n'avez pas de compte ?",
                                            " ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                href: "/auth/signup",
                                                className: "font-medium text-primary hover:text-primary/90",
                                                children: "Inscription"
                                            }, void 0, false, {
                                                fileName: "[project]/app/auth/login/page.jsx",
                                                lineNumber: 247,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/auth/login/page.jsx",
                                        lineNumber: 245,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-[11px] text-muted-foreground/60",
                                        children: [
                                            "En continuant, vous acceptez nos",
                                            " ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                href: "/mentions-legales",
                                                className: "underline",
                                                children: "Conditions générales"
                                            }, void 0, false, {
                                                fileName: "[project]/app/auth/login/page.jsx",
                                                lineNumber: 256,
                                                columnNumber: 15
                                            }, this),
                                            " ",
                                            "et",
                                            " ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                href: "/politique-confidentialite",
                                                className: "underline",
                                                children: "Politique de confidentialité"
                                            }, void 0, false, {
                                                fileName: "[project]/app/auth/login/page.jsx",
                                                lineNumber: 258,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/auth/login/page.jsx",
                                        lineNumber: 254,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/auth/login/page.jsx",
                                lineNumber: 244,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/auth/login/page.jsx",
                        lineNumber: 198,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/auth/login/page.jsx",
                lineNumber: 114,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(LoginPage, "OpHAuaI6Ak16cA5eWOm2lm3IETQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$seo$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuthSEO"]
    ];
});
_c2 = LoginPage;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "GoogleIcon");
__turbopack_context__.k.register(_c1, "Logo");
__turbopack_context__.k.register(_c2, "LoginPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=_ceaa2696._.js.map